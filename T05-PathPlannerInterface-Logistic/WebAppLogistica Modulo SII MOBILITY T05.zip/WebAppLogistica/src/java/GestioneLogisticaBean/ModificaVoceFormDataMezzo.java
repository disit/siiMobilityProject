/****************************************************** 
 *   Document    : GestioneLogistica
 *   Created on  : 07-02-2017, 12.16.00
 *   Author      : TIME
 ******************************************************/
package GestioneLogisticaBean;


public class ModificaVoceFormDataMezzo {
  private String posVoce ;
    private Voce voce ;

    public ModificaVoceFormDataMezzo() {
        posVoce = "-1" ;
        voce = new Voce("") ;
    }

    public ModificaVoceFormDataMezzo(String posVoce, Voce voce) {
        this.posVoce = posVoce;
        this.voce = voce;
    }

    public String getPosVoce() {
        return posVoce;
    }

    public void setPosVoce(String posVoce) {
        this.posVoce = posVoce;
    }

    public Voce getVoce() {
        return voce;
    }

    public void setVoce(Voce voce) {
        this.voce = voce;
    }
    
    public void setMsg(String msg) {
    this.voce.setMsg(msg);
 
    }
    
    public String getMsg() {
     return this.voce.getMsg() ;
    }   
}
