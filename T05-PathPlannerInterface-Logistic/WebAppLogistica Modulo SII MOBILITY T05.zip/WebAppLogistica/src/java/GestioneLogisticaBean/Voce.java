/****************************************************** 
 *   Document    : GestioneLogistica
 *   Created on  : 07-02-2017, 12.16.00
 *   Author      : TIME
 ******************************************************/
package GestioneLogisticaBean;

public class Voce {
    private String msg ;
    
    public Voce(String msg) {
        this.msg = msg ;
    }
    
    public String getMsg() {
         return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
    
}
