/****************************************************** 
 *   Document    : GestioneLogistica
 *   Created on  : 07-02-2017, 12.16.00
 *   Author      : TIME
 ******************************************************/
package GestioneLogisticaBean;
import java.util.ArrayList;
import java.util.List;

    /*****************************************************************************************************************************
     * ListaLogisticaBean : Classe per la gestione dei dati
     * 
     * 
     ******************************************************************************************************************************/
public class ListaLogisticaBean {
    private List<Voce> logisticadati; //variabile locale utilizzata come variabile di comodo

    /**
     * Costruttore di default -- crea una lista  vuota, con zero voci.
     */
    public ListaLogisticaBean() {
        this.logisticadati = new ArrayList<Voce>();
    }

    /**
     * Aggiunge una nuova voce all'elenco
     * 
     * @param testo la stringa di testo corrispondente alla voce da aggiungere
     * @return  <code>void<code>
     */
    public void aggiungi(String testo) {
        Voce voce = new Voce(testo);
        logisticadati.add(voce);
            
    }

    public boolean elimina(int posVoce) {
           
        if (posVoce >= 0 && posVoce < logisticadati.size()) {
            Voce v = logisticadati.get(posVoce);
             logisticadati.remove(posVoce);
            return true;
        }
        return false;
    }

    /**
     * Modifica il testo presente in una certa voce dell'elenco.
     * 
     * @param posVoce Posizione della voce da modificare. Deve essere compreso
     * tra 0 e size-1
     * @param nuovoTesto Nuova stringa da sostituire alla precedente
     * @return <code>true</code> se la sostituzione ha avuto successo, <code>false</code> altrimenti.
     * 
     */
    public boolean modifica(int posVoce, String nuovoTesto) {
        if (posVoce >= 0 && posVoce < logisticadati.size()) {

            Voce nuova = new Voce(nuovoTesto);
            logisticadati.set(posVoce, nuova);

            return true;
        }

        return false;
    }

    /**
     * Sposta in alto la voce selezionata nella lista.
     * 
     * @param posVoce l'indice della voce da spostare in alto (compreso tra 1 e size-1)
     * @return <code>true</code> se lo spostamento ha avuto successo, <code>false</code> altrimenti.
     */
    public boolean spostaSu(int posVoce) {
        if (posVoce < 1 || posVoce > logisticadati.size() - 1) {
            return false;
        } else {
            Voce temp = logisticadati.get(posVoce - 1);
            logisticadati.set(posVoce - 1, logisticadati.get(posVoce));
            logisticadati.set(posVoce, temp);
            return true;
        }
    }
    
    /**
     * Sposta in basso la voce selezionata nella lista.
     * 
     * @param posVoce l'indice della voce da spostare in basso (compreso tra 0 e size-2)
     * @return <code>true</code> se lo spostamento ha avuto successo, <code>false</code> altrimenti.
     */
    public boolean spostaGiu(int posVoce) {
        if (posVoce < 0 || posVoce > logisticadati.size() - 2) {
            return false;
        } else {
            Voce temp = logisticadati.get(posVoce + 1);
            logisticadati.set(posVoce + 1, logisticadati.get(posVoce));
            logisticadati.set(posVoce, temp);
            return true;
        }
    }
    
    /**
     * Elimina il contenuto della lista della spesa
     */
    public void pulisci() {
        logisticadati.clear();
    }

    /**
     * Restituisce l'elenco di tutte le voci memorizzate
     * @return una collection di stringhe con le voci della lista
     */
    public List<Voce> getLogisticadati() {
        return logisticadati;
    }  
}
