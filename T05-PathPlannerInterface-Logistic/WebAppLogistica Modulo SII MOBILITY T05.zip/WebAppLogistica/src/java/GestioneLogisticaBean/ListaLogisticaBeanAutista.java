/****************************************************** 
 *   Document    : GestioneLogistica
 *   Created on  : 07-02-2017, 12.16.00
 *   Author      : TIME
 ******************************************************/
package GestioneLogisticaBean;
import java.util.ArrayList;
import java.util.List;


public class ListaLogisticaBeanAutista {
    private List<Voce> logisticadati; //variabile locale utilizzata come variabile di comodo

    /**
     * Costruttore di default -- crea una lista vuota, con zero voci.
     */
    public ListaLogisticaBeanAutista() {
        this.logisticadati = new ArrayList<Voce>();
    }

    /**
     * Aggiunge una nuova voce all'elenco
     * 
     * @param testo la stringa di testo corrispondente alla voce da aggiungere
     * 
     */
    public void aggiungi(String testo) {
        System.out.println("Stampo testo passato ad aggiungi: " + testo);
        Voce voce = new Voce(testo);
        logisticadati.add(voce);
            
    }
    /**
     * Modifica il testo presente in una certa voce dell'elenco.
     * 
     * @param posVoce Posizione della voce da modificare. Deve essere compreso
     * tra 0 e size-1
     * @param nuovoTesto Nuova stringa da sostituire alla precedente
     * @return <code>true</code> se la sostituzione ha avuto successo, <code>false</code> altrimenti.
     * 
     */
    public boolean modifica(int posVoce, String nuovoTesto) {
        if (posVoce >= 0 && posVoce < logisticadati.size()) {

            Voce nuova = new Voce(nuovoTesto);
            logisticadati.set(posVoce, nuova);

            return true;
        }

        return false;
    }

    
    /**
     * Elimina il contenuto della lista della spesa
     */
    public void pulisci() {
        logisticadati.clear();
    }

    /**
     * Restituisce l'elenco di tutte le voci memorizzate
     * @return una collection di stringhe con le voci della lista
     */
    public List<Voce> getLogisticadati() {
        return logisticadati;
    }  
}
   

