/****************************************************** 
 *   Document    : GestioneLogistica
 *   Created on  : 07-02-2017, 12.16.00
 *   Author      : TIME
 ******************************************************/

package GestioneLogistica;
import GestioneLogisticaBean.ListaLogisticaBean;
import GestioneLogistica.GestioneDati;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
    /*****************************************************************************************************************************
     * GestioneDatiMagazzino : Classe contenente i metodi per la gestione dei dati relativi ai Magazzini
     * 
     ******************************************************************************************************************************/

public class GestioneDatiMagazzino {

    /*****************************************************************************************************************************
     * fillListaDatiMagazzino()
     * 
     * Metodo che interrroga il DB e riempe il BEAN  
     * @param logisticadati struttura dati
     * @return <code> void <code>
     ******************************************************************************************************************************/
     public void fillListaDatiMagazzino(ListaLogisticaBean logisticadati) {
         Connection conn = DBConnect.getConnection();
        try {
            Statement st = conn.createStatement();
            String sql = "SELECT CodiceId, CodiceCorriere, Indirizzo, Citta, CAP, Provincia, DataRegistrazione, NumeroTelefonico, Latitudine, Longitudine, DataCancellazione, NumeroFax, Corriere_CodiceId, Corriere_PartitaIVA FROM Magazzino ORDER BY CodiceId";
            ResultSet res = st.executeQuery(sql) ;
            while (res.next()){
                if (res.getString("DataCancellazione") == null || res.getString("DataCancellazione") == "") {
                    logisticadati.aggiungi(res.getString("CodiceId"));
                    logisticadati.aggiungi(res.getString("CodiceCorriere"));
                    logisticadati.aggiungi(res.getString("Indirizzo"));
                    logisticadati.aggiungi(res.getString("Citta"));
                    logisticadati.aggiungi(res.getString("CAP"));
                    logisticadati.aggiungi(res.getString("Provincia"));
                    logisticadati.aggiungi(res.getString("DataRegistrazione"));
                    logisticadati.aggiungi(res.getString("NumeroTelefonico"));
                    logisticadati.aggiungi(res.getString("Latitudine"));
                    logisticadati.aggiungi(res.getString("Longitudine"));
                    logisticadati.aggiungi(res.getString("DataCancellazione"));
                    logisticadati.aggiungi(res.getString("NumeroFax"));
                    logisticadati.aggiungi(res.getString("Corriere_CodiceId"));
                    logisticadati.aggiungi(res.getString("Corriere_PartitaIVA"));
                    }
                }
             st.close();
             conn.close();
            } catch (SQLException ex) {
                Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
                throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
                }
    }
    /*****************************************************************************************************************************
     * fillListaDatiSingoloMagazzino()
     * Metodo che interrroga il DB e riempe il BEAN con i dati di un singolo Magazzino  
     * @param logisticadati struttura dati
     * @param posVoce CodiceId di un Magazzino
     * @return <code> void <code>
     * 
     ******************************************************************************************************************************/
    public void fillListaDatiSingoloMagazzino(ListaLogisticaBean logisticadati, int posVoce) {
        Connection conn = DBConnect.getConnection();
        try {
            Statement st = conn.createStatement();
            String sql = "SELECT CodiceId, Nome, Indirizzo, Citta, CAP, Provincia, DataRegistrazione, NumeroTelefonico, Latitudine, Longitudine, DataCancellazione, NumeroFax, Corriere_CodiceId, Corriere_PartitaIVA FROM Magazzino WHERE  CodiceId=" + posVoce;
            ResultSet res = st.executeQuery(sql) ;
            while (res.next()){
                if (res.getString("DataCancellazione") == null || res.getString("DataCancellazione") == "") {
                    logisticadati.aggiungi(res.getString("CodiceId"));
                    logisticadati.aggiungi(res.getString("Nome"));
                    logisticadati.aggiungi(res.getString("Indirizzo"));
                    logisticadati.aggiungi(res.getString("Citta"));
                    logisticadati.aggiungi(res.getString("CAP"));
                    logisticadati.aggiungi(res.getString("Provincia"));
                    logisticadati.aggiungi(res.getString("DataRegistrazione"));
                    logisticadati.aggiungi(res.getString("NumeroTelefonico"));
                    logisticadati.aggiungi(res.getString("Latitudine"));
                    logisticadati.aggiungi(res.getString("Longitudine"));
                    logisticadati.aggiungi(res.getString("DataCancellazione"));
                    logisticadati.aggiungi(res.getString("NumeroFax"));
                    logisticadati.aggiungi(res.getString("Corriere_CodiceId"));
                    logisticadati.aggiungi(res.getString("Corriere_PartitaIVA"));
                    }
                }
             st.close();
             conn.close();
            } catch (SQLException ex) {
                Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
                throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
                }
    }
    /*****************************************************************************************************************************
     * fillListaDatiMagazzinoCorriere()
     * Metodo che interrroga il DB e riempe il BEAN con i dati di tutti i Magazzini di un dato Corriere  
     * @param logisticadati struttura dati
     * @param posVoce CodiceId di un Corriere
     * @return <code> void <code>
     * 
     ******************************************************************************************************************************/
    public void fillListaDatiMagazzinoCorriere(ListaLogisticaBean logisticadati, int posVoce) {
        Connection conn = DBConnect.getConnection();
        try {
            Statement st = conn.createStatement();
            String sql = "SELECT CodiceId, CodiceCorriere, IndrizzoMag, Citta, CAP, Provincia, DataRegistrazione, NumeroTelefonico, DataCancellazione, NumeroFax FROM Magazzino WHERE  Corriere_CodiceId=" + posVoce;
            ResultSet res = st.executeQuery(sql) ;
            while (res.next()){
                String eliminaTest = res.getString("CodiceCorriere").toUpperCase();
                if (!eliminaTest.contains("TEST")){
                    logisticadati.aggiungi(res.getString("CodiceId"));
                    logisticadati.aggiungi(res.getString("CodiceCorriere"));
                    logisticadati.aggiungi(res.getString("IndrizzoMag"));
                    logisticadati.aggiungi(res.getString("Citta"));
                    logisticadati.aggiungi(res.getString("CAP"));
                    logisticadati.aggiungi(res.getString("Provincia"));
                    logisticadati.aggiungi(res.getString("NumeroTelefonico"));
                    logisticadati.aggiungi(res.getString("NumeroFax"));
                    logisticadati.aggiungi(res.getString("DataRegistrazione"));
                    logisticadati.aggiungi(res.getString("DataCancellazione"));
                    }
                }
            st.close();
            conn.close();
            } catch (SQLException ex) {
                Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
                throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
                }
    }
            
}
