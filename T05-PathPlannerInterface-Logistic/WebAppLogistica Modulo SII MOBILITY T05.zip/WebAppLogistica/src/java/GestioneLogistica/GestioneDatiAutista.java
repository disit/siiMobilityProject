/****************************************************** 
 *   Document    : GestioneLogistica
 *   Created on  : 07-02-2017, 12.16.00
 *   Author      : TIME
 ******************************************************/
package GestioneLogistica;

import GestioneLogisticaBean.ListaLogisticaBean;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

    /*****************************************************************************************************************************
     * GestioneDatiAutista : Classe contenente i metodi per la gestione dei dati relativi agli Autisti
     * 
     * 
     ******************************************************************************************************************************/

public class GestioneDatiAutista {
    /*****************************************************************************************************************************
     * fillListaDatiAutistaPadroncino()
     * Metodo che interrroga il DB e riempe il BEAN  
     * @param logistadati struttura dati
     * @param posVoce CodiceIde del Padroncino
     * @result <code> void <code> 
     ******************************************************************************************************************************/
    public void fillListaDatiAutistaPadroncino(ListaLogisticaBean logisticadati, int posVoce) {
        Connection conn = DBConnect.getConnection();
        try {
            Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "SELECT CodiceId, CodiceAutista, NomeAutista, CognomeAutista, TelefonoAutista, TurnoAutista, PresenzaAutista, TipoRapporto, DataInizioRapporto, DataFineRapportoPrevista, DataRegistrazione, DataCancellazione, Mezzo_Anagrafica_CodiceMezzo, Padroncino_Anagrafica_CodiceId, Padroncino_Anagrafica_PartitaIva FROM autista_anagrafica WHERE Padroncino_Anagrafica_CodiceId=" + posVoce;
            ResultSet res = st.executeQuery(sql) ;
            if (res.last()) { 
                int numeroRighe = res.getRow();
                res.beforeFirst();
            
                while (res.next()){
                    String eliminaTest = res.getString("CodiceAutista").toUpperCase();
                    if (!eliminaTest.contains("TEST")){
                        logisticadati.aggiungi(res.getString("CodiceId"));
                        logisticadati.aggiungi(res.getString("CodiceAutista"));
                        logisticadati.aggiungi(res.getString("NomeAutista") + " " + res.getString("CognomeAutista"));
                        //logisticadati.aggiungi(res.getString("CognomeAutista"));
                        logisticadati.aggiungi(res.getString("TelefonoAutista"));
                        logisticadati.aggiungi(res.getString("TurnoAutista"));
                        logisticadati.aggiungi(res.getString("PresenzaAutista"));
                        logisticadati.aggiungi(res.getString("TipoRapporto"));
                        //logisticadati.aggiungi(res.getString("DataInizioRapporto"));
                        //logisticadati.aggiungi(res.getString("DataFineRapportoPrevista"));
                        logisticadati.aggiungi(res.getString("Mezzo_Anagrafica_CodiceMezzo"));
                        logisticadati.aggiungi(res.getString("DataRegistrazione"));
                        logisticadati.aggiungi(res.getString("DataCancellazione"));
                        }
                    }
                }else {
                    System.out.println("ERR: Non sono presenti Autisti per il padroncino: CodiceId=" + res.getString("Padroncino_Anagrafica_CodiceId") + ", PartitaIVA= " + res.getString("Padroncino_Anagrafica_PartitaIva"));
                    }
            st.close();
            conn.close();
            } catch (SQLException ex) {
            Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
            throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
        }
    }
     
}
