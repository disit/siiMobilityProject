/****************************************************** 
 *   Document    : GestioneLogistica
 *   Created on  : 07-02-2017, 12.16.00
 *   Author      : TIME
 ******************************************************/

package GestioneLogistica;

import GestioneLogisticaBean.ListaLogisticaBean;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

    /*****************************************************************************************************************************
     * GestioneDatiMezzo : Classe contenente i metodi per la gestione dei dati relativi ai Mezzi
     * 
     * 
     ******************************************************************************************************************************/

public class GestioneDatiMezzo {
      /*****************************************************************************************************************************
     * fillListaDatiMezzo()
     * 
     * Metodo che interrroga il DB e riempe il BEAN  ei dati relaiti ai Mezzi
     * @param logisticadati struttura dati
     * @return <code> void <code>
     ******************************************************************************************************************************/
     public void fillListaDatiMezzo(ListaLogisticaBean logisticadati) {
        String eliminaTest;
        Connection conn = DBConnect.getConnection();
        try {
            Statement st = conn.createStatement();
            String sql = "SELECT CodiceId, CodiceMezzo, TipoMezzo, DisponibilitaMezzo, AltezzaMezzo, LunghezzaMezzo, PesoMezzo, VolumeMezzo, TipoEuro, TipoCarburante, DataRegistrazione, DataCancellazione, UtilizzoMezzo FROM mezzo_anagrafica ORDER BY CodiceId";
            ResultSet res = st.executeQuery(sql) ;
            while (res.next()){
                if (res.getString("DataCancellazione") == null || res.getString("DataCancellazione") == "") {
                    eliminaTest = res.getString("CodiceMezzo").toUpperCase();
                    if (!eliminaTest.contains("TEST")){
                        logisticadati.aggiungi(res.getString("CodiceId"));
                        logisticadati.aggiungi(res.getString("CodiceMezzo"));
                        logisticadati.aggiungi(res.getString("TipoMezzo"));
                        logisticadati.aggiungi(res.getString("DisponibilitaMezzo"));
                        logisticadati.aggiungi(res.getString("AltezzaMezzo"));
                        logisticadati.aggiungi(res.getString("LunghezzaMezzo"));
                        logisticadati.aggiungi(res.getString("PesoMezzo"));
                        logisticadati.aggiungi(res.getString("VolumeMezzo"));
                        logisticadati.aggiungi(res.getString("TipoEuro"));
                        logisticadati.aggiungi(res.getString("TipoCarburante"));
                        logisticadati.aggiungi(res.getString("UtilizzoMezzo"));
                        logisticadati.aggiungi(res.getString("DataRegistrazione"));
                        logisticadati.aggiungi(res.getString("DataCancellazione"));
                        }
                    }
                }
             st.close();
             conn.close();
            } catch (SQLException ex) {
                Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
                throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
                }
    }
    /*****************************************************************************************************************************
     * fillListaDatiSingoloMezzo()
     * Metodo che permette di recuperare idati relaivi ad un determinato Mezzo
     * @param logisticadati struttura dati
     * @param posVoce CodiceId di un Mezzo
     * @return <code> void <code>
     ******************************************************************************************************************************/
    public void fillListaDatiSingoloMezzo(ListaLogisticaBean logisticadati, int posVoce) {
        String eliminaTest;
        Connection conn = DBConnect.getConnection();
         try {
            Statement st = conn.createStatement();
            String sql = "SELECT CodiceId, CodiceMezzo, TipoMezzo, DisponibilitaMezzo, AltezzaMezzo, LunghezzaMezzo, PesoMezzo, VolumeMezzo, TipoEuro, TipoCarburante, DataRegistrazione, DataCancellazione, UtilizzoMezzo FROM mezzo_anagrafica ORDER BY CodiceId=" + posVoce;
            ResultSet res = st.executeQuery(sql) ;
            while (res.next()){
                 //inserisco solo i record che non sono stati cancellati logicamente, questi non saranno resi visibili
                 if (res.getString("DataCancellazione") == null || res.getString("DataCancellazione") == "") {
                    eliminaTest = res.getString("CodiceMezzo").toUpperCase();
                    if (!eliminaTest.contains("TEST")){
                        logisticadati.aggiungi(res.getString("CodiceId"));
                        logisticadati.aggiungi(res.getString("CodiceMezzo"));
                        logisticadati.aggiungi(res.getString("TipoMezzo"));
                        logisticadati.aggiungi(res.getString("DisponibilitaMezzo"));
                        logisticadati.aggiungi(res.getString("AltezzaMezzo"));
                        logisticadati.aggiungi(res.getString("LunghezzaMezzo"));
                        logisticadati.aggiungi(res.getString("PesoMezzo"));
                        logisticadati.aggiungi(res.getString("VolumeMezzo"));
                        logisticadati.aggiungi(res.getString("TipoEuro"));
                        logisticadati.aggiungi(res.getString("TipoCarburante"));
                        logisticadati.aggiungi(res.getString("UtilizzoMezzo"));
                        logisticadati.aggiungi(res.getString("DataRegistrazione"));
                        logisticadati.aggiungi(res.getString("DataCancellazione"));
                        }
                    }
                }
             st.close();
             conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
            throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
            }
    }
/*****************************************************************************************************************************
     * fillListaDatiMezzoPadroncino()
     * Metodo che recupera i dati relaivi ai mezzi di un dato Padroncino
     * @param logisticadati struttura dati
     * @param posVoce CodiceId di un Padroncino
     * @return <code> void <code>
     ******************************************************************************************************************************/
    public void fillListaDatiMezzoPadroncino(ListaLogisticaBean logisticadati, int posVoce) {
         String eliminaTest;
        Connection conn = DBConnect.getConnection();
        try {
            Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "SELECT CodiceId, CodiceMezzo, TipoMezzo, DisponibilitaMezzo, AltezzaMezzo, LunghezzaMezzo, PesoMezzo, VolumeMezzo, TipoEuro, TipoCarburante, DataRegistrazione, DataCancellazione, UtilizzoMezzo, Padroncino_Anagrafica_CodiceId, Padroncino_Anagrafica_PartitaIva FROM mezzo_anagrafica WHERE Padroncino_Anagrafica_CodiceId=" + posVoce;
            ResultSet res = st.executeQuery(sql) ;
            if (res.last()) { //-- se il numero di righe è 0 passo oltre
                int numeroRighe = res.getRow();
                res.beforeFirst();
            
                while (res.next()){
                    eliminaTest = res.getString("CodiceMezzo").toUpperCase();
                    if (!eliminaTest.contains("TEST")){
                        logisticadati.aggiungi(res.getString("CodiceId"));
                        logisticadati.aggiungi(res.getString("CodiceMezzo"));
                        logisticadati.aggiungi(res.getString("TipoMezzo"));
                        logisticadati.aggiungi(res.getString("AltezzaMezzo"));
                        logisticadati.aggiungi(res.getString("LunghezzaMezzo"));
                        logisticadati.aggiungi(res.getString("PesoMezzo"));
                        logisticadati.aggiungi(res.getString("VolumeMezzo"));
                        logisticadati.aggiungi(res.getString("TipoEuro"));
                        logisticadati.aggiungi(res.getString("TipoCarburante"));
                        logisticadati.aggiungi(res.getString("DataRegistrazione"));
                        logisticadati.aggiungi(res.getString("DataCancellazione"));
                        }
                    }
                }else {
                    System.out.println("ERR: Non sono presenti Mezzi il padroncino: CodiceId=" + res.getString("Padroncino_Anagrafica_CodiceId") + ", PartitaIVA= " + res.getString("Padroncino_Anagrafica_PartitaIva"));
                    }
            st.close();
            conn.close();
            } catch (SQLException ex) {
                Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
                throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
                }
    }
    
     /*****************************************************************************************************************************
     * fillListaDatiCorriereDaRecuperare()
     * 
     * metodo che interrroga il DB e cancella il valore della data di cancellazione in modo da recuperare il dato
     * @param logisticadati struttura dati
     * @param posVoce CodiceId di un Corriere
     * @return <code> void <code>
     ******************************************************************************************************************************/
     public void fillListaDatiMezzoDaRecuperare(ListaLogisticaBean logisticadati) {
        String eliminaTest;
        Connection conn = DBConnect.getConnection();
        try {
            Statement st = conn.createStatement();
            String sql = "SELECT CodiceId, Nome, Indirizzo, Citta, CAP, Provincia, DataRegistrazione, NumeroTelefonico, Latitudine, Longitudine, DataCancellazione, NumeroFax, Corriere_CodiceId, Corriere_PartitaIVA FROM Magazzino ORDER BY CodiceId";
            ResultSet res = st.executeQuery(sql) ;
            while (res.next()){
                if (res.getString("DataCancellazione") != null ) {
                    eliminaTest = res.getString("CodiceMezzo").toUpperCase();
                    if (!eliminaTest.contains("TEST")){
                        logisticadati.aggiungi(res.getString("CodiceId"));
                        logisticadati.aggiungi(res.getString("Nome"));
                        logisticadati.aggiungi(res.getString("Indirizzo"));
                        logisticadati.aggiungi(res.getString("Citta"));
                        logisticadati.aggiungi(res.getString("CAP"));
                        logisticadati.aggiungi(res.getString("Provincia"));
                        logisticadati.aggiungi(res.getString("DataRegistrazione"));
                        logisticadati.aggiungi(res.getString("NumeroTelefonico"));
                        logisticadati.aggiungi(res.getString("Latitudine"));
                        logisticadati.aggiungi(res.getString("Longitudine"));
                        logisticadati.aggiungi(res.getString("DataCancellazione"));
                        logisticadati.aggiungi(res.getString("NumeroFax"));
                        logisticadati.aggiungi(res.getString("Corriere_CodiceId"));
                        logisticadati.aggiungi(res.getString("Corriere_PartitaIVA"));
                        }
                    }
                }
            st.close();
            conn.close();
            } catch (SQLException ex) {
                    Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
                    throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
                    }
    }
    
    
}
