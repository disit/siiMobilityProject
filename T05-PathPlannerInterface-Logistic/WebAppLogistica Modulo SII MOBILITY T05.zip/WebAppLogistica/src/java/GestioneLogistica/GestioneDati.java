
/****************************************************** 
 *   Document    : GestioneLogistica
 *   Created on  : 07-02-2017, 12.16.00
 *   Author      : TIME
 ******************************************************/

package GestioneLogistica;
//import it.polito.elite.paw.listaspesa.ListaSpesaBean;
import GestioneLogisticaBean.ListaLogisticaBean;
import GestioneLogisticaBean.ListaLogisticaBeanMezzo;
import java.lang.RuntimeException;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

    /*****************************************************************************************************************************
     * GestioneDati : Classe contenente i metodi per elaborazioni dei dati
     * 
     * 
     ******************************************************************************************************************************/
public class GestioneDati {
     
    /*****************************************************************************************************************************
     * 
     * getMaxOrd()
     * 
     * Metodo che calcola il massimo numero d'ordine presente nella tabella
     *      @param NomeTabella nome della tabella
     *      @param NomeCampo nome del campo che contiene il codice incrementale
     * 
     *      @return <code>ord</code>   valore massimo del numero d'ordine, se vi sono elementi memorizzati;
     *      @return <code>  -1</code> se invece il database non contiene ancora elementi
     * 
    ******************************************************************************************************************************/
    public int getMaxOrd(String NomeTabella, String NomeCampo) {
        Connection conn = DBConnect.getConnection();

        try {
            Statement st = conn.createStatement();
            String sql="";
             sql = "SELECT MAX(" + NomeCampo + ") FROM " + NomeTabella; 
            ResultSet res = st.executeQuery(sql);

            int ord;
            if (res.next()) {
                ord = res.getInt(1);
                if (res.wasNull()) {   
                    ord = -1;
                }
            } else {
                ord = -1;
            }
            st.close();
            conn.close();
            return ord ;
        } catch (SQLException ex) {
            Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
            throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
        }
    }
    
    /*****************************************************************************************************************************
     * controlloChiaveUnica()
     * 
     * Metodo che verifica se un elemento è presente in una tabella
     * @param NomeTabella nome della tabella
     * @param NomeChiave nome del campo chiave
     * @param ValoreChiave valore del campo chiave
     * 
     *  
     * @return <code>true</code> se nella tabella è già presente un record con stessa chiave;
     * <code> false</code> altrimenti
     ******************************************************************************************************************************/
    public boolean controlloChiaveUnica(String NomeTabella, String NomeChiave, String ValoreChiave) {
        Connection conn = DBConnect.getConnection();
        System.out.println("stampo i valori passati a controlloChiaveUnica: "+ NomeTabella + " " + NomeChiave + " " + ValoreChiave);
        try {
            Statement st = conn.createStatement();
            String sqlselect = "SELECT * FROM "+ NomeTabella + " WHERE " + NomeChiave + " = " + "'" + ValoreChiave + "'";
            System.out.println("stampo sqlselect: " + sqlselect);
            ResultSet res = st.executeQuery(sqlselect);
            if (res.first()){
                st.close();
                conn.close();
                return true;
            } else {
                st.close();
                conn.close();
                return false;
                }
        } catch (SQLException ex) {
            Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
           throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
            }
    }
    /*****************************************************************************************************************************
     * searchCodice()
     * 
     * Metodo che ritorna il CodiceId associato ad un elemento.
     * 
     * 
     * @param NomeTabella nome della tabella
     * @param Chiave chiave che identifica l'elemento
     * 
     * @return <code>CodiceId</code> se la ricerca non è avvenuta con successo,
     * <code>valore >0</code> altrimenti
     ******************************************************************************************************************************/
       
     public int searchCodice(String NomeTabella, String NomeChiave, String ValoreChiave) {
        Connection conn = DBConnect.getConnection();
        try {
            Statement st = conn.createStatement();
            String sqlselect = "SELECT * FROM "+ NomeTabella + " WHERE " + NomeChiave + " = " + "'" + ValoreChiave + "'";
            ResultSet res = st.executeQuery(sqlselect);
            String parametro=null;
            
            parametro="CodiceId";
            if (res.first()){
                int ritorno = Integer.parseInt(res.getString(parametro));
                st.close();
                conn.close();
                return ritorno;
            } else {
                st.close();
                conn.close();
                return 0;
                }
        } catch (SQLException ex) {
            Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
            throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
            }
        
     }
     /*****************************************************************************************************************************
     * searchValore()
     * 
     * Metodo che ricerca il valore di un specifico elemento identificato da una chiave.
     * 
     * 
     * @param NomeTabella nome della tabella
     * @param NomeChiave nome della chiave che identifica l'elemento
     * @param ValoreChiave valore della chiave che identifica l'elemento e su cui si vuol fare la ricerca
     * @param NomeElemento nome dell'elemento di cui vogliamo il valore
     * 
     * @return <code>null</code> se la ricerca non è avvenuta con successo,
     * <code>valore >valore</code> altrimenti
     ******************************************************************************************************************************/
       
     public String searchValore(String NomeTabella, String NomeChiave, String ValoreChiave, String NomeElemento) {
        System.out.println("stampo i valori passati a searchValore: " + NomeTabella + " " + NomeChiave + " " + ValoreChiave + " " + NomeElemento);
       Connection conn = DBConnect.getConnection();
        try {
            Statement st = conn.createStatement();
            String sqlselect = "SELECT * FROM "+ NomeTabella + " WHERE " + NomeChiave + " = " + "'" + ValoreChiave + "'";
            ResultSet res = st.executeQuery(sqlselect);

           if (res.first()){
               String ritorno = res.getString(NomeElemento);
               st.close();
               conn.close();
               return ritorno;
            } else {
               
                st.close();
                conn.close();
                return null;
                }
        } catch (SQLException ex) {
            Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
            throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
            }
        
     }
    
  /*****************************************************************************************************************************
     * controllMin()
     * 
     * Metodo che restituisce la posizione dove inserire il barcode nell'ArrayAppoggio.
     * 
     * 
     * @param orarioVal ora stimata di consegna
     *
     * 
     * @return <code>null</code> se la ricerca non è avvenuta con successo,
     * <code>valore >valore</code> altrimenti
     ******************************************************************************************************************************/
       
     public static int controllaMin(Time orarioVal) {
        int ris, valMn;
        if (orarioVal == null) {
            valMn=0;
        } else {
            valMn = orarioVal.getMinutes();
            }
         ris = 0;
         if (valMn > 0 && valMn <= 15){
             ris = 0;
         }else{
             if (valMn > 15 && valMn <= 30){
                 ris = 1;
             }else {
                 if (valMn > 30 && valMn <= 45) {
                     ris = 2;
                 } else {
                     if (ris > 45) {
                         ris = 3;
                     }
                 }
             }
         }
         return (ris);
         
     }    
/*****************************************************************************************************************************
     * controllaOraMin()
     * 
     * Metodo che restituisce la posizione dove inserire il barcode nell'ArrayAppoggio.
     * 
     * 
     * @param orarioVal ora stimata di consegna
     *
     * 
     * @return <code>null</code> se la ricerca non è avvenuta con successo,
     * <code>valore >valore</code> altrimenti
     ******************************************************************************************************************************/
       
     public static int controllaOraMin (Time orarioVal) {
        int ris, ris1, ris2, valMn, valOra;
        ris = 0;
        ris1 = 0;
        ris2 = 0;
        if (orarioVal==null){
            valOra=18;
            valMn=0;
            
        } else{
          valMn = orarioVal.getMinutes();
          valOra = orarioVal.getHours();
        }
        System.out.println("Stampo ora e minuti: " + valOra  + " " + valMn);
        
        if (valMn == 0 ) {
            if (valOra >= 18) {
               ris = (4*(valOra-8)); 
            }else {
            ris = (4*(valOra-8)) + 1;
            }
        } else {
            ris1 = (4*(valOra-8)) + 1;
            ris2 =controllaMin(orarioVal);
            ris = ris1 + ris2 ;
        }
         
         return (ris);
         
     }  
      /*****************************************************************************************************************************
     * controllaOra()
     * 
     * Metodo che restituisce la posizione dove inserire il barcode nell'ArrayAppoggio.
     * 
     * 
     * @param orarioVal ora stimata di consegna
     *
     * 
     * @return <code>null</code> se la ricerca non è avvenuta con successo,
     * <code>valore >valore</code> altrimenti
     ******************************************************************************************************************************/
       
     public static int controllaOra(Time orarioVal) {
        int ris, valOra;
        if (orarioVal == null) {
            valOra=18;
        }else {
          valOra = orarioVal.getHours();
        }
         if (valOra >= 18) {
             ris = valOra-8;
         } else {
         ris = (valOra-8) + 1;
         }
         return (ris);
         
     }
     /*****************************************************************************************************************************
     * getColoreMezzo()
     * 
     * Ritorna la percentuale
     * 
     * @param Mezzo identificativo per poter accedere alle due tabelle
     * dell'elemento da leggere
     * 
     * @return percentuale <code>Percentuale</code>,
     * oppure <code>0</code> se non è possibile calcolare la percentuale
    ******************************************************************************************************************************/
    public static Double getColoreMezzo(String Mezzo) {
        Double totalValue = null;
        int weightTrk = 0;
         try {
            Connection conn = DBConnect.getConnection();
            Statement st = conn.createStatement();
            Statement st1 = conn.createStatement();
            
            String sql = "SELECT SUM(PesoDichiarato) FROM riassegnazioneColli WHERE Mezzo_Anagrafica_CodiceMezzo = " + "'" + Mezzo + "'";
            ResultSet res = st.executeQuery(sql);
            int index = 1;
            if (res.next()) {
                totalValue = res.getDouble(index);
                 String sql1 = "SELECT PesoMezzo FROM mezzo_anagrafica WHERE CodiceMezzo = " + "'" + Mezzo + "'";
                ResultSet res1 = st.executeQuery(sql1);
                if (res1.next()) {
                    int controllo = isDoubleOrInt (res1.getString("PesoMezzo"));
                    if (controllo >= 0){
                            weightTrk = Integer.parseInt(res1.getString("PesoMezzo"));
                            }else {
                                weightTrk=100;
                                }
                    }
                } 
            Double calcoloPerc = (100*totalValue)/weightTrk;
            st.close();
            st1.close();
            conn.close();
            return   calcoloPerc;      
                
            
        } catch (SQLException ex) {
            Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
            throw new RuntimeException("database error in " );
        }
        
    }
    
    /*****************************************************************************************************************************
    * Verifica se una stringa è un numero (double o int).
    * @return -1 se non è una stringa valida,
    * 0 se è un int, 1 se è un double
    ******************************************************************************************************************************/
    public static int isDoubleOrInt(String num){
     System.out.println("Stampo num :" + num);
        try{
            Integer.parseInt(num);
            return 0;
            }catch(Exception e){
                try{
                    Double.parseDouble(num);
                    return 1;
                    }catch(Exception err){
                        return -1;
                        }
                }
    } 
     /*****************************************************************************************************************************
     * controlloZTL()
     * 
     * Ritorna la percentuale
     * 
     * @param valoreZTL valore da controllare
     * @param OraconsegnaRichiesta valore ora consegna richiesta
     * @return percentuale <code>valoreRitorno</code>,
     * oppure <code>null</code> se non è possibile calcolare la percentuale
    ******************************************************************************************************************************/

    public static String controlloZTL (String valoreZTL, Time OraconsegnaRichiesta){
    String valoreRitorno=null;
    String varAppoggio=null;
    if (valoreZTL == null){
            valoreZTL= "NO";
            } 
    if (valoreZTL.equals("SI")){
            valoreRitorno ="ZTL ";
            } else {
                if((OraconsegnaRichiesta == null )){
                    valoreRitorno="NOV ";
                    } else {
                        valoreRitorno="OV ";
                        }
                }
    return valoreRitorno;
    }

 /*****************************************************************************************************************************
     * getMsgCorriere()
     * 
     * Ritorna la stringa corrispondente ad una specifica voce della tabella Corriere
     * 
     * @param posVoce il numero d'ordine (compreso tra 0 e getMaxOrd(), estremi compresi)
     * dell'elemento da leggere
     * @param nomeTabella nome della tabella
     * @param nomeCampo nome dell'elemento che si vuol leggere
     * 
     * @return il messaggio corrispondente alla posizione <code>posVoce</code>,
     * oppure <code>null</code> se il numero d'ordine è errato
    ******************************************************************************************************************************/
    public String getSingleVal(int posVoce, String nomeTabella, String nomeCampo) {
        String msg = "";
         try {
            Connection conn = DBConnect.getConnection();
            Statement st = conn.createStatement();
            String sql = "SELECT * FROM " + nomeTabella +" WHERE CodiceId=" + posVoce;
            ResultSet res = st.executeQuery(sql);
            if (res.next()) {
                msg = res.getString(nomeCampo);
                st.close();
                conn.close();
                return msg;
            }
        } catch (SQLException ex) {
            Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
            throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
        }
        return null;
    }    
 
}