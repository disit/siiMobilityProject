/****************************************************** 
 *   Document    : GestioneLogistica
 *   Created on  : 07-02-2017, 12.16.00
 *   Author      : TIME
 ******************************************************/

package GestioneLogistica;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import GestioneLogisticaBean.ListaLogisticaBeanAutista;

     /*********************************************************************************************************************************
     * GestioneListe: Classe contenente i metodi per la gestione dei dati relativi alle Liste Consegne - Ritiri e Liste pickup
     * 
     * 
     **********************************************************************************************************************************/

public class GestioneListe {
 
 
    /*****************************************************************************************************************************
     * listaCRAutista()
     * 
     * metodo che interrroga il DB per ricercare tutti gli autisti che lavorano in una data .
     * Per ciascuna autista devono essere visualizzate delle info da recuperare nella tabella listaconsegneritiri
     * 
     * @param logisticadati struttura dati
     * @param DataInizioServizio data di creazione della lista
     * @result <code> void <code> 
     ******************************************************************************************************************************/
 public void listaCRAutista( ListaLogisticaBeanAutista logisticadati, Date DataInizioServizio) {
   String sql,eliminaTest;
        Connection conn = DBConnect.getConnection();
        try {
            Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            sql="SELECT DISTINCT Autista_Anagrafica_CodiceAutista FROM listeconsegneritiri";
            ResultSet res = st.executeQuery(sql) ;
            if (res.last()) { 
                int numeroRighe = res.getRow();
                 res.beforeFirst();
                while (res.next()){
                    eliminaTest = res.getString("Autista_Anagrafica_CodiceAutista").toUpperCase();
                    if (!eliminaTest.contains("TEST")){
                         listaCRfillAutistaBarcode(logisticadati, res.getString("Autista_Anagrafica_CodiceAutista"), null);
                        }
                    }
                }else {
                        System.out.println("Err ************: non ci sono autisti " );
                         }  
            st.close();
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
            throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
            }
    
      
 } 
    
    
    
    
    
    
 /*****************************************************************************************************************************
     * listaCRfillAutistaBarcode()
     * 
     * metodo che interrroga il DB per ricercare tutte le info relative ai colli che un dato autista deve consegnare o ritirare
     * in input legge la chiave dell'autista ed esegue una selec sulla tabella listaconsegneritiri. Da qui estrai tutti i barcode
     * associati all'autista e tutte le informazioni di interesse ad esso collegate
     * 
     * @param logisticadati struttura dati
     * @param valoreChiave codice autista
     * @param DataInizioServizio data di creazione della lista
     * @result <code> void <code> 
     ******************************************************************************************************************************/
    
    public void listaCRfillAutistaBarcode( ListaLogisticaBeanAutista logisticadati, String valoreChiave, Date DataInizioServizio) {
        String sql,str1, str2, str3, str4, str5;
        String[] valAppoggio;
        int N = 11;
        Connection conn = DBConnect.getConnection();
        //-- query
        try {
            Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            //-- Eseguo una nuova interrogazione per prelevare tutti i dati relativi al carico di quel mezzo nella tabella listaconsegnaritiri
            sql="SELECT BarCode, TipoSpedizione, IndirizzoDestinatario, CittaDestinatario,CAPDestinatario,OraConsegnaRichiesta,OraStimata,DataInizioServizio FROM listeconsegneritiri WHERE Autista_Anagrafica_CodiceAutista=" + "'" + valoreChiave + "'" + "  " + "ORDER BY OraStimata";
            System.out.println("Stampo da listaCRricercaAutistaBarcode select :" + sql);
            ResultSet res = st.executeQuery(sql) ;
            valAppoggio = new String[N];        
            if (res.last()) { 
                int numeroRighe = res.getRow();
                res.beforeFirst();
                str5 = valoreChiave;
                valAppoggio[0] = str5 + "#";
                while (res.next()){
                       int posizione;
                        posizione = GestioneDati.controllaOra(res.getTime("OraStimata"));
                        System.out.println("Stampo da listaCRricercaAutistaBarcode posizione :" + posizione);
                        str1 =  res.getString("BarCode");
                        if (res.getString("OraConsegnaRichiesta")== null){
                            str3 = "nessuna";
                        }else {
                            str3 = res.getString("OraConsegnaRichiesta");
                        }
                        if (res.getString("DataInizioServizio")== null){
                            str4 = "nessuna";
                        }else{
                            str4 = res.getString("DataInizioServizio");
                        }
                        str2 = "€" + res.getString("TipoSpedizione") +
                                "€" + res.getString("IndirizzoDestinatario") + 
                                "€" + res.getString("CAPDestinatario") + 
                                "€" + res.getString("CittaDestinatario") +
                                "€" + str3 +
                                "€" +  str4;
                            if (valAppoggio[posizione] != null) {
                                valAppoggio[posizione]= valAppoggio[posizione] + "$ " + str1 + str2  ;
                                }else {
                                    valAppoggio[posizione]= str1 + str2 ; 
                                    } 
                            }
                 for (int i = 0; i<N; i++){
                        if (valAppoggio[i] == null){
                            valAppoggio[i] = " -- ";
                            }
                        logisticadati.aggiungi(valAppoggio[i]);
                        }
                }else {
                        System.out.println("Err ************: non ci sono dati per l'autista " );
                            for (int i = 0; i<N; i++){
                                if (valAppoggio[i] == null){
                                    valAppoggio[i] = " -- ";
                                    }
                                logisticadati.aggiungi(valAppoggio[i]);
                                }
                            //FINE scrittura nel bean

                        }  
            st.close();
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
            throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
        }
    }
    
 /*****************************************************************************************************************************
     * listaPKAutista()
     * 
     * metodo che interrroga il DB per ricercare tutti gli autisti che lavorano in una data .
     * Per ciascuna autista devono essere visualizzate delle info da recuperare nella tabella listepickup
     * il metodo è richiamato da <<doListaPKMain.jsp>>
     * @param logisticadati codice incrementale che identifica l'elemento nel DB
     * @param DataInizioServizio data di creazione della lista
     * @result <code> void <code> 
     ******************************************************************************************************************************/
 public void listaPKAutista( ListaLogisticaBeanAutista logisticadati, Date DataInizioServizio) {    
    String sql,sql1, str1;
    String[] valAppoggioPK;
    int trovato = 0;
        Connection conn = DBConnect.getConnection();
        //-- query
        try {
            Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            Statement st1 = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            // ricerco tutti i magazzini
            sql1="SELECT CodiceId, CodiceCorriere FROM magazzino WHERE (Nome <> 'MagazzinoTest') AND (Nome <> 'MagazzinoTest2') Order by CodiceId";
            ResultSet res1 = st1.executeQuery(sql1) ;
                   
            if (res1.last()) { 
                int N = res1.getRow()+1;
                System.out.println("STAMPO****************************** da listaPKAutista numerorighe :" + N);
                valAppoggioPK = new String[N];   
                res1.beforeFirst();
                valAppoggioPK[0] = Integer.toString(N);
                logisticadati.aggiungi(valAppoggioPK[0]);
                int i = 1; 
                while (res1.next()){
                        valAppoggioPK[i]=res1.getString("CodiceCorriere");
                        logisticadati.aggiungi(valAppoggioPK[i]);
                        i++;
                        }
                sql="SELECT DISTINCT CodiceAutista FROM listepickup";
                ResultSet res = st.executeQuery(sql) ;
                if (res.last()) { 
                    int numeroRighe = res.getRow();
                    System.out.println("STAMPO****************************** da listaPKAutista numeroRighe seconda select :" + numeroRighe);
                    res.beforeFirst();
                    while (res.next()){
                            String varAut=res.getString("CodiceAutista");
                            String eliminaTest = res.getString("CodiceAutista").toUpperCase();
                            if (!eliminaTest.contains("TEST")){
                                listaPKfillAutistaBarcode(logisticadati, varAut, null, N);
                                }
                            }
                    }else {
                        System.out.println("Err ************: non ci sono autisti " );
                        }  
                }else {
                        System.out.println("Err ************: non ci sono magazzini " );
                        }  

            st.close();
            st1.close();
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
            throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
            }
 }   
/*****************************************************************************************************************************
     * listaPKfillAutistaBarcode()
     * 
     * metodo che interrroga il DB per ricercare tutte le info relative ai colli che un dato autista deve consegnare o ritirare
     * in input legge la chiave dell'autista ed esegue una selec sulla tabella listaconsegneritiri. Da qui estrai tutti i barcode
     * associati all'autista e tutte le informazioni di interesse ad esso collegate
     * 
     * @param logisticadati codice incrementale che identifica l'elemento nel DB
     * @param valoreChiave codice autista
     * @param DataInizioServizio data di creazione della lista
     * @param N numero di magazzini presenti 
     * @result <code> void <code> 
     ******************************************************************************************************************************/
    
    public void listaPKfillAutistaBarcode( ListaLogisticaBeanAutista logisticadati, String valoreChiave, Date DataInizioServizio, int N) {
        String sql,str1, str2, str3, str4, str5;
        String[] valAppoggio;
        int posizione = 0;
        Connection conn = DBConnect.getConnection();
        //-- query
        try {
            Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
             sql="SELECT Barcode, TipoSpedizione, Magazzino_CodiceCorriere, IndrizzoMag, Citta, CAP, DataInizioServizio FROM listepickup WHERE CodiceAutista=" +
                        "'" + valoreChiave + "'" + "  " +"ORDER BY DataInizioServizio";
            ResultSet res = st.executeQuery(sql) ;
           
            valAppoggio = new String[N];        
            if (res.last()) { 
                int numeroRighe = res.getRow();
                res.beforeFirst();
                str5 = valoreChiave;
                valAppoggio[0] = str5 + "#";
                while (res.next()){
                        posizione = calcolaPosizione(res.getString("Magazzino_CodiceCorriere"));
                        str1 =  res.getString("Barcode");
                        
                        str2 = "€" + res.getString("TipoSpedizione") +
                               "€" + res.getString("IndrizzoMag") +
                               "€" + res.getString("Citta") + 
                               "€" + res.getString("CAP") + 
                               "€" + res.getDate("DataInizioServizio") ;
                        
                            //  inserimento dati nell'array
                            if (valAppoggio[posizione] != null) {
                                valAppoggio[posizione]= valAppoggio[posizione] + "$ " + str1 + str2  ;
                                }else {
                                    valAppoggio[posizione]= str1 + str2 ; 
                                    } 
                            }
                for (int i = 0; i<N; i++){
                        if (valAppoggio[i] == null){
                            valAppoggio[i] = " -- ";
                            }
                        logisticadati.aggiungi(valAppoggio[i]);
                        }
                }else {
                        System.out.println("Err ************: non ci sono dati per l'autista " );
                            for (int i = 0; i<N; i++){
                                if (valAppoggio[i] == null){
                                    valAppoggio[i] = " -- ";
                                    }
                                logisticadati.aggiungi(valAppoggio[i]);
                               }
                       }  
            st.close();
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
            throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
        }
    }
    /*****************************************************************************************************************************
     * calcolaPosizione()
     * 
     * metodo che interrroga il DB per individuare la posizione del Magazzino
     * il metodo è richiamato da <<CruscolistaPKfillAutistaBarcodetto>>
     * @param varMag identificativo Magazzino
     * 
     * @return <code>trovato</code> posizione relativa al magazzino richiesto
     * <code>-1</code> altrimenti
     ******************************************************************************************************************************/
    
    public int calcolaPosizione(String varMag){
    String sql;
    int trovato = 0;
    int ris = 0;
    Connection conn = DBConnect.getConnection();
        try {
            Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            sql="SELECT CodiceId, CodiceCorriere FROM magazzino WHERE (Nome <> 'MagazzinoTest') AND (Nome <> 'MagazzinoTest2') Order by CodiceId";
            ResultSet res = st.executeQuery(sql) ;
            if (res.last()) { 
                int N = res.getRow()+1;
                res.beforeFirst();
                int i = 1; 
                while (res.next()){
                        if (res.getString("CodiceCorriere").compareTo(varMag)!= 0){
                            i++;
                        }else {
                            trovato = i;
                            }
                        }
                if (trovato<=N) {
                    ris = trovato;
                    }else{
                        ris = -1;
                        }
                }else {
                    System.out.println("Err ************: non ci sono magazzini " );
                    ris = -1;       
                    }  
            st.close();
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
            throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
            }
        return ris;
    }
}
