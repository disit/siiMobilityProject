/****************************************************** 
 *   Document    : GestioneLogistica
 *   Created on  : 07-02-2017, 12.16.00
 *   Author      : TIME
 ******************************************************/

package GestioneLogistica;
import GestioneLogisticaBean.ListaLogisticaBeanMezzo;
import GestioneLogisticaBean.ListaLogisticaBean;
import GestioneLogistica.GestioneDati;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
    /*****************************************************************************************************************************
     * GestioneDatiRiassegnazione: Classe contenente i metodi necessari alla gestione dei dati per il Cruscotto
     * 
     * 
     ******************************************************************************************************************************/

public class GestioneDatiRiassegnazione {

    /*****************************************************************************************************************************
     * fillListaDatiMezziPadroncini()
     * 
     * metodo che interrroga il DB e riempe il BEAN per la visualizzazione della TabellaAssegnazioni 
     * la prima select è cablata sul codice padroncino ma poi verrà eseguita su un valore passato per paramatro (valoreChiave)
     * @param logisticadati codice incrementale che identifica l'elemento nel DB
     * @result <code> void <code> 
     ******************************************************************************************************************************/
    
    public void fillListaDatiMezziPadroncini(ListaLogisticaBeanMezzo logisticadati ) {
        String sql,sql1;
        
        Connection conn = DBConnect.getConnection();
        try {
            Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            Statement st1 = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            sql = "SELECT PartitaIva, RagioneSociale FROM padroncino_anagrafica";
            ResultSet res = st.executeQuery(sql) ;
            if (res.last())  { 
                int numeroRighe = res.getRow();
                res.beforeFirst();
                while (res.next()){
                    String valoreChiave = res.getString("PartitaIva");
                    String valoreRagSoc = res.getString("RagioneSociale");
                    sql1 = "SELECT CodiceMezzo FROM mezzo_anagrafica WHERE Padroncino_Anagrafica_PartitaIva =" + "'" + valoreChiave + "'";
                    ResultSet res1 = st1.executeQuery(sql1) ;
                    if (res1.last()) { 
                        int numeroRighe1 = res1.getRow();
                        res1.beforeFirst();
                        while (res1.next()){
                            String valoreMezzo = res1.getString("CodiceMezzo");
                            String eliminaTest = res1.getString("CodiceMezzo").toUpperCase();
                                if (!eliminaTest.contains("TEST")){
                                    fillTabellaMezziPadroncini (logisticadati, valoreMezzo, valoreRagSoc, valoreChiave); 
                                }
                            }
                        }else {
                            System.out.println("ERR in fillListaDatiMezziPadroncini: Il padroncino in oggetto non ha nessun mezzo :" + valoreChiave);
                            } 
                    }
                } else {
                        System.out.println("ERR in fillListaDatiMezziPadroncini: Non ci sono pradroncini bel DB" );
                        }   
             st.close();
             st1.close();
             conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
            throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
        }
    }  
    
    
/*****************************************************************************************************************************
     * fillTabellaMezziPadroncini()
     * 
     * metodo che interrroga il DB e riempe il BEAN per la visualizzazione dei colli assegnati ai mezzi 
     * la prima select è cablata sul codice padroncino ma poi verrà eseguita su un valore passato per paramatro (valoreChiave)
     * @param logisticadati Struttura dati
     * @param valoreMezzo codice Mezzi 
     * @param valorePadroncino RagioneSociale del Padroncino
     * @param valoreChiave Partita IVA del Padroncino
     * @result <code> void <code> 
     ******************************************************************************************************************************/
    public void fillTabellaMezziPadroncini (ListaLogisticaBeanMezzo logisticadati, String valoreMezzo, String valorePadroncino, String valoreChiave){
        String sql1,str1,str2,str3,str4;
        int N = 11;
        str3=null;
        String[] valAppoggio;
        Connection conn = DBConnect.getConnection();
         try {
            Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            Statement st1 = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            valAppoggio = new String[N+1];
                   sql1="SELECT BarCode, OraStimata, ZTL, OraConsegnaRichiesta,PesoDichiarato,indirizzoDestinatario,CAPDestinatario FROM riassegnazionecolli WHERE Mezzo_Anagrafica_CodiceMezzo=" + "'" + valoreMezzo + "'" + "  " + "ORDER BY OraStimata";
                    ResultSet res1 = st1.executeQuery(sql1) ;
                    Double ritorno = GestioneDati.getColoreMezzo(valoreMezzo);
                    System.out.println(" STAMPO ritorno: " + ritorno);
                    if (ritorno !=0){   
                        if (ritorno >= 70) {
                                 str3 = "R";
                            }else {
                                if (ritorno >50 && ritorno<70) {
                                    str3 = "G";
                                }else {
                                    if (ritorno <= 50){
                                        str3 = "V";
                                    }
                                }
                            }
                        }else {
                            str3 = "B";
                        }
                    if (res1.last()) { 
                        int numeroRighe = res1.getRow();
                        res1.beforeFirst();
                        valAppoggio[0] = valoreMezzo + "§" + valorePadroncino + "§" + valoreChiave + "#" + str3 + "#" ;
                        while (res1.next()){
                            int posizione;
                            posizione = GestioneDati.controllaOra(res1.getTime("OraStimata"));
                            str1 = GestioneDati.controlloZTL(res1.getString("ZTL"), res1.getTime("OraConsegnaRichiesta"));
                            String strApp = res1.getString("OraConsegnaRichiesta");
                            if (strApp == null){
                                strApp = "nessuna";
                                }
                            str1 = "£" + str1;
                            str2 = "£" + res1.getString("CAPDestinatario") + "€" + res1.getString("indirizzoDestinatario") + "€" +  res1.getString("PesoDichiarato") + "€" +  strApp;
                            str4 = res1.getString("BarCode");
                            if (valAppoggio[posizione] != null) {
                                valAppoggio[posizione]= valAppoggio[posizione] + "$ " +  res1.getString("BarCode") + str1 + str2  ;
                                }else {
                                    valAppoggio[posizione]= res1.getString("BarCode") + str1 + str2 ; 
                                    } 
                            }
                        for (int i = 0; i<N; i++){
                                if (valAppoggio[i] == null){
                                    valAppoggio[i] = " -- ";
                                    }
                                logisticadati.aggiungi(valAppoggio[i]);
                                }
                        }else {
                            System.out.println("ERR in fillTabellaMezziPadroncini: il mezzo in oggetto non ha nessun carico :" + valoreMezzo);
                            valAppoggio[0] = valoreMezzo + " §" + valorePadroncino + "§" + valoreChiave + "#" + null + "#" ;
                            for (int i = 0; i<N; i++){
                                System.out.println("Stampo valore i :" + i);
                                if (valAppoggio[i] == null){
                                    valAppoggio[i] = " -- ";
                                    }
                                logisticadati.aggiungi(valAppoggio[i]);
                                valAppoggio[i]=null;
                                }
                            }
            st.close();
            st1.close();
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
            throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
        }    
    }
    
    
    
/*****************************************************************************************************************************
     * fillDatiSingoloMezzo()
     * 
     * metodo che interrroga il DB e riempe il BEAN per la visualizzazione della TabellaAssegnazioni.
     * 
     * @param logisticadati struttura dati
     * @param valoreChiave codice del Mezzo il cui carico deve essere riassegnato 
     * @result <code> void <code> 
     ******************************************************************************************************************************/
    
    public void fillDatiSingoloMezzo(ListaLogisticaBeanMezzo logisticadati, String valoreChiave) {
        String sql,str1, str2, str3, str4, str5;
        String[] valAppoggio;
        int N = 41;
        Connection conn = DBConnect.getConnection();
         try {
            Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            valAppoggio = new String[N];
            sql="SELECT BarCode, OraStimata, ZTL, OraConsegnaRichiesta,PesoDichiarato,indirizzoDestinatario,CAPDestinatario FROM riassegnazionecolli WHERE Mezzo_Anagrafica_CodiceMezzo=" + "'" + valoreChiave + "'" + "  " + "ORDER BY OraStimata";
            ResultSet res = st.executeQuery(sql) ;
                    
            if (res.last()) { 
                int numeroRighe = res.getRow();
                res.beforeFirst();
                str5 = " Mezzo " + " " + valoreChiave;
                valAppoggio[0] = str5;
                while (res.next()){
                        int posizione;
                        posizione = GestioneDati.controllaOraMin(res.getTime("OraStimata"));
                            str1 = GestioneDati.controlloZTL(res.getString("ZTL"), res.getTime("OraConsegnaRichiesta"));
                            String strApp = res.getString("OraConsegnaRichiesta");
                            if (strApp == null){
                                strApp = "nessuna";
                                }

                            str1 = "£" + str1;
                            str2 = "£" + res.getString("CAPDestinatario") + "€" + res.getString("indirizzoDestinatario") + "€" +  res.getString("PesoDichiarato") + "€" +  strApp;
                            str4 = res.getString("BarCode");
                            if (valAppoggio[posizione] != null) {
                                valAppoggio[posizione]= valAppoggio[posizione] + "$ " + str4  + str1 + str2  ;
                                }else {
                                    valAppoggio[posizione]= str4 + str1 + str2 ; 
                                    } 
                            }
                for (int i = 0; i<N; i++){
                        if (valAppoggio[i] == null){
                            valAppoggio[i] = " -- ";
                            }
                        logisticadati.aggiungi(valAppoggio[i]);
                        valAppoggio[i]=null;
                        }
                }else {
                        System.out.println("Err ************: non ci sono dati per quel mezzo " );
                            for (int i = 0; i<N; i++){
                                if (valAppoggio[i] == null){
                                    valAppoggio[i] = " -- ";
                                    }
                                logisticadati.aggiungi(valAppoggio[i]);
                                valAppoggio[i]=null;
                                }
                        }  
            st.close();
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
            throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
        }
    }
/*****************************************************************************************************************************
     * fillDatiDueMezzi()
     * 
     * metodo che interrroga il DB e riempe il BEAN per la visualizzazione della TabellaAssegnazioni.
     * @param logisticadati codice incrementale che identifica l'elemento nel DB
     * @param valoreChiave codice del Mezzo e numero colonne della tabella
     * @result <code> void <code> 
     ******************************************************************************************************************************/
    
    public void fillDatiDueMezzi(ListaLogisticaBeanMezzo logisticadati, String valoreChiave) {
         String sql,str1, str2, str3, str4, str5;
        String valoreMezzo;
        String[] valAppoggio;
        int N;
         String[] splits =  valoreChiave.split("\\$");
        for(int j=0; j<2;j++ ) {
            Connection conn = DBConnect.getConnection();
            if (j==0){
                N = 41;
            }else {
                N = 11;
             }
            valAppoggio = new String[N];
            
        try {
            Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            valoreMezzo = splits[j];
            str5= valoreMezzo;
            sql="SELECT BarCode, OraStimata, ZTL, OraConsegnaRichiesta,PesoDichiarato,indirizzoDestinatario,CAPDestinatario FROM riassegnazionecolli WHERE Mezzo_Anagrafica_CodiceMezzo=" + "'" + valoreMezzo + "'" + "  " + "ORDER BY OraStimata";
           ResultSet res = st.executeQuery(sql) ;
                    
            if (res.last()) { 
                int numeroRighe = res.getRow();
                res.beforeFirst();
                valAppoggio[0] =  str5;
                while (res.next()){
                        int posizione;
                        if (N==41) {
                            posizione = GestioneDati.controllaOraMin(res.getTime("OraStimata"));
                            }else{
                                posizione = GestioneDati.controllaOra(res.getTime("OraStimata"));
                                }
                        str1 = GestioneDati.controlloZTL(res.getString("ZTL"), res.getTime("OraConsegnaRichiesta"));
                         String strApp = res.getString("OraConsegnaRichiesta");
                        if (strApp == null){
                            strApp = "nessuna";
                            }
                        str1 = "£" + str1;
                        str2 = "£" + res.getString("CAPDestinatario") + "€" + res.getString("indirizzoDestinatario") + "€" +  res.getString("PesoDichiarato") + "€" +  strApp;
                        str4 = res.getString("BarCode");
                        if (valAppoggio[posizione] != null) {
                                valAppoggio[posizione]= valAppoggio[posizione] + "$ " + str4  + str1 + str2  ;
                                }else {
                                    valAppoggio[posizione]= str4 + str1 + str2 ; 
                                    } 
                        }
                for (int i = 0; i<N; i++){
                    if (valAppoggio[i] == null){
                            valAppoggio[i] = " -- ";
                            }
                    logisticadati.aggiungi(valAppoggio[i]);
                    valAppoggio[i]=null;
                    }
             }else {
            System.out.println("Err ************: non ci sono dati per quel mezzo " );
                valAppoggio[0] =  str5;
                for (int i = 0; i<N; i++){
                    if (valAppoggio[i] == null){
                        valAppoggio[i] = " -- ";
                        }
                    logisticadati.aggiungi(valAppoggio[i]);
                    valAppoggio[i]=null;
                    }
               }  
            st.close();
           conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
            throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
        }
        
    }
         
    }

    /*****************************************************************************************************************************
     * fillDatiMezzi()
     * 
     * metodo che interrroga il DB e riempe il BEAN per la visualizzazione della TabellaAssegnazioni senza il mezzo precedententemente selezionato.
     * questo metodo è simile a fillListaDatiMezzi.
     * @param logisticadati 
     * @param valoreChiave codice Padroncino- partitaIVA
     * @param valoreMezzo codice del Mezzo da esculdere dalla lista
     * @param valorePadroncino ragione sociale del Padroncino
     * 
     * @result <code> void <code> 
     * 
     ******************************************************************************************************************************/
    
    public void fillDatiMezzi(ListaLogisticaBeanMezzo logisticadati, String valoreChiave, String valoreMezzo, String valorePadroncino) {
        String sql,sql1,sql2,sql3,str1,str2,str3,str4, str5;
        int N = 11;
        str3=null;
        String[] valAppoggio;
        valAppoggio = new String[N+1];

        Connection conn = DBConnect.getConnection();
        try {
            Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            Statement st1 = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            sql = "SELECT CodiceMezzo FROM mezzo_anagrafica WHERE Padroncino_Anagrafica_PartitaIva =" + "'" + valoreChiave + "'";
            ResultSet res = st.executeQuery(sql) ;
            if (res.last()) { 
                int numeroRighe = res.getRow();
                res.beforeFirst();
                while (res.next()){
                     sql1="SELECT BarCode, OraStimata, ZTL, OraConsegnaRichiesta,PesoDichiarato,indirizzoDestinatario,CAPDestinatario FROM riassegnazionecolli WHERE Mezzo_Anagrafica_CodiceMezzo=" + "'" + res.getString("CodiceMezzo") + "'" + "  " + "ORDER BY OraStimata";
                    ResultSet res1 = st1.executeQuery(sql1) ;
                    if (res.getString("CodiceMezzo").compareTo(valoreMezzo) != 0) {//non devo inserire nella prima tabella i dati del mezzo da riassegnare
                            Double ritorno = GestioneDati.getColoreMezzo(res.getString("CodiceMezzo"));
                            if (ritorno !=0){
                                if (ritorno >= 70) {
                                    str3 = "R";// colore ROSSO
                                }else {
                                    if (ritorno >50 && ritorno<70) {
                                        str3 = "G";// colore  GIALLO
                                    }else {
                                        if (ritorno <= 50){
                                            str3 = "V"; // colore VERDE
                                            }
                                        }
                                    }
                            }else {
                                str3 = "B";
                                }
                        }else {
                            str3 = "N";
                            }
                    str5 = res.getString("CodiceMezzo") + ";" + valorePadroncino + "#" + str3 + "#" ;
                    valAppoggio[0] = str5;
                    if (res1.last()) { 
                         numeroRighe = res1.getRow();
                         res1.beforeFirst();
                        while (res1.next()){
                            int posizione;
                            posizione = GestioneDati.controllaOra(res1.getTime("OraStimata"));
                            str1 = GestioneDati.controlloZTL(res1.getString("ZTL"), res1.getTime("OraConsegnaRichiesta"));
                            String strApp = res1.getString("OraConsegnaRichiesta");
                            if (strApp == null){
                                strApp = "nessuna";
                                }
                            str1 = "£" + str1;
                            str2 = "£" + res1.getString("CAPDestinatario") + "€" + res1.getString("indirizzoDestinatario") + "€" +  res1.getString("PesoDichiarato") + "€" +  strApp;
                            str4 = res1.getString("BarCode");
                            if (valAppoggio[posizione] != null) {
                                valAppoggio[posizione]= valAppoggio[posizione] + "$ " +  str4 + str1 + str2  ;
                                }else {
                                    valAppoggio[posizione]= str4 + str1 + str2 ; 
                                    } 
                            }
                            for (int i = 0; i<N; i++){
                              System.out.println("STAMPO ************ in fillDatiMezzi " + valAppoggio[i]);

                                if (valAppoggio[i] == null){
                                    valAppoggio[i] = " -- ";
                                    }
                                logisticadati.aggiungi(valAppoggio[i]);
                                valAppoggio[i]=null;
                                }
                         }else {
                            System.out.println("STAMPO ERR in fillDatiMezzi ");
                            for (int i = 0; i<N; i++){
                                if (valAppoggio[i] == null){
                                    valAppoggio[i] = " -- ";
                                    }
                                logisticadati.aggiungi(valAppoggio[i]);
                                valAppoggio[i]=null;
                                }
                            }
                        
                        }
            }else {
                        System.out.println("ERR: non ci sono mezzi associati al Padroncino" + valoreChiave);
                        
                        }    
             st.close();
             st1.close();
             conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
            throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
        }
    }
/*****************************************************************************************************************************
     * fillDatiMezzo()
     * 
     * metodo che interrroga il DB e riempe il BEAN per la visualizzazione della TabellaAssegnazioni relativa al singolo mezzo
     * la prima select è cablata sul codice padroncino ma poi verrà eseguita su un valore passato per paramatro (valoreChiave)
     * @param logisticadati 
     * @param valoreChiave codice mezzo
     * @result <code> void <code> 
     ******************************************************************************************************************************/
    
    public void fillDatiMezzo(ListaLogisticaBeanMezzo logisticadati, String valoreChiave) {
        String sql,str1, str2, str3, str4, str5;
        String[] valAppoggio;
        int N = 41;
        Connection conn = DBConnect.getConnection();
        try {
            Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            valAppoggio = new String[41];
            sql="SELECT BarCode, OraStimata, ZTL, OraConsegnaRichiesta,PesoDichiarato,indirizzoDestinatario,CAPDestinatario FROM riassegnazionecolli WHERE Mezzo_Anagrafica_CodiceMezzo=" + "'" + valoreChiave + "'" + "  " + "ORDER BY OraStimata";
            ResultSet res = st.executeQuery(sql) ;
                    
            if (res.last()) { 
                 int numeroRighe = res.getRow();
                res.beforeFirst();
                str5 = " Mezzo " + " " + valoreChiave;
                valAppoggio[0] = " Mezzo " + " " + valoreChiave;
                while (res.next()){
                        int posizione;
                        posizione = GestioneDati.controllaOraMin(res.getTime("OraStimata"));
                        str1 = GestioneDati.controlloZTL(res.getString("ZTL"), res.getTime("OraConsegnaRichiesta"));
                        String strApp = res.getString("OraConsegnaRichiesta");
                        if (strApp == null){
                                strApp = "nessuna";
                                }
                        str1 = "£" + str1;
                        str2 = "£" + res.getString("CAPDestinatario") + "€" + res.getString("indirizzoDestinatario") + "€" +  res.getString("PesoDichiarato") + "€" +  strApp;
                        str4= res.getString("BarCode");
                        if (valAppoggio[posizione] != null) {
                                valAppoggio[posizione]= valAppoggio[posizione] + "$ " +  res.getString("BarCode") + str1 + str2  ;
                                }else {
                                    valAppoggio[posizione]= res.getString("BarCode") + str1 + str2 ; 
                                    } 
                        }
                        for (int i = 0; i<N; i++){
                                if (valAppoggio[i] == null){
                                    valAppoggio[i] = " -- ";
                                    }
                                logisticadati.aggiungi(valAppoggio[i]);
                                valAppoggio[i]=null;
                                }
                }else {
                    System.out.println("ERR: non ci sono colli per quel mezzo :" + valoreChiave);
                    }  
            st.close();
            conn.close();
            } catch (SQLException ex) {
                Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
                throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
                }
    }
  
 
    
     
    

      /*****************************************************************************************************************************
     * riassegnaElemento()
     * 
     * Metodo per riassegnare un nuovo barcode o lista di barcode in una tabella :
     * eseguo un'aggiornamento nella tabella riassegnacolli:  UPDATE riassegnazionecolli SET OraStimata= 'hh:mm:ss' WHERE BarCode= 'xxxxxx'
     * @param CodBarcode codice barcode che si vuol "riassegnare" o lista di barcode separati da ,
     * @param OraStimata nuovo ora relativa all'ora di consegna stimata
     * 
     * 
     * @return <code>true</code> se la modifica è avvenuta con successo,
     * <code>false</code> altrimenti
     ******************************************************************************************************************************/
     public boolean riassegnaElemento( String CodBarcode, String OraStimata) {
        
        if (CodBarcode.trim().length() != 0) {
            Connection conn = DBConnect.getConnection();
            try {
                String[] varAppoggio = CodBarcode.split("\\,");
                
                for (String codiceBarcode : varAppoggio){
                    String sql="";
                    codiceBarcode = codiceBarcode.trim();
                     sql = "UPDATE  riassegnazionecolli SET OraStimata = ? WHERE BarCode = ?";
                   
                    sql=sql.trim();
                    if (sql.length()!=0) {
                        PreparedStatement st = conn.prepareStatement(sql);
                        st.setString(1, OraStimata);
                        st.setString(2, codiceBarcode);
                        int res = st.executeUpdate();
                        if (res != 1) {
                            return false;
                             }
                     st.close();   
                    }
                }
                conn.close();
             } catch (SQLException ex) {
                    Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
                    throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
                    }
            }else {
                return false;
                }
        return true;
        }  
     /*****************************************************************************************************************************
     * riassegnaElementoAltroMezzo()
     * 
     * Metodo per riassegnare un nuovo barcode o lista di barcode in una tabella :
     * eseguo un'aggiornamento nella tabella riassegnacolli: 
     * @param CodMezzo codice mezzo a cui riassegnare il collo,
     * @param CodBarcode codice barcode che si vuol "riassegnare" o lista di barcode separati da ,
     * @param OraStimata nuovo ora relativa all'ora di consegna stimata
     * 
     * 
     * @return <code>true</code> se la modifica è avvenuta con successo,
     * <code>false</code> altrimenti
     ******************************************************************************************************************************/
     public boolean riassegnaElementoAltroMezzo( String CodMezzo, String CodBarcode, String OraStimata) {
        System.out.println("STAMPO valori passati a riassegnaElementoAltroMezzo: " + CodMezzo + " " + CodBarcode + " " + OraStimata);
        if (CodBarcode.trim().length() != 0) {
            Connection conn = DBConnect.getConnection();
            try {
                String[] varAppoggio = CodBarcode.split("\\,");
                for (String codiceBarcode : varAppoggio){
                    String sql="";
                    codiceBarcode = codiceBarcode.trim();
                    sql="UPDATE collo SET OraStimata= ?, Autista_Anagrafica_CodiceAutista= (SELECT CodiceAutista FROM autista_anagrafica WHERE Mezzo_Anagrafica_CodiceMezzo= ?),Autista_Anagrafica_CodiceId=  (SELECT CodiceId FROM autista_anagrafica WHERE Mezzo_Anagrafica_CodiceMezzo= ?) WHERE BarCode= ?";
                    sql=sql.trim();
                    if (sql.length()!=0) {
                        PreparedStatement st = conn.prepareStatement(sql);
                        st.setString(1, OraStimata);
                        st.setString(2, CodMezzo);
                        st.setString(3, CodMezzo);
                        st.setString(4, codiceBarcode);
                        int res = st.executeUpdate();
                        if (res != 1) {
                            return false;
                            }
                     st.close();   
                    }
                }
                conn.close();
             } catch (SQLException ex) {
                    Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
                    throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
                    }
            }else {
                return false;
                }
        return true;
        }
   
     
}