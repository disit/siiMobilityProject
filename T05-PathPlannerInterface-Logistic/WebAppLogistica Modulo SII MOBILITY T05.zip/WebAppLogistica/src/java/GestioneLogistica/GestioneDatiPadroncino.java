/****************************************************** 
 *   Document    : GestioneLogistica
 *   Created on  : 07-02-2017, 12.16.00
 *   Author      : TIME
 ******************************************************/

package GestioneLogistica;

import GestioneLogisticaBean.ListaLogisticaBean;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

    /*****************************************************************************************************************************
     * GestioneDatiPadroncino : Classe contenente i metodi per la gestione dei dati relativi ai Padroncini
     * 
     * 
     ******************************************************************************************************************************/

public class GestioneDatiPadroncino {
    /*****************************************************************************************************************************
     * fillListaDatiPadroncino()
     * 
     * mMtodo che interrroga il DB e riempe il BEAN  dei dati relativi ai padroncini
     * 
     * @param logisticadati struttura per caricare i dati
     * @result <code> void <code> 
     ******************************************************************************************************************************/
     public void fillListaDatiPadroncino(ListaLogisticaBean logisticadati) {
        Connection conn = DBConnect.getConnection();
        try {
            Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "SELECT CodiceId, RagioneSociale, PartitaIva, "
                    + "IndirizzoSedeLegale, "
                    + "Citta,"
                    + "CAP,"
                    + "Provincia,"
                    + "NumeroTelefonico, "
                    + "NumeroFax, "
                    + "DataRegistrazione,"
                    + "DataCancellazione, "
                    + "email, "
                    + "website FROM padroncino_anagrafica ORDER BY CodiceId";
            ResultSet res = st.executeQuery(sql) ;
            if (res.last()) { 
                int numeroRighe = res.getRow();
                res.beforeFirst();
                while (res.next()){
                    String eliminaTest = res.getString("RagioneSociale").toUpperCase();
                    if (!eliminaTest.contains("TEST")){
                        logisticadati.aggiungi(res.getString("CodiceId"));
                        logisticadati.aggiungi(res.getString("RagioneSociale"));
                        logisticadati.aggiungi(res.getString("PartitaIva"));
                        logisticadati.aggiungi(res.getString("IndirizzoSedeLegale"));
                        logisticadati.aggiungi(res.getString("Citta"));
                        logisticadati.aggiungi(res.getString("CAP"));
                        logisticadati.aggiungi(res.getString("Provincia"));
                        logisticadati.aggiungi(res.getString("NumeroTelefonico"));
                        logisticadati.aggiungi(res.getString("NumeroFax"));
                        logisticadati.aggiungi(res.getString("website"));
                        logisticadati.aggiungi(res.getString("email"));
                        logisticadati.aggiungi(res.getString("DataRegistrazione"));
                        logisticadati.aggiungi(res.getString("DataCancellazione"));
                        }
                    }
                }else {
                    System.out.println("ERR: Non sono presenti Padroncini ATTIVI." );
                    }
             st.close();
             conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
            throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
        }
    }
     
}
