/*-- 
    Document    : GestioneLogistica
    Created on  : 07-02-2017, 12.16.00
    Author      : TIME
    Description : Restituisce la connessione al DB
--*/
package GestioneLogistica;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
    /*****************************************************************************************************************************
     * DBConnect : Classe contenente i metodi per la connessione al DB
     * 
     * 
     ******************************************************************************************************************************/

public class DBConnect {
   
/**********************************************************************************************************
 * Restituisce la connessione al DB
 * @author TIME
 * 
 * @return <code>conn</code> connesione al DB,
 * <code>null</code> altrimenti
 **********************************************************************************************************/           
    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.jdbc.Driver") ;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DBConnect.class.getName()).log(Level.INFO, null, ex);
        }
      
        String dburl = "jdbc:mysql://localhost/logistica2?user=root" ; 
        Connection conn = null ;   
        try {
            conn = DriverManager.getConnection(dburl);
        } catch (SQLException ex) {
            Logger.getLogger(DBConnect.class.getName()).log(Level.INFO, null, ex);
        }
        
   
        return conn ;
    }

   
    
}

