/****************************************************** 
 *   Document    : GestioneLogistica
 *   Created on  : 07-02-2017, 12.16.00
 *   Author      : TIME
 ******************************************************/

package GestioneLogistica;
import GestioneLogisticaBean.ListaLogisticaBean;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
  /*****************************************************************************************************************************
     * GestioneDatiCorriere : Classe contenente i metodi per la gestione dei dati relativi ai Corrieri
     * 
     * 
     ******************************************************************************************************************************/

public class GestioneDatiCorriere {

    /*****************************************************************************************************************************
     * fillListaDatiCorriere()
     * 
     * metodo che interrroga il DB e riempe il BEAN  di corrieri ATTIVI
     *  
     * @param logisticadati struttura per caricare i dati
     * @return <code>void<code>
     ******************************************************************************************************************************/
     public void fillListaDatiCorriere(ListaLogisticaBean logisticadati) {
        Connection conn = DBConnect.getConnection();
        try {
            Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "SELECT CodiceId, RagioneSociale, PartitaIVA, IndirizzoSedeLegale, NumeroTelefonicoSedeLegale, NumeroFaxSedeLegale, DataRegistrazione, DataCancellazione, website, email FROM Corriere ORDER BY CodiceId";
 
            ResultSet res = st.executeQuery(sql) ;
            if (res.last()) { 
               int numeroRighe = res.getRow();
                res.beforeFirst();
                while (res.next()){
                    String eliminaTest = res.getString("RagioneSociale").toUpperCase();
                    if (!eliminaTest.contains("TEST")){
                        logisticadati.aggiungi(res.getString("CodiceId"));
                        logisticadati.aggiungi(res.getString("RagioneSociale"));
                        logisticadati.aggiungi(res.getString("PartitaIVA"));
                        logisticadati.aggiungi(res.getString("IndirizzoSedeLegale"));
                        logisticadati.aggiungi(res.getString("NumeroTelefonicoSedeLegale"));
                        logisticadati.aggiungi(res.getString("NumeroFaxSedeLegale"));
                        logisticadati.aggiungi(res.getString("website"));
                        logisticadati.aggiungi(res.getString("email"));
                        logisticadati.aggiungi(res.getString("DataRegistrazione"));
                        logisticadati.aggiungi(res.getString("DataCancellazione"));
                        }
                    }
                }else {
                    System.out.println("ERR: Non sono presenti Corrieri ATTIVI." );
                    }
            st.close();
            conn.close();
            } catch (SQLException ex) {
            Logger.getLogger(GestioneDati.class.getName()).log(Level.SEVERE, null, ex);
            throw new RuntimeException("database error in " + this.getClass().getSimpleName(), ex);
        }
    }
    
}