/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready( function(){
    
    // registrazione degli event handler al caricamendo della pagina
    // registrare sulle caselle di input che l'utente ha scritto qualcosa
    
    $('input[id="PI"]').blur( validatesto ) ;
    $('input[id="RS"]').blur( validatesto ) ;
    $('input[id="ISL"]').blur( validatesto ) ;
    $('input[id="NTSL"]').blur( validatesto ) ;
    $('input[id="NFSL"]').blur( validatesto ) ;
    $('input[id="web"]').blur( validatesto ) ; 
    $('input[id="em"]').blur( validatesto ) ;
    $('form[id="FormAggiungi"]').submit( validaform ) ;
    
} ) ;

/* gestore dell'evento change delle due caselle di testo */
function validatesto() {
    /* this -> nodo DOM della casella di input */
    /* $(this) -> oggetto jQuery relativo a tale casella */
    var contenuto = $(this).val() ;
    
    if( contenuto.length === 0 ) {
        /*p# sta ad indicare il paragrafo */
        $("p#erroriFormAggiungi").text("Il campo "+ $(this).attr("name") +
            " non può essere vuoto") ;
    } else {
        $("p#erroriFormAggiungi").text("") ;
    }
}

/* controlla l'intero form al momento della submission */
function validaform() {
    if( ($('input[name="PI"]').val().trim()).length === 0 ||
        ($('input[name="RS"]').val().trim()).length === 0  ||
        ($('input[name="ISL"]').val().trim()).length === 0  ||
        ($('input[name="NTSL"]').val().trim()).length === 0  ||
        ($('input[name="NFSL"]').val().trim()).length === 0  ||
        ($('input[name="web"]').val().trim()).length === 0  ||
        ($('input[name="em"]').val().trim()).length === 0 ) {
            $("p#erroriFormAggiungi").text("Impossibile inviare il form, campi mancanti") ;
                return false ;
            } else {
                $("p#erroriFormAggiungi").text(" POSSIAMO inserire i dati inviati") ;
                return true ;
                }
        
}


