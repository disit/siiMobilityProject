/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready( function(){
    
    // registrazione degli event handler al caricamendo della pagina
    // registrare sulle caselle di input che l'utente ha scritto qualcosa
    
    $('input[name="NM"]').blur( validatesto ) ;
    $('input[name="INDR"]').blur( validatesto ) ;
    $('input[name="CITTA"]').blur( validatesto ) ;
    $('input[name="CAP"]').blur( validatesto ) ;
    $('input[name="PROV"]').blur( validatesto ) ;
    $('input[name="NTEL"]').blur( validatesto ) ; 
    $('input[name="LAT"]').blur( validatesto ) ;
    $('input[name="LON"]').blur( validatesto ) ;
    $('input[name="NFAX"]').blur( validatesto ) ;
    $('input[name="PIVAC"]').blur( validatesto ) ;
    $('form[name="FormAggiungi"]').submit( validaform ) ;
    
} ) ;

/* gestore dell'evento change delle due caselle di testo */
function validatesto() {
    /* this -> nodo DOM della casella di input */
    /* $(this) -> oggetto jQuery relativo a tale casella */
    var contenuto = $(this).val() ;
    
    if( contenuto.length == 0 ) {
        /*p# sta ad indicare il paragrafo */
        $("p#erroriloginform").text("Il campo "+ $(this).attr("name") +
            " non può essere vuoto") ;
    } else {
        $("p#erroriloginform").text("") ;
    }
}

/* controlla l'intero form al momento della submission */
function validaform() {
   if( $('input[name="NM"]').val().length==0 ||
           $('input[name="INDR"]').val().length==0  ||
           $('input[name="CITTA"]').val().length==0  ||
           $('input[name="CAP"]').val().length==0  ||
           $('input[name="PROV"]').val().length==0  ||
           $('input[name="NTEL"]').val().length==0  ||
           $('input[name="LAT"]').val().length==0  ||
           $('input[name="LON"]').val().length==0  ||
           $('input[name="NFAX"]').val().length==0  ||
           $('input[name="PIVAC"]').val().length==0  ||
           $('input[name="em"]').val().length==0) {
        $("p#erroriloginform").text("Impossibile inviare il form, campi mancanti") ;
        return false ;
        } else {
        $("p#erroriloginform").text("") ;
        return true ;
    }
        
}


