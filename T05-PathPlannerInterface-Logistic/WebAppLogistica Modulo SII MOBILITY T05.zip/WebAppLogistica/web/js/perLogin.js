/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
	// only for demo purposes
	$.validator.setDefaults({
		submitHandler: function() {
			alert("submitted! (skipping validation for cancel button)");
		}
	});

	$().ready(function() {
		$("#form1").validate({
			errorLabelContainer: $("#form1 div.error")
		});

		var container = $('div.container');
		// validate the form when it is submitted
		var validator = $("#form2").validate({
			errorContainer: container,
			errorLabelContainer: $("ol", container),
			wrapper: 'li'
		});

		$(".cancel").click(function() {
			validator.resetForm();
		});
	});


