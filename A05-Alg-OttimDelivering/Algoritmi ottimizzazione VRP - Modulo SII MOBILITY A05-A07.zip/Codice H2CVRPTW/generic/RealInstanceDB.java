package generic;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.logging.Level;
import java.util.logging.Logger;

import generic.IInstance.Cliente;
import generic.IInstance.Route;
import generic.IInstance.Veicolo;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.Vector;

/** 
 * @author Emanuele Guerrazzi
 * Il programma legge da DB tramite XAMPP tutti gli indirizzi relativi ai pacchi, siano essi di origine che di destinazione, e sfrutta i file locali "all_address.txt", "distmatrix.txt", "timematrix.txt" e "coordinate.txt" per ottenere i dati che gli servono.
 * NB: nel caso in cui venisse letto 1 indirizzo non presente prima in "all_address.txt", questo dovrebbe essere aggiunto al file e gli altri 3 ".txt" aggiornati (tutto ci� dovrebbe essere implementato dal metodo "aggiorna_all_address,txt".
 */

public class RealInstanceDB implements IInstance{
	
	File tutti_indirizzi = new File("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstanceDB\\input\\all_address.txt");
	File distanze = new File("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstanceDB\\input\\distmatrix.txt");
	File tempi = new File("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstanceDB\\input\\timematrix.txt");
	File coordinate = new File("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstanceDB\\input\\coordinate.txt");
	int[][] distmat;
	double[][] timemat;
	Vector<Veicolo> vehiclemat;
	Vector<Pacco> packmat;
	Vector<Cliente> custmat;
	final int baseline = 8;	// orario di inizio lavoro
	String[] Origini;
	String[] Destinazioni;
	String[] indirizzi;
	
	public int get_ND(){	// FUNZIONA!
		try{
			Connection conn = DBConnect.getConnection();
			Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			String sql = "SELECT COUNT(*) FROM (SELECT DISTINCT `IndrizzoOriginePacco`,`CittaOriginePacco`,`CAPOriginePacco`,`ProvinciaOriginePacco` FROM `listepacchi` WHERE `IndrizzoOriginePacco` NOT LIKE '%Magazzino%') as A";
			ResultSet res = st.executeQuery(sql);
			res.next();
			int ND = Integer.parseInt(res.getString(1));
			
			if(st != null) st.close();
			if(conn != null) conn.close();	
			
			return ND;
		}catch (SQLException ex) {
			Logger.getLogger(RealInstanceDB.class.getName()).log(Level.SEVERE, null, ex);
			throw new RuntimeException("database error ", ex);
		}
	}
	
	public int get_NC(){	// FUNZIONA!
		try{
			Connection conn = DBConnect.getConnection();
			Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			String sql = "SELECT COUNT(*) FROM (SELECT DISTINCT `IndirizzoDestinazionePacco`,`CittaDestinazionePacco`,`CAPDestinazionePacco`,`ProvinciaDestinazionePacco` FROM `listepacchi` WHERE IndirizzoDestinazionePacco NOT LIKE '%collo%' ) as A";
			ResultSet res = st.executeQuery(sql);
			res.next();
			int ND = Integer.parseInt(res.getString(1));
			return ND;
		}catch (SQLException ex) {
			Logger.getLogger(RealInstanceDB.class.getName()).log(Level.SEVERE, null, ex);
			throw new RuntimeException("database error ", ex);
		}		
	}

	// il metodo legge da DB tutti i nomi dei pacchi
	public String[] getBarcode(){
		try{
			Connection conn = DBConnect.getConnection();
			Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			String sql = "SELECT Barcode FROM listepacchi WHERE Barcode NOT LIKE '%Collo%' ";
			ResultSet res = st.executeQuery(sql);
			int numeroRighe = 0;
			if(res.last()){
				numeroRighe = res.getRow();
			}
			res.beforeFirst();
			String[] nomepacco = new String[numeroRighe];
			int conta_righe = 0;
			while(res.next()){
				nomepacco[conta_righe] = res.getString(1);
				conta_righe++;
			}	
			
			return nomepacco;
		}catch (SQLException ex) {
			Logger.getLogger(RealInstanceDB.class.getName()).log(Level.SEVERE, null, ex);
			throw new RuntimeException("database error ", ex);
		}		
	}
	// il metodo legge da DB tutti i nomi degli indirizzi (origine)
	public String[] getIndirizziOrig(){
		try{
			Connection conn = DBConnect.getConnection();
			Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			String sql1 = "SELECT IndrizzoOriginePacco FROM listepacchi WHERE IndrizzoOriginePacco NOT LIKE '%magazzino%' ";
			ResultSet res1 = st.executeQuery(sql1);
			int numeroRighe = 0;
			if(res1.last()){
				numeroRighe = res1.getRow();
			}
			res1.beforeFirst();
			String[] parte1 = new String[numeroRighe];
			int conta_righe = 0;
			while(res1.next()){
				parte1[conta_righe] = res1.getString(1);
				conta_righe++;
			}
			
			String sql2 = "SELECT CittaOriginePacco FROM listepacchi WHERE CittaOriginePacco NOT LIKE '%magazzino%'  ";
			ResultSet res2 = st.executeQuery(sql2);
			String[] parte2 = new String[numeroRighe];
			conta_righe = 0;
			while(res2.next()){
				parte2[conta_righe] = res2.getString(1);
				conta_righe++;
			}	
			
			String sql3 = "SELECT CAPOriginePacco FROM listepacchi WHERE CAPOriginePacco NOT LIKE '%mag%' ";
			ResultSet res3 = st.executeQuery(sql3);
			String[] parte3 = new String[numeroRighe];
			conta_righe = 0;
			while(res3.next()){
				parte3[conta_righe] = res3.getString(1);
				conta_righe++;
			}	
			
			String sql4 = "SELECT ProvinciaOriginePacco FROM listepacchi WHERE ProvinciaOriginePacco NOT LIKE '%magazzino%' ";
			ResultSet res4 = st.executeQuery(sql4);
			String[] parte4 = new String[numeroRighe];
			conta_righe = 0;
			while(res4.next()){
				parte4[conta_righe] = res4.getString(1);
				conta_righe++;
			}	
			
			String[] indirizziOrigine = new String[numeroRighe];
			for(int i=0;i<numeroRighe;i++){
				indirizziOrigine[i] = parte1[i] + ", "+parte3[i]+" " + parte2[i]+" " + parte4[i]+", Italy";
			}
			
			return indirizziOrigine;
		}catch (SQLException ex){
			Logger.getLogger(RealInstanceDB.class.getName()).log(Level.SEVERE, null, ex);
			throw new RuntimeException("database error ", ex);
		}
	}
	// il metodo legge da DB tutti i nomi degli indirizzi (destinazione)
	public String[] getIndirizziDest(){
		try{
			Connection conn = DBConnect.getConnection();
			Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			String sql1 = "SELECT IndirizzoDestinazionePacco FROM listepacchi WHERE IndirizzoDestinazionePacco NOT LIKE '%Collo%'";
			ResultSet res1 = st.executeQuery(sql1);
			int numeroRighe = 0;
			if(res1.last()){
				numeroRighe = res1.getRow();
			}
			res1.beforeFirst();
			String[] parte1 = new String[numeroRighe];
			int conta_righe = 0;
			while(res1.next()){
				parte1[conta_righe] = res1.getString(1);
				conta_righe++;
			}
			
			String sql2 = "SELECT CittaDestinazionePacco FROM listepacchi WHERE CittaDestinazionePacco NOT LIKE '%Collo%'";
			ResultSet res2 = st.executeQuery(sql2);
			String[] parte2 = new String[numeroRighe];
			conta_righe = 0;
			while(res2.next()){
				parte2[conta_righe] = res2.getString(1);
				conta_righe++;
			}	
			
			String sql3 = "SELECT CAPDestinazionePacco FROM listepacchi WHERE CAPDestinazionePacco NOT LIKE '%Collo%'";
			ResultSet res3 = st.executeQuery(sql3);
			String[] parte3 = new String[numeroRighe];
			conta_righe = 0;
			while(res3.next()){
				parte3[conta_righe] = res3.getString(1);
				conta_righe++;
			}	
			
			String sql4 = "SELECT ProvinciaDestinazionePacco FROM listepacchi WHERE ProvinciaDestinazionePacco NOT LIKE '%Collo%'";
			ResultSet res4 = st.executeQuery(sql4);
			String[] parte4 = new String[numeroRighe];
			conta_righe = 0;
			while(res4.next()){
				parte4[conta_righe] = res4.getString(1);
				conta_righe++;
			}	
			
			String[] indirizzi = new String[numeroRighe];
			for(int i=0;i<numeroRighe;i++){
				indirizzi[i] = parte1[i] + ", "+parte3[i]+" " + parte2[i]+" " + parte4[i]+", Italy";
			}
			
			return indirizzi;
		}catch (SQLException ex){
			Logger.getLogger(RealInstanceDB.class.getName()).log(Level.SEVERE, null, ex);
			throw new RuntimeException("database error ", ex);
		}
	}
	// questo metodo restituisce tutti i diversi indirizzi presente nel DB. Essi alimentano il file all_address.txt sulla cui base vengono generati i file distmatrix.txt e timematrix.txt
	
	public String[] getIndirizzi(){
		Vector<String> indirizzi = new Vector<String>();
		String[] indirizziOrigine = getIndirizziOrig();

		// aggiungo tutti gli indirizzi di origine al vector
		/*for(int i=0;i<indirizziOrigine.length;i++){
			indirizzi.add(indirizziOrigine[i]);
		}*/
		
		indirizzi.addElement(indirizziOrigine[0]);	// caso monodepot

		String[] indirizziDest = getIndirizziDest();

		// aggiungo tutti gli indirizzi di destinazione al vector
		for(int i=0;i<indirizziDest.length;i++){
			indirizzi.add(indirizziDest[i]);
		}

		// togliere eventuali doppioni
		for(int i=0;i<indirizzi.size()-1;i++){
			for(int j=i+1;j<indirizzi.size();j++)
				if(indirizzi.get(j).equals(indirizzi.get(i)) ){
					indirizzi.removeElementAt(j);
					j--;
				}	
		}

		// togliere le parti di test
		for(int i=0;i<indirizzi.size();i++){
			if(indirizzi.get(i).contains("MagazzinoTest") || indirizzi.get(i).contains("ColloTest")){
				indirizzi.removeElementAt(i);
				i--;
			}
		}
		
		String[] indirizzy = new String[indirizzi.size()];
		for(int i=0;i<indirizzi.size();i++){
			indirizzy[i] = indirizzi.get(i);
		}

		return indirizzy;

	}

	public int get_baseline(){return baseline;}
	public int[][] get_distmatrix(){ return this.distmat;}
	public double[][] get_timematrix(){ return this.timemat;}
	public Vector<Veicolo> get_vehiclematrix(){return this.vehiclemat;}
	public Vector<Pacco> get_packagematrix(){ return this.packmat;}
	public Vector<Cliente> get_customermatrix(){return this.custmat;}
	
	public int get_typeInstance(){return 2;}
	public int get_scalatempo(){return 1;}
	public int get_speed(){ return 25; }
	public Vector<Route> get_routes(){return this.get_routes();}
	
	// FUNZIONE DI LETTURA DATI
	public void readData() throws IOException{
		int ND, NC;
		ND = get_ND();
		NC = get_NC();
		
		//int nodi = ND+NC; // quando sar� MD
		int nodi = 1 +NC;	// monodepot
		
		int i,j;
		
		Origini = getIndirizziOrig();
		Destinazioni = getIndirizziDest();
		indirizzi = getIndirizzi();
		
		System.out.println("Ecco gli indirizzi:");
		for(i=0;i<indirizzi.length;i++){
			System.out.println(indirizzi[i]);
		}
		
		// LETTURA DISTMATRIX E TIMEMATRIX
		distmat = new int[nodi][nodi];	// potrebbero esserci alcuni "depot" che sono anche clienti.
		timemat = new double[nodi][nodi];
		
		System.out.println("Nodi = "+nodi);
		
		for(i=0;i<nodi;i++){
			int pos_i = find_position1(indirizzi[i]); // indica di quante righe sotto deve scorrere lo scanner distmatrix.
			for(j=0;j<nodi;j++){
				Scanner distmatrix = new Scanner(distanze);
				Scanner timematrix = new Scanner(tempi);
				
				int pos_j = find_position1(indirizzi[j]); // indica di quante colonne a dx deve scorrere lo scanner distmatrix.								
				int conta_righe = 0;
				int conta_colonne1 = 0;	// vale per distmatrix;
				int conta_colonne2 = 0;	// vale per timematrix;
				
				while(conta_righe<pos_i){
					distmatrix.nextLine();
					timematrix.nextLine();
					conta_righe++;
				}
				
				while(conta_colonne1<pos_j){
					if(distmatrix.hasNextInt()){
						distmatrix.nextInt();
						conta_colonne1++;
					}else distmatrix.next();					
				}
				
				while(conta_colonne2<pos_j){
					if(timematrix.hasNextDouble()){
						timematrix.nextDouble();
						conta_colonne2++;
					}else timematrix.next();					
				}	
				
				// a questo punto dovresti esserti posizionato correttamente
				double beta = 5;		// coefficiente che deve tener conto di carico/scarico, occhio a MIN/S!
				distmat[i][j] = distmatrix.nextInt();
				timemat[i][j] = timematrix.nextDouble()/60 + beta;	// la timematrix deve essere in minuti!
				if(i==j){
					timemat[i][j] = 0;
				}
				
				distmatrix.close();
				timematrix.close();
								
			}
		}
	
		// LETTURA VEHICLEMATRIX
		vehiclemat = new Vector<Veicolo>();
		try{
			Connection conn = DBConnect.getConnection();
			Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			String sql = "SELECT * FROM `listeveicoli`";
			ResultSet res = st.executeQuery(sql);
			
			res.next();
			res.next(); // per evitare i 2 veicoli di test che hanno volume non numerico
			
			while(res.next()){
				Veicolo v = new Veicolo();
				v.ID_veicolo = res.getString(1);
				v.Carburante = res.getString(2);
				v.portata = res.getDouble(3);
				v.capacit� = res.getDouble(4);
				v.ID_autista = res.getString(5);
				vehiclemat.add(v);
			}
			
			
		}catch (SQLException ex) {
			Logger.getLogger(RealInstanceDB.class.getName()).log(Level.SEVERE, null, ex);
			throw new RuntimeException("database error ", ex);
		}
		
		// LETTURA PACKMATRIX
		packmat = new Vector<Pacco>();
		try{
			Connection conn = DBConnect.getConnection();
			Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			String sql = "SELECT * FROM listepacchi";
			ResultSet res = st.executeQuery(sql);
			
			res.next();
			res.next(); // per evitare i 2 pacchi di test che hanno volume non numerico
			
			while(res.next()){
				Pacco p = new Pacco();
				p.Barcode = res.getString(1);
				p.peso = res.getDouble(11);
				String aux_volume = res.getString(12);
				aux_volume = aux_volume.replaceAll(",", ".");
				p.volume = Double.parseDouble(aux_volume);
				String LST_aux = res.getString(13);
				// trasforma orario in un LST
				if(LST_aux == null){ // se � null
					p.LST = 600;		// l'orario � in pratica le 18:00
				}else{					// altrimenti dobbiamo ricavarci l'intero
					String[] parts = LST_aux.split(":");
					String ore = parts[0]; 	  // ore
					String minuti = parts[1]; // minuti
					int aux_ore = (Integer.parseInt(ore)-baseline)*60;
					int aux_minuti = (Integer.parseInt(minuti));
					p.LST = aux_ore + aux_minuti;
				}
				packmat.add(p);
			}
			
			if(conn !=null ) conn.close();
			if(st !=null) st.close();
			
		}catch (SQLException ex) {
			Logger.getLogger(RealInstanceDB.class.getName()).log(Level.SEVERE, null, ex);
			throw new RuntimeException("database error ", ex);
		}	
		int counter = 0; // serve per origini e destinazioni
		for(i=0;i<packmat.size();i++){
			// packmat.get(i).Origine = Origini[counter];	// sbloccare quando introdotto MD
			packmat.get(i).Origine = Origini[0];
			packmat.get(i).Destinazione = Destinazioni[counter];
			counter++;
		}
		
		// LETTURA CUSTMATRIX (si inseriscono solo gli indirizzi di destinazione)
		custmat = new Vector<Cliente>();
		// metti prima la tabella sul DB, poi da qua fai la chiamata a SQL
		// in realt� si fa prima a leggere direttamente da "all_address.txt" ottenuto da "aggiorna_all_address"
		String[] destinazioni = new String[packmat.size()];
		for(i=0;i<destinazioni.length;i++){
			Cliente c = new Cliente();
			destinazioni[i] = packmat.get(i).Destinazione;
			c.indirizzo = destinazioni[i];
			String linea = find_latlon(c.indirizzo,coordinate);
			linea = linea.replaceAll("\\.",",");
			Scanner line = new Scanner(linea);
			line.useDelimiter("\t");
			line.next();	// serve a evitare di prendere l'indirizzo
			while(c.latitudine==0){
				if(line.hasNextDouble()){
					c.latitudine = line.nextDouble();
					//System.out.println("latitudine = "+cliente.latitudine);
				}else{line.next();}
			}
			while(c.longitudine==0){
				if(line.hasNextDouble()){
					c.longitudine = line.nextDouble();
				}else{line.next();}
			}
			custmat.add(c);
			line.close();
		}
		
		//elimina cliente doppioni
		for(i=0;i<custmat.size();i++){
			boolean doppione = false;
			for(j=0;j<i && !doppione;j++){
				if(custmat.get(i).indirizzo.equals(custmat.get(j).indirizzo) ){
					doppione = true;
					custmat.removeElementAt(i);
					i--;
					System.out.println("rimosso");
				}
			}
		}
		
		
		// TEST
		System.out.println("Distmatrix");
		for(i=0;i<distmat.length;i++){
			for(j=0;j<distmat.length;j++){
				System.out.print(distmat[i][j]+" ");
			}
			System.out.println();
		}
		
		System.out.println("Timematrix");
		for(i=0;i<timemat.length;i++){
			for(j=0;j<timemat.length;j++){
				System.out.print(timemat[i][j]+" ");
			}
			System.out.println();
		}
		
		PrintStream vehi = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstanceDB\\output\\vehiclematrix.txt"));
		System.setOut(vehi);
		System.out.println("Vehiclematrix");
		System.out.println("CODICE MEZZO"+"\t TIPO CARBURANTE"+"\t PESO MEZZO"+"\t VOLUME MEZZO"+"\t PADRONCINO ANAGRAFICA");
		for(i=0;i<vehiclemat.size();i++){
			System.out.println(vehiclemat.get(i).ID_veicolo+"\t"+vehiclemat.get(i).Carburante+"\t"+vehiclemat.get(i).portata+"\t"+vehiclemat.get(i).capacit�+"\t"+vehiclemat.get(i).ID_autista);
		}
		System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
		
		// PER I PACCHI TESTA:
		PrintStream pack = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstanceDB\\output\\packmatrix.txt"));
		System.setOut(pack);
		System.out.println("Packagematrix");
		System.out.println("BARCODE"+"\t"+"ORIGINE"+"\t DESTINAZIONE"+"\t PESO"+"\t VOLUME"+"\t LST");
		// - se volume preso correttamente
		// - se orario trasformato correttamente
		// - se origine e destinazioni integrate correttamente
		for(i=0;i<packmat.size();i++){
			System.out.println(packmat.get(i).Barcode+"\t"+packmat.get(i).Origine+"\t"+packmat.get(i).Destinazione+"\t"+packmat.get(i).peso+"\t"+packmat.get(i).volume+"\t"+packmat.get(i).LST);
		}
		System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
		
		//CUSTOMERS
		PrintStream cust = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstanceDB\\output\\custmatrix.txt"));
		System.setOut(cust);
		System.out.println("Custmatrix");
		System.out.println("INDIRIZZO"+"\t LATITUDINE"+"\t LONGITUDINE");
		for(i=0;i<custmat.size();i++){
			System.out.println(custmat.get(i).indirizzo+"\t"+custmat.get(i).latitudine+"\t"+custmat.get(i).longitudine);
		}
		System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
		
	}	
	
	public void aggiorna_all_address(){
		int i;
		System.out.println("Provo a leggere tutti i pacchi di \"listapacchi\" con il metodo");
		String[] nomi_pacchi = getBarcode(); 
		for(i=0;i<nomi_pacchi.length;i++){
			System.out.println("Nome pacco = "+nomi_pacchi[i]);	
		}
		
		String[] indirizzi = getIndirizziDest(); 
		for(i=0;i<indirizzi.length;i++){
			System.out.println("Nome indirizzo = "+indirizzi[i]);	
		}
		
		System.out.println("Scrittura di tutti gli indirizzi (origini e destinazioni)");
		
		String[] all_address = getIndirizzi();
		
		// QUESTA ROBA DEL LOG SERVE PER EVITARE L'OVERWRITING DEL FILE
		
		File tutti_address = new File("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstanceDB\\input\\all_address.txt");
		try{
			if(tutti_address.exists()==false){
				System.out.println("We had to make a new file.");
				tutti_address.createNewFile();
			}
			//PrintWriter out = new PrintWriter(new FileWriter(tutti_address, true));
			PrintWriter out = new PrintWriter(new FileWriter(tutti_address));
			
			// IN REALTA' DOVRAI OTTENERE TUTTI GLI INDIRIZZI CHE ATTUALMENTE NON SONO PRESENTI IN ALL_ADDRESS.TXT, che quindi aggiungerai
						
			for(i=0;i<all_address.length;i++){
				out.println(all_address.length);
			}
			out.close();
		}catch(IOException e){
			System.out.println("COULD NOT LOG!!");
		}
		
		
		int ND = get_ND();
		System.out.println("Numero di magazzini = "+ND);
		
		int NC = get_NC();
		System.out.println("Numero di clienti = "+NC);
		
	}
	
	/*********************************************************/
	/*** IMPLEMENTAZIONE METODI DI SUPPORTO (di IInstance) ***/
	/*********************************************************/
	
	/**
	 * Questo metodo restituisce la linea in cui si trovano latitudine e longitudine
	 * @param indirizzo	� l'indirizzo del cliente
	 * @param coordinate � il file in cui cercare l'indirizzo
	 * @return ritorna la linea in cui si trovano lat e lon dell'indirizzo passato in input
	 */
	public String find_latlon(String indirizzo, File coordinate) throws IOException{
		String line = "ERROR";
		boolean trovato = false;
		Scanner scanner = new Scanner(coordinate);
		while(!trovato){
			String linea = scanner.nextLine();
			Scanner auxlinea = new Scanner(linea);
			auxlinea.useDelimiter("\t");
			String stringa = auxlinea.next();
			if(stringa.equals(indirizzo)){
				trovato = true;
				line = linea;
			}
			auxlinea.close();
		}
		
		scanner.close();
		//System.out.println("line = "+line);
		return line;
	}
	
	// questo metodo trova la posizione dell'indirizzo del cliente dentro al file "all_address.txt"
	public int find_position1(String indirizzo) throws IOException{
		int position = -1;
		boolean trovato = false;
		Scanner input = new Scanner(this.tutti_indirizzi);
		int conta_pos = 0;	// serve a evitare il conflitto con ﻿ 
		while(input.hasNextLine() && !trovato){
			String s = input.nextLine();
			if(s.equals(indirizzo)){
				position = conta_pos;
				trovato = true;
			}else{
				conta_pos++;
			}
		}	
		input.close();
		return position;
	}

	// questo metodo serve per capire la posizione dell'indirizzo nella ATTUALE matrice delle distanze (che � pi� piccola)
	public int find_position2(String indirizzo, String[] indirizzi){
		int position = -1;
		boolean trovato = false;
		
		for(int i=0;i<indirizzi.length&&!trovato;i++){
			if(indirizzo.equals(indirizzi[i])){
				trovato=true;
				position = i;
			}
		}
		return position;
	}
	
	public String[] get_indirizzi(){ return this.indirizzi;	}


	
}
