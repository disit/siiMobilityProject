/***
 * Questo algoritmo risolve il H2CVRPTW, con 1 solo deposito
 */

package generic;

import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Collections;
import java.util.Random;
import java.util.Vector;
import java.util.ArrayList;

import generic.IInstance.Node;
import generic.IInstance.Edge;
import generic.ICore.Soluzione;
import generic.IInstance.Cliente;
import generic.IInstance.Veicolo;
import generic.IInstance.Pacco;;

public class Core implements ICore{
	
	public Soluzione localSearch(Soluzione soluzione, IInstance inst){
		return soluzione;
	}
	
	public void loadProblem(IInstance inst){
		System.out.println((inst.get_NC() + inst.get_ND()));
		
		boolean debug = false;
		int i,j;
		int nodi = inst.get_NC()+inst.get_ND();
		
		if(debug){
			System.out.println("Stampa della matrice delle distanze");
		
			
			for (i = 0; i < nodi; i++) {
				for (j = 0; j < nodi; j++) {
					System.out.print(inst.get_distmatrix()[i][j] + " ");
				}
				System.out.println();
			}
			
			System.out.println("Stampa della matrice dei tempi");
			for (i = 0; i < nodi; i++) {
				for (j = 0; j < nodi; j++) {
					System.out.print(inst.get_timematrix()[i][j] + " ");
				}
				System.out.println();
			}
			
			System.out.println("Stampa della matrice dei veicoli");
			System.out.println("ID_VEICOLO"+"\t"+"ID_AUTISTA"+"\t"+"CARBURANTE"+"\t"+"PORTATA"+"\t"+"CAPACITA'");
			for (i = 0; i < inst.get_vehiclematrix().size(); i++) {
				System.out.print(inst.get_vehiclematrix().get(i).ID_veicolo + "\t" + inst.get_vehiclematrix().get(i).ID_autista + "\t" +inst.get_vehiclematrix().get(i).Carburante + "\t\t"+ inst.get_vehiclematrix().get(i).portata+"\t"+inst.get_vehiclematrix().get(i).capacit�);
				System.out.println();
			}


			System.out.println("Stampa della matrice dei pacchi");
			System.out.println("BARCODE"+"\t"+"ORIGINE"+"\t"+"DESTINAZIONE"+"\t"+"PESO"+"\t"+"VOLUME"+"\t"+"LST");
			for (i = 0; i < inst.get_packagematrix().size(); i++) {
				System.out.print(inst.get_packagematrix().get(i).Barcode + "\t" + inst.get_packagematrix().get(i).Origine + "\t" +inst.get_packagematrix().get(i).Destinazione + "\t"+ inst.get_packagematrix().get(i).peso+"\t"+inst.get_packagematrix().get(i).volume+"\t"+inst.get_packagematrix().get(i).LST);
				System.out.println();
			}
			System.out.println("Stampa della matrice dei clienti");
			System.out.println("INDIRIZZO"+"\t"+"LATITUDINE"+"\t"+"LONGITUDINE");
			for (i = 0; i < inst.get_customermatrix().size(); i++) {
				System.out.print(inst.get_customermatrix().get(i).indirizzo + "\t" + inst.get_customermatrix().get(i).latitudine + "\t" +inst.get_customermatrix().get(i).longitudine);
				System.out.println();
			}
		} // fine if(debug)
		
	}
	
	public Soluzione solveProblem(IInstance inst) throws IOException{
		Soluzione soluzione = new Soluzione();
		soluzione.elementi = new Vector<Elemento_soluzione>();
		Vector<Vector<Cliente>> ClusterSet = clustering(inst);
		heterogeneous_assignment(ClusterSet, soluzione, inst);
		calcola_funzione_obiettivo(soluzione,inst);	
		return soluzione;
	}
	
	public void printSolution(Soluzione soluzione, IInstance inst){
		int i,j;
		// qua si riporta tutto alla scala naturale (min) per facilitare le successive stampe
		for(i=0;i<soluzione.elementi.size();i++){
			for(j=0;j<soluzione.elementi.get(i).pacchi_assegnati.size();j++){
				soluzione.elementi.get(i).pacchi_assegnati.get(j).LST *= inst.get_scalatempo();
				soluzione.elementi.get(i).pacchi_assegnati.get(j).ora_arrivo_stimata *= inst.get_scalatempo();
			}
		}
		
		System.out.println("Sono stati impiegati "+soluzione.elementi.size()+" veicoli");
		System.out.println("La distanza percorsa � di "+soluzione.funzione_obiettivo +" metri");
		System.out.println("Dettagli su ciascun veicolo:");
		for(i=0;i<soluzione.elementi.size();i++){
			System.out.println("Veicolo utilizzato: "+soluzione.elementi.get(i).veicolo_usato.ID_veicolo);
			System.out.println("Alimentazione: "+soluzione.elementi.get(i).veicolo_usato.Carburante);
			System.out.println("Autista: "+soluzione.elementi.get(i).veicolo_usato.ID_autista);
			System.out.println("Capacit� utile:"+soluzione.elementi.get(i).veicolo_usato.capacit�);
			System.out.println("Portata utile:"+soluzione.elementi.get(i).veicolo_usato.portata);
			System.out.println("Pacchi assegnati:");
			System.out.println("BARCODE" + "\t" + "ORIGINE"+"\t"+"DESTINAZIONE"+"\t"+"PESO"+"\t"+"VOLUME"+"\t"+"LST"+"\t"+"ORARIO STIMATO");
			for(j=0;j<soluzione.elementi.get(i).pacchi_assegnati.size();j++){	// si evita di stampare i pacchi fittizi, anche se in multidepot ci servir� stampare il deposito di ritorno
				int ora_LST = (int) (inst.get_baseline() + soluzione.elementi.get(i).pacchi_assegnati.get(j).LST/60);
				int aux_minuti_LST = (int) (soluzione.elementi.get(i).pacchi_assegnati.get(j).LST % 60);
				String minuti_LST;
				if(aux_minuti_LST>=10){
					minuti_LST = String.valueOf(aux_minuti_LST);
				}else{minuti_LST = "0"+String.valueOf(aux_minuti_LST);}
				
				int ora = (int) (inst.get_baseline() + soluzione.elementi.get(i).pacchi_assegnati.get(j).ora_arrivo_stimata/60);
				int aux_minuti = (int) (soluzione.elementi.get(i).pacchi_assegnati.get(j).ora_arrivo_stimata % 60);
				String minuti;
				if(aux_minuti>=10){
					minuti = String.valueOf(aux_minuti);
				}else{minuti = "0"+String.valueOf(aux_minuti);}
				
				System.out.println(soluzione.elementi.get(i).pacchi_assegnati.get(j).Barcode + "\t" +soluzione.elementi.get(i).pacchi_assegnati.get(j).Origine +"\t"+soluzione.elementi.get(i).pacchi_assegnati.get(j).Destinazione+"\t"+soluzione.elementi.get(i).pacchi_assegnati.get(j).peso+"\t"+soluzione.elementi.get(i).pacchi_assegnati.get(j).volume+"\t"+ora_LST+":"+minuti_LST+"\t"+ora+":"+minuti);
			}
			calcola_tempo_percorrenza(soluzione.elementi.get(i));
		}
	}
	
	/*** CLUSTERING 
	 * Viene effettuato il clustering dei clienti. Per prima cosa viene applicato l'algoritmodi PRIM
	 ***/
	public Vector<Vector<Cliente>> clustering(IInstance inst) throws IOException{
		double costo_min_span_tree = Prim(inst);
		System.out.println(costo_min_span_tree);
		double alpha = 2;	// coefficiente moltiplicativo (>=1)
		int K = (int) Math.ceil(((costo_min_span_tree * alpha)/(inst.get_speed()/3.6))/(36000));	// numero di cluster da passare a K-Means. Si divide per 3.6 per passare da km/h a m/s, dopodich� si divide per 36000 che corrisponde al time-span, ovvero ai secondi presenti nelle 10 ori corrispondenti alla giornata lavorativa
		System.out.println("K-Means lavora con "+K+" cluster");
		Vector<Vector<Cliente>> ClusterSet = new Vector<Vector<Cliente>>();
		Vector<Cliente> Lista_Clienti = new Vector<Cliente>();
		Lista_Clienti = inst.get_customermatrix();
		KMeans cluster = new KMeans(); 
		cluster.initialize(K,Lista_Clienti);
		ClusterSet = cluster.kMeanCluster(K,Lista_Clienti,inst.get_typeInstance());
		int i,j;
		for(i=0;i<ClusterSet.size();i++){
			for(j=0;j<ClusterSet.get(i).size();j++){
				nearest_neighbor_distandtime(ClusterSet.get(i),inst);
			}
			if(inst.get_typeInstance()==0){				// trova il modo di farlo girare una volta sola!
				remove_duplicate(ClusterSet.get(i));
				remove_duplicate(ClusterSet.get(i));
				remove_duplicate(ClusterSet.get(i));
			}
		}
		
		boolean debug = true;
		if(debug){
			StampaCluster(inst,ClusterSet);
		}
		
		return ClusterSet;
		
	}

	public void heterogeneous_assignment(Vector<Vector<Cliente>> ClusterSet, Soluzione soluzione, IInstance inst) throws IOException{
		order_vehicles(inst);
		assign_packages(ClusterSet, soluzione, inst);
		if(!check_times(soluzione)){
			System.out.println("errore");
		}
	}
	
	/**************************/
	/*** METODI DI SUPPORTO ***/
	/**************************/
	
	/*** METODI PER CLUSTERING ***/

	/**
	 * Algoritmo Di Prim
	 * @param inst
	 * @return Ritorna il costo dell'albero di copertura di costo minimo
	 * @throws IOException
	 */
	public double Prim(IInstance inst) throws IOException{
		double cost = 0;
		// ricorda che in un grafo connesso (come quello di lista_clienti) di n nodi l'albero di copertura ha esattamente n-1 archi e almeno 2 foglie. una foglia � un nodo del grafo di grado 1, ovvero nel quale incide 1 solo arco.
		Vector<Node> V1 = new Vector<Node>();
		Vector<Node> V2 = new Vector<Node>();

		// V1 e V2 mi forniscono un taglio del grafo dato dai nodi "lista_clienti" e tutti i suoi archi. Il taglio consiste nel fatto che i nodi di V1 non stanno in V2 e viceversa, e che V1 U V2 = lista_clienti.
		System.out.println("Il numero di clienti (distinti) �: "+inst.get_customermatrix().size());
		int i;
		int pos;

		for(i=0;i<inst.get_customermatrix().size();i++) {
			Node nodo = new Node();
			nodo.ID_node = inst.find_position1(inst.get_customermatrix().get(i).indirizzo);
			pos = (inst.get_customermatrix().size()-1)*i;
			nodo.pos_arco = pos;
			V2.add(nodo);
		}

		Vector<Edge> lati = new Vector <Edge>();
		int num_lati = inst.get_customermatrix().size()*(inst.get_customermatrix().size()-1);		// uso doppi grafi, a mo di multigrafo
		System.out.println("Il numero di lati �: "+num_lati);

		int conta_node = 0;
		int j=0;
		i=0;

		while(lati.size()<num_lati) {
			j++;
			if(j>=inst.get_customermatrix().size()) {
				conta_node++;
				j=0;
			}

			if( V2.get(conta_node).ID_node!=V2.get(j).ID_node) {
				Edge arco = new Edge();
				arco.ID_arco = i;
				arco.coda = V2.get(conta_node).ID_node;
				arco.testa = V2.get(j).ID_node;
				arco.costo = inst.get_distmatrix()[arco.coda][arco.testa];
				lati.add(arco);
				i++;
			}
		}

		V1.addElement(V2.firstElement());	// inizializzo V1 con il primo cliente nella lista
		V2.remove(V2.firstElement());

		Vector<Edge> albero = new Vector<Edge>();

		while(V1.size()<inst.get_customermatrix().size() ) {
			Vector<Edge> stella = new Vector<Edge>(); // find the star of the endpoints of V1
			for(i=0;i<V1.size();i++) {		// esploro la parte di nodi gi� inseriti per trovare la stella delle foglie di V1
				boolean cambia = false;
				for(j=V1.get(i).pos_arco;j<lati.size() && !cambia && V1.get(i).pos_arco>-1 ;j++) { // al fine di identificarvi gli archi che fanno parte della stella. Tali archi li trovo andando a vedere "lati"
					if(lati.get(j).coda!=V1.get(i).ID_node) {
						cambia=true;
					}else {
						boolean ciclo = false;
						for(int k=0;k<V1.size() && !ciclo;k++) {
							if(lati.get(j).testa==V1.get(k).ID_node)
								ciclo = true;
						}
						if(!ciclo) {
							stella.add(lati.get(j));
						}
					}
				}
			}

			// sort it in a crescent order
			Collections.sort(stella, new Edge());

			// pick the first
			albero.add(stella.firstElement());
			// check if it forms a cycle	(non dovrebbe essere necessario)
			// if yes, pick the following one
			// if no, add it to V1
			boolean coda = true;
			boolean testa = true;
			for(int k=0;k<V1.size();k++) {
				if(stella.firstElement().coda==V1.get(k).ID_node)
					coda = false;
				if(stella.firstElement().testa==V1.get(k).ID_node)
					testa = false;
			}

			int pos_add = -1;
			boolean trovato = false;

			if(coda) {		// cerca in V2 il nodo con ID_node = coda, e aggiungi tale nodo
				for(int k=0;k<V2.size() && !trovato;k++) {
					if(stella.firstElement().coda == V2.get(k).ID_node) {
						trovato = true;
						pos_add = k;
					}
				}
			}else if(testa) {
				for(int k=0;k<V2.size() && !trovato;k++) {
					if(stella.firstElement().testa == V2.get(k).ID_node) {
						trovato = true;
						pos_add = k;
					}
				}
			}
			if(pos_add!=-1) {
				V1.add(V2.get(pos_add));
				V2.remove(pos_add);						// remove it in V2
			}else System.out.println("Errore 00");

		}

		for(i=0;i<albero.size();i++) {
			cost += albero.get(i).costo;
		}

		/*
		System.out.println("L'albero di copertura di costo minimo � dato dai seguenti lati:");
		for(i=0;i<albero.size();i++) {
			System.out.println("("+albero.get(i).coda+","+albero.get(i).testa+")");
		}
		*/
		System.out.println("Minimum Spanning Tree cost: "+cost);

		//System.out.println("V1 size: "+V1.size());
		//System.out.println("V2 size: "+V2.size());

		return cost;
	}
		
	/**
	 * K-Means: famoso algoritmo per ottenere K cluster basati su distanza
	 * @author pc -> Lo hai preso su Internet (trova fonte) e lo hai cambiati
	 *
	 */
	
	public class KMeans
	{
	    private ArrayList<Data> dataSet = new ArrayList<Data>();
	    private ArrayList<Centroid> centroids = new ArrayList<Centroid>();
	    
	  //getting the maximum value
	    public double getMaxValue(double[] array){
	     double maxValue = array[0];
	     for (int i = 1; i < array.length; i++) {
	         if (array[i] > maxValue) {
	             maxValue = array[i];
	         }
	     }
	     return maxValue;
	    }

	    //getting the miniumum value
	    public double getMinValue(double[] array) {
	     double minValue = array[0];
	     for (int i = 1; i < array.length; i++) {
	         if (array[i] < minValue) {
	             minValue = array[i];
	         }
	     }
	     return minValue;
	    }
	    
	    public void initialize(int ncl, Vector<Cliente> cust)		// ho ncl cluster inizializzati in modo random
	    {	
	    	long seed = 10;
	    	
	    	double[] coorx = new double[cust.size()];
	    	double[] coory = new double[cust.size()];
	    	for(int i=0;i<cust.size();i++) {
	    		coorx[i] = cust.get(i).latitudine;
	    		coory[i] = cust.get(i).longitudine;
	    	}
	    	
	        for(int i=0;i<ncl;i++) {
	        centroids.add(new Centroid(randDouble(getMinValue(coorx), getMaxValue(coorx), seed), randDouble(getMinValue(coory), getMaxValue(coory), seed))); 
	        seed += 37;
	        }
	        return;
	    }
	    
	    public Vector<Vector<Cliente>> kMeanCluster(int ncl, Vector<Cliente> cust, int type)
	    {	
	    	
	    	Vector<Vector<Cliente>> ClusterSet = new Vector<Vector<Cliente>>();
	    	
	        final double bigNumber = Math.pow(10, 10);    // some big number that's sure to be larger than our data range.
	        double minimum = bigNumber;                   // The minimum value to beat. 
	        double distance = 0.0;                        // The current minimum value.
	        int sampleNumber = 0;
	        int cluster = 0;
	        boolean isStillMoving = true;
	        Data newData = null;
	        double[] coorx = new double[cust.size()];
	    	double[] coory = new double[cust.size()];
	    	String[] address = new String[cust.size()];
	    	for(int i=0;i<cust.size();i++) {
	    		coorx[i] = cust.get(i).latitudine;
	    		//System.out.println("Coor x"+coorx[i]);
	    		coory[i] = cust.get(i).longitudine;
	    		// System.out.println("Coor y"+coory[i]);
	    		address[i] = cust.get(i).indirizzo;
	    	}
	        
	        // Add in new data, one at a time, recalculating centroids with each new one. 
	        while(dataSet.size() < cust.size())
	        {
	            newData = new Data(coorx[sampleNumber], coory[sampleNumber], address[sampleNumber]);
	            dataSet.add(newData);
	            minimum = bigNumber;
	            for(int i = 0; i < ncl; i++)
	            {	
	            	if(type==0){
	            		distance = distMan(newData, centroids.get(i));
	            	}else{
	            		distance = distEuc(newData, centroids.get(i));
	            	}
	                if(distance < minimum){
	                    minimum = distance;
	                    cluster = i;
	                }
	            }
	            newData.cluster(cluster);
	            
	            // calculate new centroids.
	            for(int i = 0; i < ncl; i++)
	            {
	                double totalX = 0;
	                double totalY = 0;
	                int totalInCluster = 0;
	                for(int j = 0; j < dataSet.size(); j++)
	                {
	                    if(dataSet.get(j).cluster() == i){
	                        totalX += dataSet.get(j).X();
	                        totalY += dataSet.get(j).Y();
	                        totalInCluster++;
	                    }
	                }
	                if(totalInCluster > 0){
	                    centroids.get(i).X(totalX / totalInCluster);
	                    centroids.get(i).Y(totalY / totalInCluster);
	                }
	            }
	            sampleNumber++;
	        }
	        
	        // Now, keep shifting centroids until equilibrium occurs.
	        while(isStillMoving)
	        {
	            // calculate new centroids.
	            for(int i = 0; i < ncl; i++)
	            {
	                double totalX = 0;
	                double totalY = 0;
	                int totalInCluster = 0;
	                for(int j = 0; j < dataSet.size(); j++)
	                {
	                    if(dataSet.get(j).cluster() == i){
	                        totalX += dataSet.get(j).X();
	                        totalY += dataSet.get(j).Y();
	                        totalInCluster++;
	                    }
	                }
	                if(totalInCluster > 0){
	                    centroids.get(i).X(totalX / totalInCluster);
	                    centroids.get(i).Y(totalY / totalInCluster);
	                }
	            }
	            
	            // Assign all data to the new centroids
	            isStillMoving = false;
	            
	            for(int i = 0; i < dataSet.size(); i++)
	            {
	                Data tempData = dataSet.get(i);
	                minimum = bigNumber;
	                for(int j = 0; j < ncl; j++)
	                {                
	                	if(type==0){
	                	distance = distMan(tempData, centroids.get(j));
	                	}else{
	                		distance = distEuc(tempData, centroids.get(j));
	                	}
	                    if(distance < minimum){
	                        minimum = distance;
	                        cluster = j;
	                    }
	                }
	                tempData.cluster(cluster);
	                if(tempData.cluster() != cluster){
	                    tempData.cluster(cluster);
	                    isStillMoving = true;
	                }
	            }
	        }
	        
	        // Print out clustering results.
	        for(int i = 0; i < ncl; i++)				
	        {	
	        	Vector<Cliente> kluster = new Vector<Cliente>();
	           // System.out.println("Cluster " + i + " includes:");
	            for(int j = 0; j < coorx.length; j++)
	            {
	                if(dataSet.get(j).cluster() == i){
	                	Cliente customer = new Cliente();
	                    //System.out.println("     (" + dataSet.get(j).X() + ", " + dataSet.get(j).Y() + ")");
	                    customer.latitudine = (double) dataSet.get(j).X();
	                    customer.longitudine = (double) dataSet.get(j).Y();
	                    customer.indirizzo = dataSet.get(j).address;
	                    kluster.add(customer);
	                }
	            } // j
	           // System.out.println();
	            
	            // qua devo pushare un vector che contiene tot oggetti Customer all'interno del vector Cluster. Tale vector costituisce un cluster
	            ClusterSet.add(kluster);
	            
	        } // i
	        
	        // Print out centroid results.
	        //System.out.println("Centroids finalized at:");
	        for(int i = 0; i < ncl; i++)
	        {
	      //      System.out.println("     (" + centroids.get(i).X() + ", " + centroids.get(i).Y() + ")");
	        }
	       // System.out.print("\n");
	        
	        return ClusterSet;
	    }
	    
	    /**
	     * // Calculate Euclidean distance.
	     * @param d - Data object.
	     * @param c - Centroid object.
	     * @return - double value.
	     */
	    public double distEuc(Data d, Centroid c)
	    {
	        return Math.sqrt(Math.pow((c.Y() - d.Y()), 2) + Math.pow((c.X() - d.X()), 2));
	    }
	    
	    /**
	     * // Calculate Manhattan distance.
	     * @param d - Data object.
	     * @param c - Centroid object.
	     * @return - double value.
	     */
	    public double distMan(Data d, Centroid c)
	    {       
	        return  Math.abs(c.Y()-d.Y())+Math.abs(c.X()-d.X());
	    }
	    
	    public class Data
	    {
	        public double mX = 0;
	        public double mY = 0;
	        public String address = "0";
	        public int mCluster = 0;
	        
	        public Data()
	        {
	            return;
	        }
	        
	        public Data(double x, double y, String address)
	        {
	            this.X(x);
	            this.Y(y);
	            this.address(address);
	            return;
	        }
	        
	        public void X(double x)
	        {
	            this.mX = x;
	            return;
	        }
	        
	        public double X()
	        {
	            return this.mX;
	        }
	        
	        public void Y(double y)
	        {
	            this.mY = y;
	            return;
	        }
	        
	        public double Y()
	        {
	            return this.mY;
	        }
	        
	        public void address(String address)
	        {
	            this.address = address;
	            return;
	        }
	        
	        public String address()
	        {
	            return this.address;
	        }
	        
	        public void cluster(int clusterNumber)
	        {
	            this.mCluster = clusterNumber;
	            return;
	        }
	        
	        public int cluster()
	        {
	            return this.mCluster;
	        }
	    }
	    
	    private class Centroid
	    {
	        private double mX = 0.0;
	        private double mY = 0.0;
	        
	        public Centroid()
	        {
	            return;
	        }
	        
	        public Centroid(double newX, double newY)
	        {
	            this.mX = newX;
	            this.mY = newY;
	            return;
	        }
	        
	        public void X(double newX)
	        {
	            this.mX = newX;
	            return;
	        }
	        
	        public double X()
	        {
	            return this.mX;
	        }
	        
	        public void Y(double newY)
	        {
	            this.mY = newY;
	            return;
	        }
	        
	        public double Y()
	        {
	            return this.mY;
	        }
	    }
	}

	/*
	 * Metodo che elimina i doppioni interni ad un cluster. Viene usato se l'istanza � di Manhattan.
	 */
	
	public void remove_duplicate(Vector<Cliente> cluster) {
		for(int i=0; i<cluster.size();i++) {
			for(int j=0;j<cluster.size() && i!=j && i<cluster.size();j++) {
				if(cluster.get(i).indirizzo.equals(cluster.get(j).indirizzo)) {
					System.out.println("Ho eliminato il cliente "+cluster.get(j).indirizzo);
					cluster.remove(j);
				}
			}
		}
	}
	

	/**
	 * Metodo che serve a ordinare (prioritizzare) i clienti all'interno di un cluster secondo una metrica spazio temporale
	 */
	
	//public void nearest_neighbor_distandtime(Vector<Cliente> cluster, int[][] distmat, Vector<Pacco> transpmatrix, int N) throws IOException {	// N � il numero di magazzini
	public void nearest_neighbor_distandtime(Vector<Cliente> cluster, IInstance inst) throws IOException {	// N � il numero di magazzini
		double min_value = 999999;
		int min_pos = -1;
		double value = 999999;
		double k1 = 0.333;
		double k2 = 1;
		double addendo1, addendo2;
		
		int i,j;
		int max_dist = -1;
		for(i=0;i<inst.get_distmatrix().length;i++){
			for(j=0;j<inst.get_distmatrix().length;j++){
				if(inst.get_distmatrix()[i][j]>max_dist)
					max_dist = inst.get_distmatrix()[i][j];
			}
		}
		
		for(i=0;i<cluster.size();i++) {		// qua si esplorano tutti gli elementi del cluster, cercando quello pi� vicino al magazzino
			int position = inst.find_position1(cluster.get(i).indirizzo);
			//System.out.println(cluster.get(i).indirizzo);
			if(i==0){
				position =0;
			}
			addendo1 = k1*(( (double) inst.get_distmatrix()[0][position] / max_dist));		// ok
			//System.out.println("Addendo 1 del cliente ID "+cluster.get(i).cliente_ID+ "� "+ addendo1);
			
			// ricerca della riga in transpmatrix
			int pos_transpmatrix = -1;
			boolean trovato = false;
			//System.out.println("STAMPE DEBUG");
			for(int t=0; t<inst.get_packagematrix().size() && !trovato; t++) {
				if(inst.get_packagematrix().get(t).Destinazione.equals(cluster.get(i).indirizzo)) {	// vedo qual � l'elemento di transpmatrix che ci serve, ovvero quello corrispondente all'elemento del cluster osservato
					// transpmatrix ha gli address 
					trovato = true;
					pos_transpmatrix = t;
				}
			}
			
			addendo2 = k2 * (( (double)inst.get_packagematrix().get(pos_transpmatrix).LST/( (double) (600/inst.get_scalatempo()))));
			//System.out.println("Addendo 2 del cliente ID "+cluster.get(i).cliente_ID+ "� "+ addendo2);
			value = addendo1  + addendo2;	// il magazzino si trova in posizione 0
			
			if(value < min_value) {
				min_value = value;
				min_pos = i;
			}
		}
		
		// System.out.println("min_pos = "+min_pos);
		
		// System.out.println("Prova: "+600/scala_tempo); stampa 60 regolare
		
		//System.out.println("Min value = "+min_value+" presso il cliente ID "+cluster.get(min_pos).cliente_ID);
		// a questo punto l'elemento min_pos � il primo.
		Collections.swap(cluster,0,min_pos);	// metto in posizione 0 l'elemento che si trova in min_pos		
		
		// adesso ho il primo elemento da visitare del cluster. L'elemento successivo � quello pi� vicino al primo
		
		for(i=1;i<cluster.size();i++) {		// questo serve per le posizioni
			min_value = 999999;
			int position1 = inst.find_position1(cluster.get(i-1).indirizzo);
			for(j=i; j<cluster.size();j++) {// questo serve per considerare la distanza effettiva
				int position2 = inst.find_position1(cluster.get(j).indirizzo);
				addendo1 = k1*(((double) inst.get_distmatrix()[position1][position2]/max_dist));
				//System.out.println("Addendo 1 = "+min_value+" presso il cliente ID "+cluster.get(min_pos).cliente_ID);
				int pos_transpmatrix = -1;
				boolean trovato = false;
				for(int t=0; t<inst.get_packagematrix().size() && !trovato; t++) {
					if(inst.get_packagematrix().get(t).Destinazione.equals(cluster.get(i).indirizzo)) {	// vedo in quale riga di transpmatrix la destinazione corrisponde all'ID del cliente i-esimo del cluster
						trovato = true;
						pos_transpmatrix = t;
					}
				}
				
				addendo2 = k2 * (( (double) inst.get_packagematrix().get(pos_transpmatrix).LST/( (double) (600/inst.get_scalatempo()))));
				value = addendo1 + addendo2;
				if(value < min_value) {
					min_value = value;
					min_pos = j;
				}
			}
			//System.out.println("Min value = "+min_value+" presso il cliente ID "+cluster.get(min_pos).cliente_ID);
			Collections.swap(cluster, i, min_pos);
		}
		
		return;
	}

	public void StampaCluster(IInstance inst, Vector<Vector<Cliente>> ClusterSet) throws IOException{
		PrintStream OutputCluster;
		if(inst.get_typeInstance()==0){
			OutputCluster = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\output\\cluster.txt"));
		}else{
			OutputCluster = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstance\\output\\cluster.txt"));
		}
		System.setOut(OutputCluster);
		for (int z = 0; z < ClusterSet.size(); z++) {
			System.out.println("Stampa del cluster "+z+" ordinato");
			System.out.println("ID \t Coor_X \t Coor_Y");
			for (int g = 0; g < ClusterSet.get(z).size(); g++) {
				System.out.println(ClusterSet.get(z).get(g).indirizzo + "\t" + ClusterSet.get(z).get(g).latitudine
						+ "\t \t" + ClusterSet.get(z).get(g).longitudine);
			}
		}
		System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
	}
	
	/**
	 * Restituisce un numero reale compreso tra min e max
	 */
	
	public double randDouble(double min, double max, long seed) {
		Random rand = new Random(seed);
		double randomNum = min + (max - min) * rand.nextDouble();
		return randomNum;
	}
	
	/*** METODI PER ETEROGENEO ***/
	/**
	 * Questo metodo ordina i veicoli disponibili in senso crescente di inquinamento e, a parit� di inquinamento, in senso decrescente di capacit�.
	 */
	public void order_vehicles(IInstance inst){
		// prendi la vehiclematrix di inst e ordinala per inquinamento crescente (riconoscerai in tutte le tipologie di istanza il carburante benzina, metano ecc.)
		// a parit� di inquinamenti ordini per capacit� decrescente
		/*
		int i;
		System.out.println("Prova");
		for(i=0;i<inst.get_vehiclematrix().size();i++){
			System.out.println("Veicolo "+i+" ="+inst.get_vehiclematrix().get(i).ID_veicolo+"\t"+inst.get_vehiclematrix().get(i).Carburante+"\t"+inst.get_vehiclematrix().get(i).capacit�);
		}*/
		
		Collections.sort(inst.get_vehiclematrix(),new Veicolo());
		/*System.out.println("After sorting");
		
		for(i=0;i<inst.get_vehiclematrix().size();i++){
			System.out.println("Veicolo "+i+" ="+inst.get_vehiclematrix().get(i).ID_veicolo+"\t"+inst.get_vehiclematrix().get(i).Carburante+"\t"+inst.get_vehiclematrix().get(i).capacit�);
		}
		*/
		
	}
	
	public void assign_packages(Vector<Vector<Cliente>> ClusterSet, Soluzione soluzione, IInstance inst) throws IOException{
		int i;
		
		/** INIZIALIZZAZIONE DEI PRIMI NCL VEICOLI **/
		for(i=0;i<ClusterSet.size();i++){	// creo un numero di veicoli pari al numero di cluster
			Elemento_soluzione e = new Elemento_soluzione(); // per ogni cluster inizializzo un veicolo da inserire in soluzione
			e.veicolo_usato = new Veicolo();
			e.veicolo_usato = inst.get_vehiclematrix().firstElement();
			inst.get_vehiclematrix().remove(0);		// rimuovo il primo elemento, che ho appena aggiunto in e
			e.pacchi_assegnati = new Vector<Pacco_assegnato>();
			Pacco_assegnato p = new Pacco_assegnato();
			p.LST = 600;
			p.Destinazione = inst.get_packagematrix().firstElement().Origine;	// facciamo partire tutto dal magazzino
			e.pacchi_assegnati.addElement(p);
			soluzione.elementi.add(e);
		}
		
		/*
		System.out.println("Ecco i veicoli creati:");
		for(i=0;i<soluzione.elementi.size();i++){
		System.out.println(soluzione.elementi.get(i).veicolo_usato.ID_veicolo + "\t" + soluzione.elementi.get(i).veicolo_usato.Carburante +"\t"+soluzione.elementi.get(i).veicolo_usato.portata+"\t"+soluzione.elementi.get(i).veicolo_usato.capacit�+"\t"+soluzione.elementi.get(i).veicolo_usato.ID_autista);
		}*/

		int veicindex = ClusterSet.size()-1;	// mi dice quanti veicoli ho, � utile (forse) quando creo un nuovo veicolo					
		Vector<Integer> num_clienti_cluster = new Vector<>();		// mi creo un array in cui inserisco il numero di clienti di ciascun cluster
		for(i=0;i<ClusterSet.size();i++){
			num_clienti_cluster.add(ClusterSet.get(i).size());	// numero di clienti in ciascun cluster 
		}
		int counter = 0;	// variabile che permette di costruire le route in parallelo. Fa riferimento ai pacchi da consegnare cos� come presenti nei vari cluster
		int j;
		Collections.sort(num_clienti_cluster);	// li ordino in senso crescente		
		while(counter < num_clienti_cluster.lastElement()){
			for(int z = 0; z < ClusterSet.size(); z++) {		// vado a esplorare tutti i veicoli del clusterset
				if(counter<ClusterSet.get(z).size()){			// se esiste il cliente counter di quel veicolo
					double peso = 0;
					double volume = 0;
					int tempo = 0;

					for (j= 0; j < inst.get_packagematrix().size() ; j ++) {	// s� facendo un cliente viene servito da un solo veicolo anche quando il cliente richieda pi� di 1 pacco. La variabile j nasce e muore qua
						if(ClusterSet.get(z).get(counter).indirizzo.equals(inst.get_packagematrix().get(j).Destinazione)){
							peso += inst.get_packagematrix().get(j).peso;
							volume += inst.get_packagematrix().get(j).volume;
							tempo = inst.get_packagematrix().get(j).LST;
						}
					}					
					boolean colloassegnato = false;					// per l'elemento i del cluster z pongo colloassegnato = false
					while(!colloassegnato) {		// il collo che voglio assegnare � il collo "counter"
						// fintanto che non assegno il collo ciclo alla ricerca di un veicolo feasible. Da qua si riparte anche dopo aver costruito il nuovo veicolo. In quel caso, il veicolo del cluster z sar� ancora infeasible e si prover� a dare il cliente z.counter al nuovo veicolo. 
						
						int last_address_pos = inst.find_position1(soluzione.elementi.get(z).pacchi_assegnati.lastElement().Destinazione);
						int posizione = inst.find_position1(ClusterSet.get(z).get(counter).indirizzo);
						if( soluzione.elementi.get(z).veicolo_usato.capacit� - volume > 0 && soluzione.elementi.get(z).veicolo_usato.portata - peso > 0 && soluzione.elementi.get(z).pacchi_assegnati.lastElement().ora_arrivo_stimata + inst.get_timematrix()[last_address_pos][posizione]/inst.get_scalatempo() <= tempo){ // nessuna tolleranza temporale
							soluzione.elementi.get(z).veicolo_usato.capacit� -= volume;
							soluzione.elementi.get(z).veicolo_usato.portata -= peso;
							Pacco pacco_appoggio = new Pacco();
							pacco_appoggio = retrieve_pacco(ClusterSet.get(z).get(counter).indirizzo, inst);
							Pacco_assegnato p = new Pacco_assegnato();
							p.Barcode = pacco_appoggio.Barcode;
							p.Destinazione = pacco_appoggio.Destinazione;
							p.Origine = pacco_appoggio.Origine;
							p.peso = pacco_appoggio.peso;
							p.volume = pacco_appoggio.volume;
							p.LST = pacco_appoggio.LST;
							p.ora_arrivo_stimata = soluzione.elementi.get(z).pacchi_assegnati.lastElement().ora_arrivo_stimata + inst.get_timematrix()[last_address_pos][posizione]/inst.get_scalatempo();	
							soluzione.elementi.get(z).pacchi_assegnati.addElement(p);
							colloassegnato = true;
						}else {	// altrimenti ho bisogno di un nuovo veicolo
							// CERCO UN VEICOLO DISPONIBILE TRA QUELLI CHE SONO ATTUALMENTE IN GIOCO
							Vector<Integer> posizioni = new Vector<>();	// contiene le posizioni dei veicoli con cui provare l'assegnamento
							Vector<Integer> distanze = new Vector<>();	// contiene le distanze tra l'ultimo cliente servito da un veicolo e il cliente in questione
							for(i=0;i<soluzione.elementi.size();i++){
								System.out.println("indirizzo = "+soluzione.elementi.get(i).pacchi_assegnati.lastElement().Destinazione);
								int last_pos = inst.find_position1(soluzione.elementi.get(i).pacchi_assegnati.lastElement().Destinazione);
								int pos = inst.find_position1(ClusterSet.get(z).get(counter).indirizzo);
								System.out.println("vado da "+last_pos+" a "+pos);
								distanze.add(inst.get_distmatrix()[last_pos][pos]);
							}
							
							int min_dist = 9999999;
							int min_pos = -1;
							while(distanze.size()>0){
								for(i=0;i<distanze.size();i++){
									if(distanze.get(i) < min_dist){
										min_dist = distanze.get(i);
										min_pos = i;
									}
								}
								posizioni.add(min_pos);
								distanze.removeElementAt(min_pos);	// dovrebbe rimuovere l'elemento in posizione min_pos
							}
							
							System.out.println("Posizioni size = "+posizioni.size());
							System.out.println("Prima posizione da valutare: "+posizioni.firstElement());
							
							int v;
							boolean found = false;
							for(v=0;v<posizioni.size();v++){
								if(soluzione.elementi.get(posizioni.get(v)).veicolo_usato.capacit� - volume > 0 && soluzione.elementi.get(posizioni.get(v)).veicolo_usato.portata - peso > 0 && soluzione.elementi.get(posizioni.get(v)).pacchi_assegnati.lastElement().ora_arrivo_stimata + inst.get_timematrix()[last_address_pos][posizione]/inst.get_scalatempo() <= tempo) {							
									soluzione.elementi.get(z).veicolo_usato.capacit� -= volume;
									soluzione.elementi.get(z).veicolo_usato.portata -= peso;
									Pacco_assegnato p = new Pacco_assegnato();
									p.Barcode = inst.get_packagematrix().get(counter).Barcode;
									p.Destinazione = inst.get_packagematrix().get(counter).Destinazione;
									p.Origine = inst.get_packagematrix().get(counter).Origine;
									p.peso = inst.get_packagematrix().get(counter).peso;
									p.volume = inst.get_packagematrix().get(counter).volume;
									p.LST = inst.get_packagematrix().get(counter).LST;
									p.ora_arrivo_stimata = soluzione.elementi.get(z).pacchi_assegnati.lastElement().ora_arrivo_stimata + inst.get_timematrix()[last_address_pos][posizione]/inst.get_scalatempo();	
									soluzione.elementi.get(z).pacchi_assegnati.addElement(p);
									colloassegnato = true;
									System.out.println("Well done!");
									found = true;
								}
							}
							if(!found){	// significa che ho bisogno di un nuovo veicolo
								System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));

								System.out.println("Non ho neanche un veicolo in gioco che mi pu� aiutare. Vado a cercarmene un altro");

								Elemento_soluzione e = new Elemento_soluzione();
								e.veicolo_usato = new Veicolo();
								e.pacchi_assegnati = new Vector<Pacco_assegnato>();
								e.veicolo_usato = inst.get_vehiclematrix().firstElement();
								inst.get_vehiclematrix().remove(0);
								soluzione.elementi.addElement(e);
								Pacco_assegnato pa = new Pacco_assegnato();
								pa.LST = 600;
								pa.Destinazione = inst.get_packagematrix().firstElement().Origine;	// facciamo partire tutto dal magazzino
								e.pacchi_assegnati.addElement(pa);
								soluzione.elementi.add(e);
								veicindex++;
								Pacco_assegnato p = new Pacco_assegnato();
								p.Barcode = inst.get_packagematrix().get(counter).Barcode;
								p.Destinazione = inst.get_packagematrix().get(counter).Destinazione;
								p.Origine = inst.get_packagematrix().get(counter).Origine;
								p.peso = inst.get_packagematrix().get(counter).peso;
								p.volume = inst.get_packagematrix().get(counter).volume;
								p.LST = inst.get_packagematrix().get(counter).LST;
								p.ora_arrivo_stimata = soluzione.elementi.get(z).pacchi_assegnati.lastElement().ora_arrivo_stimata + inst.get_timematrix()[last_address_pos][posizione]/inst.get_scalatempo();	
								System.out.println("veicindex = " +veicindex);
								soluzione.elementi.get(veicindex).pacchi_assegnati.addElement(p);
								colloassegnato=true;
								System.out.println("Well done!");
							}		
						}	
					} // collo assegnato

				}
			}
			counter++;
		}
		
		/*** PERCORSO DI RITORNO ***/ 	// qua nel caso single-depot � semplificato
		for(i = 0;i<soluzione.elementi.size();i++){	// si aggiunge il magazzino di ritorno per ciascun veicolo. In generale avremo un vector di magazzini che ogni veicolo si porta dietro in quanto pi� pacchi potrebbero comportare pi� magazzini, qua per� utilizzeremo un solo magazzino
			int last_pos = inst.find_position1(soluzione.elementi.get(i).pacchi_assegnati.lastElement().Destinazione);
			Pacco_assegnato p = new Pacco_assegnato();
			p.LST = 600/inst.get_scalatempo();
			p.ora_arrivo_stimata = soluzione.elementi.get(i).pacchi_assegnati.lastElement().ora_arrivo_stimata + inst.get_timematrix()[last_pos][0]/inst.get_scalatempo();
			soluzione.elementi.get(i).pacchi_assegnati.addElement(p);
		}		
	}

	
	public Pacco retrieve_pacco(String indirizzo, IInstance inst){
		Pacco p = new Pacco();
		boolean trovato = false;
		for(int i=0;i<inst.get_packagematrix().size() && !trovato;i++){
			if(indirizzo.equals(inst.get_packagematrix().get(i).Destinazione)){
				p = inst.get_packagematrix().get(i);
				trovato = true;
			}
		}
		return p;
	}

	public boolean check_times(Soluzione soluzione){
		boolean ris = true;
		int i,j;
		for(i=0;i<soluzione.elementi.size() && ris;i++){
			for(j=0;j<soluzione.elementi.get(i).pacchi_assegnati.size() && ris;j++){
				if(soluzione.elementi.get(i).pacchi_assegnati.get(j).ora_arrivo_stimata > soluzione.elementi.get(i).pacchi_assegnati.get(j).LST)
					ris=false;
			}
		}
		return ris;
	}
	
	public void calcola_funzione_obiettivo(Soluzione soluzione, IInstance inst) throws IOException{
		int i;
		double funzione_obiettivo = 0;
		for(i=0;i<soluzione.elementi.size();i++){
			calcola_distanza(soluzione.elementi.get(i), inst);
			funzione_obiettivo += soluzione.elementi.get(i).distanza_percorsa;
		}
		soluzione.funzione_obiettivo = funzione_obiettivo;
	}
	
	public void calcola_distanza(Elemento_soluzione e, IInstance inst) throws IOException{
		double distanza = 0;
		int i;
		int pos1,pos2;
		for(i=0;i<e.pacchi_assegnati.size()-2;i++){		// -2 se consideri i 2 pacchi fittizi dei magazzini
			pos1 = inst.find_position1(e.pacchi_assegnati.get(i).Destinazione);
			pos2 = inst.find_position1(e.pacchi_assegnati.get(i+1).Destinazione);
			distanza += inst.get_distmatrix()[pos1][pos2];
		}
		e.distanza_percorsa = distanza;
	}
	
	/**
	 * Semplice funzione di calcolo del tempo totale di percorrenza. Effettua la traduzione da numero intero a orario hh:mm. Richiede che le eventuali scale temporali siano gi� state prese in considerazione
	 */
	
	public void calcola_tempo_percorrenza(Elemento_soluzione e){
		int baseline = 0;	// potresti anche toglierla
		int min_arrivo = (int) (e.pacchi_assegnati.lastElement().ora_arrivo_stimata % 60);
		int ora_arrivo = baseline + (int) e.pacchi_assegnati.lastElement().ora_arrivo_stimata / 60;
		if(min_arrivo>=10)
		System.out.println("Tempo di percorrenza totale: "+"\t" +ora_arrivo+":"+min_arrivo);
		if(min_arrivo<10)
		System.out.println("Tempo di percorrenza totale:" +"\t" +ora_arrivo+":"+"0"+min_arrivo);
	}
	
}


