package generic;
import java.io.*;
import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

import generic.IInstance.Pacco;
import generic.IInstance.Route;
import generic.IInstance.Veicolo;

import java.util.Vector;

public class ManhattanInstance implements IInstance{
	
	File inputt = new File("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\input\\input.txt");
	
	int ND;		// numero di depositi
	int Vin;	// numero di varchi ZTL in ingresso
	int Vout;	// numero di varchi ZTL in uscita
	int NTV;	// numero di tipologie di mezzi	(number types of vehicles)	
	int NTP;	// numero tipologie di colli (number types of packages)
	int NC;		// numero di clienti
	int scala_spazio;	// scala spazio
	int velocita; // velocit� in km/h dei mezzi (ritenuta uguale per tutti)
	int scala_tempo;
	final int baseline = 8;
	
	int[] coorx; // coordinate x dei clienti
	int[] coory; // coordinate y dei clienti
	boolean[] ztl; // vettore di flag ZTL per i clienti
	
	int[][] distmat;
	double[][] timemat;
	Vector<Veicolo> vehiclemat;
	Vector<Pacco> packmat;
	Vector<Cliente> custmat;
	String[] indirizzy;
	
	/*** IMPLEMENTAZIONE METODI SETTER ***/
	public void set_ND(int ND){	this.ND = ND;};	
	public void set_NC(int NC){ this.NC = NC;};
	// mancano gli altri metodi setter
	
	/*** IMPLEMENTAZIONE METODI GETTER ***/
	public int get_ND(){ return this.ND; };
	public int get_NC(){ return this.NC; };
	public int[][] get_distmatrix(){ return this.distmat; }
	public double[][] get_timematrix(){ return this.timemat; }
	public Vector<Veicolo> get_vehiclematrix(){return this.vehiclemat; }
	public Vector<Pacco> get_packagematrix(){return this.packmat; }
	public Vector<Cliente> get_customermatrix(){ return this.custmat; }
	public int get_speed(){ return this.velocita; }
	public int get_typeInstance(){return 0;}
	public int get_scalatempo(){return this.scala_tempo;}
	public int get_baseline(){return baseline;}
	
	public String[] get_indirizzi(){	return this.indirizzy;	}
	
	/*** IMPLEMENTAZIONE METODI READING ***/
	public void readData() throws IOException{
		Scanner input = new Scanner(inputt);
		boolean trovato = false;
		
		// Lettura ND
		while(!trovato){
			if(input.hasNextInt()){
				set_ND(input.nextInt());
				trovato = true;
			}else input.next();
		}
		
		// Lettura Vin
		trovato = false;
		while(!trovato){
			if (input.hasNextInt()){
				Vin = input.nextInt(); 
				trovato = true;
			}
			else
				input.next();
		}
		
		// Lettura Vout
		trovato = false;
		while(!trovato){
			if (input.hasNextInt()){
				Vout = input.nextInt(); 
				trovato = true;
			}
			else
				input.next();
		}
		
		// Lettura NTV
		trovato = false;
		while(!trovato){
			if (input.hasNextInt()){
				NTV = input.nextInt(); 
				trovato = true;
			}
			else
				input.next();
		}

		// Lettura NTP
		trovato = false;
		while(!trovato){
			if (input.hasNextInt()){
				NTP = input.nextInt();
				trovato = true;
			}
			else
				input.next();
		}
		
		// Lettura NC
		trovato = false;
		while(!trovato){
			if(input.hasNextInt()){
				set_NC(input.nextInt());
				trovato = true;
			}else input.next();
		}
		
		// Lettura scala_spazio
		trovato = false;
		while(!trovato){
			if(input.hasNextInt()){
				scala_spazio = input.nextInt();
				trovato = true;
			}else input.next();
		}
		
		// Lettura velocit�
		trovato = false;
		while(!trovato){
			if(input.hasNextInt()){
				velocita = input.nextInt();
				trovato = true;
			}else input.next();
		}
		
		// Lettura scala_tempo
		trovato = false;
		while(!trovato){
			if(input.hasNextInt()){
				scala_tempo = input.nextInt();
				trovato = true;
			}else input.next();
		}
		
		int i;
		int nodi = ND + Vin + Vout + NC;
		
		// Lettura coorx e coory
		int[] coorx = new int[nodi];
		int[] coory = new int[nodi];
		for(i=0;i<nodi;i++){
			trovato = false;
			while(!trovato){
				if(input.hasNextInt()){
					coorx[i] = input.nextInt();
					trovato = true;
				}else input.next();
			}
			trovato = false;
			while(!trovato){
				if(input.hasNextInt()){
					coory[i] = input.nextInt();
					trovato = true;
				}else input.next();
			}
		}
		
		// Scrivo le coordinate in un file a parte
		PrintStream coor = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\output\\coor.txt"));
		System.setOut(coor);
		for(i=0;i<nodi;i++){
			System.out.println(coorx[i]+"\t"+coory[i]);
		}
		System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
		
		// Lettura ZTL (in realt� � un calcolo)
		
		boolean[] ztl = new boolean[NC];
		// Ci interessa conoscere la min_x, max_x, min_y, max_y per delimitare la zona ZTL. Si suppone dunque che la zona ZTL abbia forma rettangolare in ambiente simulato, con i varchi ZTL che definiscono le dimensioni massime del rettangolo.
		int minZTLx = 999;
		int maxZTLx = -1;
		int minZTLy = 999;
		int maxZTLy = -1;
		// Mi creo 2 vettori di coordinate X e Y per i varchi ZTL ingresso
				int[] ZTLinx;
				ZTLinx = new int[Vin];
				
				int[] ZTLiny;
				ZTLiny = new int[Vin];
				for (i = 0; i < Vin; i++) {
					ZTLinx[i] = coorx[ND + i];
					ZTLiny[i] = coory[ND + i];
					if(ZTLinx[i]<minZTLx){
						minZTLx = ZTLinx[i];
					}
					if(ZTLiny[i]<minZTLy){
						minZTLy = ZTLiny[i];
					}
					if(ZTLinx[i]>maxZTLx){
						maxZTLx = ZTLinx[i];
					}
					if(ZTLiny[i]>maxZTLy){
						maxZTLy = ZTLiny[i];
					}
				}
		// Mi creo 2 vettori di coordinate X e Y per i varchi ZTL uscita
				int[] ZTLoutx;
				ZTLoutx = new int[Vout];
				int[] ZTLouty;
				ZTLouty = new int[Vout];
				for (i = 0; i < Vout; i++) {
					ZTLoutx[i] = coorx[ND + Vin + i];
					ZTLouty[i] = coory[ND + Vin + i];
					if(ZTLinx[i]<minZTLx){
						minZTLx = ZTLinx[i];
					}
					if(ZTLiny[i]<minZTLy){
						minZTLy = ZTLiny[i];
					}
					if(ZTLinx[i]>maxZTLx){
						maxZTLx = ZTLinx[i];
					}
					if(ZTLiny[i]>maxZTLy){
						maxZTLy = ZTLiny[i];
					}
				}
		
				int contaztl = 0;
				for (i = ND + Vin + Vout; i < nodi; i++) {
					if (coorx[i] >= minZTLx && coorx[i] <= maxZTLx && coory[i] >= minZTLy && coory[i] <= maxZTLy) { 
						ztl[contaztl] = true;
						contaztl++;
					} else {
						ztl[contaztl] = false;
						contaztl++;
					}
					
				}
				PrintStream ztllist = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\output\\ztl.txt"));
				System.setOut(ztllist);
				for(i=0;i<ztl.length;i++){
					System.out.println(ztl[i]);
				}
				System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
			
				
		// Lettura distmat (in realt� � un calcolo)
		int nodi2 = ND+NC;	// si tratta dei nodi considerati nelle matrici distanza e tempo
		distmat = new int[nodi2][nodi2];
		System.out.println("nodi2 = "+nodi2);
		
		int j;
		int i1 = 0;
		int j1 = 0;
		// boolean limit_reached = false; teoricamente non serve
		for(i=0;i<nodi;i++){
			for(j=0;j<nodi;j++){
				
				if(j1>=nodi2){	// controllo sulle dimensioni di distmat
					j1=0;
					i1++;
				}
				
				if(i<ND){		// significa che parto da un deposito
					if(j<ND){ 	// sono nel caso deposito-deposito
						distmat[i1][j1] = (Math.abs(coorx[i]-coorx[j]) + Math.abs(coory[i]-coory[j]))*scala_spazio; //distanza tra magazzini
						j1++;
					}else if(j>= (ND+Vin+Vout)){	// siamo nel caso deposito-cliente
						if(ztl[j-ND-Vin-Vout]){		// il cliente � in ZTL, il magazzino ovviamente � fuori
							distmat[i1][j1] = nearestZTLin(scala_spazio,coorx[i],coorx[j],coory[i],coory[j],ZTLinx,ZTLiny);
							j1++;
						}else{						// altrimenti siamo nel caso magazzino - cliente NOZTL
							distmat[i1][j1] = (Math.abs(coorx[i]-coorx[j]) + Math.abs(coory[i]-coory[j]))*scala_spazio; // caso std
							j1++;
						}
					}
				}else if(i>=(ND+Vin+Vout)){		// significa che parto da un cliente
					if(ztl[i-ND-Vin-Vout]){		// parto da dentro la ZTL
						if(j<ND){				// caso cliente ZTL - magazzino
							distmat[i1][j1] = nearestZTLout(scala_spazio,coorx[i],coorx[j],coory[i],coory[j],ZTLoutx,ZTLouty);
							j1++;
						}else if(j>= (ND+Vin+Vout)){	// caso cliente ZTL - cliente
							if(ztl[j-ND-Vin-Vout]){		// caso cliente ZTL - cliente ZTL
								distmat[i1][j1] = (Math.abs(coorx[i]-coorx[j]) + Math.abs(coory[i]-coory[j]))*scala_spazio; // caso std
								j1++;
							}else if(!ztl[j-ND-Vin-Vout]){	 // caso cliente ZTL - cliente no ZTL
								distmat[i1][j1] = nearestZTLout(scala_spazio,coorx[i],coorx[j],coory[i],coory[j],ZTLoutx,ZTLouty);
								j1++;
							}
						}
					}else if(!ztl[i-ND-Vin-Vout]){	// parto fuori ZTL
						if(j<ND){				// caso cliente no ZTL - magazzino
							distmat[i1][j1] = (Math.abs(coorx[i]-coorx[j]) + Math.abs(coory[i]-coory[j]))*scala_spazio; // caso std
							j1++;
						}else if(j>= (ND+Vin+Vout)){	// caso cliente no ZTL - cliente
							if(ztl[j-ND-Vin-Vout]){		// caso cliente no ZTL - cliente ZTL
								distmat[i1][j1] = nearestZTLin(scala_spazio,coorx[i],coorx[j],coory[i],coory[j],ZTLinx,ZTLiny);
								j1++;
							}else if(!ztl[j-ND-Vin-Vout]){	 // caso cliente no ZTL - cliente no ZTL
								distmat[i1][j1] = (Math.abs(coorx[i]-coorx[j]) + Math.abs(coory[i]-coory[j]))*scala_spazio; // caso std
								j1++;
							}
						}
					}
				}
			}
		}
		
		PrintStream dist = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\output\\dist.txt"));
		System.setOut(dist);
		for(i=0;i<nodi2;i++){
			for(j=0;j<nodi2;j++){
				System.out.print(distmat[i][j] +"\t");
			}
			System.out.println();
		}
		
		// Lettura timemat (in realt� � un calcolo)
		timemat = new double [nodi2][nodi2];
		float aux = (float) ((float) velocita / 3.6) ;		// velocit� in metri al secondo
		aux = aux*100;
		double vel = Math.round(aux);
		vel = vel/100;	// velocit� in metri al secondo
		
		double alpha = 1.00; // coefficiente moltiplicativo
		double beta = 5; // coefficiente additivo per carico/scarico (minuti)
		
		System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out))); // la stampa torna a video
		for(i=0;i<nodi2;i++) {
			for(j=0;j<nodi2;j++) {
				if(i==j){
					timemat[i][j]=0;
				}else{
				aux = (float) ((float) distmat[i][j]/(60*vel)*alpha + beta);
				aux = aux*100;
				timemat[i][j] = Math.round(aux);
				timemat[i][j] = timemat[i][j]/100;		// tempo espresso in minuti
				}
			}
		}
		
		PrintStream time = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\output\\time.txt"));
		System.setOut(time);
		System.out.println("velocit�: "+vel);
		for(i=0;i<nodi2;i++){
			for(j=0;j<nodi2;j++){
				System.out.print(timemat[i][j] +"\t");
			}
			System.out.println();
		}
		
		System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
		input.close();
		
		// Lettura vehiclemat
		
		// per creare una matrice di veicoli come deisderato da IInstance abbiamo bisogno della matrice di disponibilit�
		Scanner dispveicoli = new Scanner(new File("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\input\\dispveicoli.txt"));
		
		// creati il vector di disponibilit�
		Vector<Integer> disp = new Vector<>();
		while(dispveicoli.hasNext()){
			if(dispveicoli.hasNextInt()){
				disp.add(dispveicoli.nextInt());
			}else{dispveicoli.next();}
		}
		
		dispveicoli.close();
		
		Scanner input_veicoli = new Scanner(new File("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\input\\input_veicoli.txt"));
		vehiclemat = new Vector<Veicolo>();
		int count = 0;
		input_veicoli.nextLine();
		input_veicoli.nextLine();
		for(i=0;i<disp.size();i++){
			String ID_veicolo = input_veicoli.next();
			double capacita = input_veicoli.nextDouble();
			double portata = input_veicoli.nextDouble();
			for(j=0;j<disp.get(i);j++){
				Veicolo v = new Veicolo();
				switch(i){
				case 0:{
					v.Carburante = "Metano";
					break;
				}
				case 1:{
					v.Carburante = "Diesel";
					break;
				}
				case 2:{
					v.Carburante = "Benzina";
					break;
				}
				case 3:{
					v.Carburante = "Benzina";
					break;
				}
				default:{
					v.Carburante = "Unknown";
					break;	
				}
				}
				v.ID_veicolo = ID_veicolo;
				v.capacit� = capacita;
				v.portata = portata;
				v.ID_autista = String.valueOf(count);
				vehiclemat.add(v);
				count++;
			}
		}
		
		PrintStream veicoli = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\output\\veicoli.txt"));
		System.setOut(veicoli);
		for(i=0;i<vehiclemat.size();i++){
			System.out.print(vehiclemat.get(i).ID_veicolo + "\t" + vehiclemat.get(i).ID_autista + "\t" +vehiclemat.get(i).Carburante + "\t\t"+ vehiclemat.get(i).portata+"\t\t"+vehiclemat.get(i).capacit�);
			System.out.println();
		}
		
		System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
		
		input_veicoli.close();
		
		
		// LETTURA PACKMAT
		packmat = new Vector<Pacco>();
		Scanner input_pacchi = new Scanner(new File("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\input\\input_pacchi.txt"));
		// mi creo un array di double che descrive le caratteristiche del pacco (tutti standard)
		double[][] caratt_pacco = new double[NTP][2];
		for(i=0;i<NTP;i++){
			caratt_pacco[i][0] = -1;
			caratt_pacco[i][1] = -1;
			while(caratt_pacco[i][0]<0){
				if(input_pacchi.hasNextDouble()){
					caratt_pacco[i][0] = input_pacchi.nextDouble(); // peso
				}else{
					if(input_pacchi.hasNext()){
						input_pacchi.next();
					}else{input_pacchi.nextLine();}
				}
			}
			while(caratt_pacco[i][1]<0){
				if(input_pacchi.hasNextDouble()){
					caratt_pacco[i][1] = input_pacchi.nextDouble(); // volume
				}else{
					if(input_pacchi.hasNext()){
						input_pacchi.next();
					}else{input_pacchi.nextLine();}
				}
			}
		}
		
		/*System.out.println("Ecco le caratteristiche dei pacchi");
		for(i=0;i<NTP;i++){
			System.out.println(caratt_pacco[i][0]+"\t"+caratt_pacco[i][1]);
		}*/
		
		input_pacchi.close();
		
		// probabilit� pacchi
		double[] prob = new double[NTP];
		double sumprob=0;
		for(i=0;i<NTP;i++){
			prob[i]=Math.pow(0.5,i+1);
			if(i==NTP-1){
				prob[i] = 1-sumprob;
			}
			sumprob+=prob[i];
		}
		
		/*System.out.println("Ecco le probabilit� dei pacchi");
		for(i=0;i<NTP;i++){
			System.out.println(prob[i]);
		}*/
		
		// generatore di richieste trasportistiche
		long seed = 788823;
		double richieste2 = randDouble(1, 1.5, seed)*NC; // genera un numero di richieste compreso tra NC e 1.5*NC
		int richieste = (int) richieste2;
		int countprob = 0;	// serve per capire la probabilit� da assegnare al collo 
		sumprob = prob[0];
		for(i=0;i<richieste;i++){
			if(i> (int) (sumprob*richieste) ){
				if(countprob<NTP-1){
					countprob++;
					sumprob+=prob[countprob];
				}
			}
			Pacco pacco = new Pacco();
			pacco.Barcode = getSaltString();		// nella versione simulata non ci interessa questa informazione
			pacco.Origine = String.valueOf(randInt(0,ND-1,seed));
			seed+=123;	// serve a non usare lo stesso cliente
			pacco.Destinazione = String.valueOf(randInt(ND + Vin + Vout, ND + Vin + Vout + NC - 1, seed));
			pacco.volume = caratt_pacco[countprob][0];
			pacco.peso = caratt_pacco[countprob][1];
			if(ztl[Integer.parseInt(pacco.Destinazione) - ND - Vin - Vout]){	// significa che il cliente � in ztl
				pacco.LST = 120/scala_tempo;			// corrisponde alle ore 10:00, con scala temporale = 1 minuto.
			}else{
				boolean doppione = false;
				// controlla se il cliente ha gi� richiesto un pacco
				for(int c=0;c<packmat.size();c++){
					if(pacco.Destinazione.equals(packmat.get(c).Destinazione)){
						pacco.LST = packmat.get(c).LST;
						doppione = true;
					}
				}
				
				// genera un numero a caso tra 0 e 1 e switchalo.
				if(!doppione){
					seed-=  37;
					double a = randDouble(0,1,seed);
					if(a<0.33){
						pacco.LST = 240/scala_tempo;
					}else if(a>=0.33 && a<0.66){
						pacco.LST = 360/scala_tempo;
					}else{
						pacco.LST = 600/scala_tempo;
					}
				}
			}
			
			packmat.add(pacco);
		}
		
		// LETTURA CUSTMAT
		custmat = new Vector<Cliente>();
		for(i=0;i<richieste;i++) {
			boolean found = false;			// serve a evitare i doppioni
			Cliente cliente = new Cliente(); 
			for(j=0;j<custmat.size() && !found;j++) {
				if(packmat.get(i).Destinazione.equals(custmat.get(j).indirizzo)){
					found = true;
				}
			}
			if(!found) {
				cliente.indirizzo = packmat.get(i).Destinazione;
				cliente.latitudine = coorx[Integer.parseInt(cliente.indirizzo)];
				cliente.longitudine = coory[Integer.parseInt(cliente.indirizzo)];
				custmat.add(cliente);
			}
		}
		
		PrintStream clienti = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\output\\clienti.txt"));
		System.setOut(clienti);
		for(i=0;i<custmat.size();i++){
			System.out.print(custmat.get(i).indirizzo + "\t" + custmat.get(i).latitudine + "\t" +custmat.get(i).longitudine);
			System.out.println();
		}
		
		System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
		
		printPack(packmat);
	
	}	// end of readData
	
	public void printPack(Vector<Pacco> packmat) throws IOException{
		PrintStream pacchi = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\output\\pacchi.txt"));
		System.setOut(pacchi);
		System.out.println("BARCODE"+"\t"+"ORIGINE"+"\t"+"DESTINAZIONE"+"\t"+"PESO"+"\t"+"VOLUME"+"\t"+"LST");
		for(int i=0;i<packmat.size();i++){
			System.out.println(packmat.get(i).Barcode+"\t"+packmat.get(i).Origine+"\t"+packmat.get(i).Destinazione+"\t"+packmat.get(i).peso+"\t"+packmat.get(i).volume+"\t"+packmat.get(i).LST);
		}
		System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
	}
	
	/*** IMPLEMENTAZIONE METODI WRITING ***/
	
	/*** IMPLEMENTAZIONE METODI DI SUPPORTO (di IInstance) ***/
	// questo metodo permette di risalire alla posizione del cliente nella matrice delle distanze, sapendo di non dover considerare le ZTL
	// nella matrice delle distanze ci sono infatti solo depositi e clienti, no le ZTL che sono impiegate prima
	public int find_position1(String indirizzo){
		int ZTL = this.Vin+this.Vout;
		int position = Integer.parseInt(indirizzo);
		if(position>=(this.ND+ZTL)){
			position-=(this.ND+ZTL-1);
		}			
		return position;
	}
	
	// questo metodo serve per capire la posizione dell'indirizzo nella ATTUALE matrice delle distanze (che � pi� piccola)
	public int find_position2(String indirizzo, String[] indirizzi){
			int position = -1;
			boolean trovato = false;
			
			for(int i=0;i<indirizzi.length&&!trovato;i++){
				if(indirizzo.equals(indirizzi[i])){
					trovato=true;
					position = i;
				}
			}
			return position;
		}
	
	/**************************/
	/*** METODI DI SUPPORTO ***/
	/**************************/
	
	/*
	 * I metodi di nearestZTL servono per calcolare la minima distanza tra il cliente 1(x1,y1) e il cliente 2(x2,y2) sapendo che nel tragitto il veicolo dovr� passare per un varco ZTL (di ingresso oppure di uscita). Nel caso di ZTLin, i � il cliente FUORI ztl e j quello in ZTL. Nel caso di ZTLout, i �il cliente ZTL e j quello FUORI ZTL. 
	 */
	private int nearestZTLin(int scala_spazio, int x1, int x2, int y1, int y2, int[] ZTLinx, int[] ZTLiny){
		int min_distanza = 99999;
		int distanza;
		int i;
		for(i=0;i<ZTLinx.length;i++){
			distanza = ( (Math.abs(x1 - ZTLinx[i]) + Math.abs(y1 - ZTLiny[i]))
					+ (Math.abs(ZTLinx[i] - x2) + Math.abs(ZTLiny[i] - y2)) )*scala_spazio;
			if(distanza < min_distanza)
				min_distanza = distanza;
		}
		return min_distanza;
	}
	
	private int nearestZTLout(int scala_spazio, int x1, int x2, int y1, int y2, int[] ZTLoutx, int[] ZTLouty){
		int min_distanza = 99999;
		int distanza;
		int i;
		for(i=0;i<ZTLoutx.length;i++){
			distanza = ( (Math.abs(x1 - ZTLoutx[i]) + Math.abs(y1 - ZTLouty[i]))
					+ (Math.abs(ZTLoutx[i] - x2) + Math.abs(ZTLouty[i] - y2)) )*scala_spazio;
			if(distanza < min_distanza)
				min_distanza = distanza;
		}
		return min_distanza;
	}
	
	/** RANDDOUBLE /RANDINT
	 * Il metodo ritorna un numero pseudocasuale compreso tra min e max
	 * @param min	estremo inferiore
	 * @param max	estremo superiore
	 * @param seed	numero che comporta la casualit�
	 * @return
	 */
	public static double randDouble(double min, double max, long seed) {
		Random rand = new Random(seed);
		double randomNum = min + (max - min) * rand.nextDouble();
		return randomNum;
	}
	
	public static int randInt(int min, int max, long seed) {
		Random rand = new Random(seed);
		int randomNum = (int) (min + (max - min) * rand.nextDouble());
		return randomNum;
	}
	
	// generatore casuale di stringhe
	protected String getSaltString() {
        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 18) { // length of the random string.
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        String saltStr = salt.toString();
        return saltStr;

    }
	
}
