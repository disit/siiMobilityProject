package generic;
import com.google.gson.Gson;

import generic.DBConnect;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Vector;

public class Geocoder {
	
	public static double GoogleLat(String address){
		String key = "AIzaSyB3PD-PXal2VOacL7vFjdGqGNrPklU8waQ";
		//String ris = null;
		double ris = -1;
		try{
			URL url = new URL("https://maps.googleapis.com/maps/api/geocode/json?address="+address+"&key="+key);
			InputStreamReader reader = new InputStreamReader(url.openStream());
			
			AttributeMatrix am = new Gson().fromJson(reader, AttributeMatrix.class);
			
			//System.out.println("Place_ID = "+ am.getResults()[0].getPlaceID());
			
			ris = Double.parseDouble(am.getResults()[0].getGeometry().getLocation().get("lat"));
			
		}catch (MalformedURLException ex) {
            Logger.getLogger(Geocoder.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Geocoder.class.getName()).log(Level.SEVERE, null, ex);
        }
					
		return ris;
		
	}
	
	public static double GoogleLng(String address){
		String key = "AIzaSyB3PD-PXal2VOacL7vFjdGqGNrPklU8waQ";
		double ris = -1;
		//String ris = null;
		try{
			URL url = new URL("https://maps.googleapis.com/maps/api/geocode/json?address="+address+"&key="+key);
			InputStreamReader reader = new InputStreamReader(url.openStream());
			
			AttributeMatrix am = new Gson().fromJson(reader, AttributeMatrix.class);
			
			ris = Double.parseDouble(am.getResults()[0].getGeometry().getLocation().get("lng"));	// mi dice che � nullo
			
		}catch (MalformedURLException ex) {
            Logger.getLogger(Geocoder.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Geocoder.class.getName()).log(Level.SEVERE, null, ex);
        }
		
		return ris;
		
	}
	
	
	// Classe che segue la struttura del file JSON
    private class AttributeMatrix {
    	private Result[] results;
    	private String status;
    	
    	// Getters
    	public Result[] getResults() { return results; }
    	public String getStatus() { return status; }
    	
    	class Result{
    		private address_component[] address;
    		private String formatted_address;
    		private geometry geometry;
    		private String place_id;
			private String[] types;
    		
    		// Getters
    		public address_component[] getAddress(){ return address; }
    		public String getFormatted_Address() {return formatted_address; }
    		public geometry getGeometry() {return geometry; }
    		public String getPlaceID() { return place_id; }
			public String[] getTypes() { return types; }
    		
			private address_component[] address_components;

			class address_component{
			    			private String long_name;
			    			private String short_name;
			    			private String[] types;
			    			
			    			// Getters
			    			
			    			public String getLongName() {return long_name;}
			    			public String getShortName() {return short_name;}
			    			public String[] getTypes() {return types;}
			    			
			    		}

    		
    		class geometry{
    			private Map <String,String> location;//CON MAP
    			private String location_type;
    			private viewport viewport; //(che � fatta da northeast e southwest)
    			
    			// Getters
    			public Map <String,String> getLocation() { return location; }//CON MAP
    			public String getLocation_type() { return location_type; }
    			public viewport getViewport() { return viewport; }
				
				public double getLatitude() { return Double.parseDouble(location.get("lat")); }//CON MAP
    			public double getLongitude() { return Double.parseDouble(location.get("lng")); }//CON MAP
					
    			
    			class viewport{
    				private northeast northeast;
    				private southwest southwest;
    				
    				class northeast{
    					private String latitude;
    					private String longitude;
    					
    					public String getLatitude() { return this.latitude; }
        				public String getLongitude() { return this.longitude; }
    				}
    				
    				class southwest{
    					private String latitude;
    					private String longitude;
    					
    					public String getLatitude() { return this.latitude; }
        				public String getLongitude() { return this.longitude; }
    				}
    				
    			}
    			
    		}
    		
    	}
    	
    }
	
    
    /*public static void UpdateTable(){
    	try{
    		Connection conn = DBConnect.getConnection();
			Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			String sql = "SELECT IndirizzoDestinazionePacco FROM listepacchi";	// UPDATE TABLE INSERT VALUES. In prima battuta si fa DROP
			ResultSet res = st.executeQuery(sql);
    	}
    }*/
    
    public static void main(String[] args) throws IOException{
    	// anzich� leggere da origini si legge direttamente dai risultati di SQL (dal vector di origini)
    	
    	RealInstanceDB R = new RealInstanceDB();
    	String[] indirizzi = R.getIndirizzi(); 
    
    	for(int i=0;i<indirizzi.length;i++){
    		// address diventa la linea di origins
    		try{
    			String address = indirizzi[i];
    			
    			// se trovi qualcosa come "Test@" nella string non usarlo
    			
    			//GLI INDIRIZZI DEVONO PRIMA ESSERE MODIFICATI. Dove si incontra uno spazio si mette %20.
    			String new_address = address.replaceAll(" ", "%20");
    			new_address = new_address.replaceAll("�", "'");
    			
    			//String address = "via%20del%20Leti%20%208,Lammari";
    			String key = "AIzaSyB3PD-PXal2VOacL7vFjdGqGNrPklU8waQ";
    			URL url = new URL("https://maps.googleapis.com/maps/api/geocode/json?address="+new_address+"&key="+key);
    			InputStreamReader reader = new InputStreamReader(url.openStream());

    			AttributeMatrix am = new Gson().fromJson(reader, AttributeMatrix.class);
    				
    			System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
    			System.out.println(new_address);
    			// System.out.println(am.getResults()[0].getAddress()[1].getLongName());	

    			//System.out.println(am.getResults()[0].getTypes()[0]);
    			//String indirizzo = am.getResults()[0].getFormatted_Address();
    			//System.out.println(am.getResults()[0].getGeometry().getLocation_type());

    			//System.out.println("Address Components Length: "+am.getResults()[0].getAddress());

    			double latitude = GoogleLat(new_address);
    			double longitude = GoogleLng(new_address);
    			
    			File output = new File("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstanceDB\\input\\coordinate.txt");
    			try{
    				if(output.exists()==false){
    					System.out.println("We had to make a new file.");
    					output.createNewFile();
    				}
    				PrintWriter out = new PrintWriter(new FileWriter(output, true));
    				out.print(indirizzi[i]+"\t"+latitude+"\t"+longitude);
        			out.println();
    				out.close();
    			}catch(IOException e){
    				System.out.println("COULD NOT LOG!!");
    			}

    		}catch (MalformedURLException ex) {
    			Logger.getLogger(Geocoder.class.getName()).log(Level.SEVERE, null, ex);
    		} catch (IOException ex) {
    			Logger.getLogger(Geocoder.class.getName()).log(Level.SEVERE, null, ex);
    		}
    	} // fine while
    }

}


