package generic;
import com.google.gson.Gson;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/** this version should allow to populate a 100x100 matrix in about 10 days**/

public class GMapsDistTime {
	// verifica che i 2 metodi funzionino
	// poi in ciascuno dovresti anche gestire il fatto che i metodi possono non funzionare causa exceed query limit di Google (che non sembra essere 5000)
	public static int[][] GoogleDistance(String origins, String destinations){
		String key = "AIzaSyAqkcIvDZEM9a5GIB5bPmoIkW9ubnbb2Aw"; // emanuele.guerrazzi@gmail.com
    	//String key = "AIzaSyCgA0d47ZnHPReywfzpX8AUh3x0rxBeTug"; // luisellona60@gmail.com
		// String key = "AIzaSyDDNcu6xRecPucHTPi6zhxlKL8HVk6Af1M";
		// String key = "AIzaSyDPAdIjlfjPa3LQO0pKIzDRQtoMOweGfjI";
		
		int[][] ris = new int[1][1];
		
		try {
		URL url = new URL("https://maps.googleapis.com/maps/api/distancematrix/json?origins="+origins+"&destinations="+destinations+"&key="+key);
        InputStreamReader reader = new InputStreamReader(url.openStream());
        
        AttributeMatrix am = new Gson().fromJson(reader, AttributeMatrix.class);
        
     // Matrice delle distance
        int rows = am.getOriginAddresses().length;
        int columns = am.getDestinationAddresses().length;
        int[][] dm = new int[rows][columns];
        for(int r = 0; r < rows; ++r) {
            for(int c = 0; c < columns; ++c) {
                dm[r][c] = am.getRows()[r].getElements()[c].getDistance();
            }
        }
        ris = dm;
		} catch (MalformedURLException ex) {
            Logger.getLogger(GMapsDistTime.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(GMapsDistTime.class.getName()).log(Level.SEVERE, null, ex);
        }
		
		return ris;
	}
	
	public static double[][] GoogleTime(String origins, String destinations){
		String key = "AIzaSyAqkcIvDZEM9a5GIB5bPmoIkW9ubnbb2Aw"; // emanuele.guerrazzi@gmail.com
    	// String key = "AIzaSyCgA0d47ZnHPReywfzpX8AUh3x0rxBeTug"; // luisellona60@gmail.com
		// String key = "AIzaSyDDNcu6xRecPucHTPi6zhxlKL8HVk6Af1M";
		// String key = "AIzaSyDPAdIjlfjPa3LQO0pKIzDRQtoMOweGfjI";
		
		double[][] ris = new double[1][1];
		
		try {
		URL url = new URL("https://maps.googleapis.com/maps/api/distancematrix/json?origins="+origins+"&destinations="+destinations+"&key="+key);
        InputStreamReader reader = new InputStreamReader(url.openStream());
        
        AttributeMatrix am = new Gson().fromJson(reader, AttributeMatrix.class);
         
     // Matrice delle distance
        int rows = am.getOriginAddresses().length;
        int columns = am.getDestinationAddresses().length;
        double[][] tm = new double[rows][columns];
        for(int r = 0; r < rows; ++r) {
            for(int c = 0; c < columns; ++c) {
                tm[r][c] = (double) am.getRows()[r].getElements()[c].getDuration()/60;
            }
        }
        ris = tm;
		} catch (MalformedURLException ex) {
            Logger.getLogger(GMapsDistTime.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(GMapsDistTime.class.getName()).log(Level.SEVERE, null, ex);
        }
		
		return ris;
	}
	
	// Classe che segue la struttura del file JSON
	private class AttributeMatrix {
		private String[] destination_addresses;
		private String[] origin_addresses;
		private Row[] rows;
		private String status;

		// Getters
		public String[] getDestinationAddresses() { return destination_addresses; }
		public String[] getOriginAddresses() { return origin_addresses; }
		public Row[] getRows() { return rows; }
		public String getStatus() { return status; }

		// Query over limit test
		public boolean limitReached() {
			return new String("OVER_QUERY_LIMIT").equals(status);
		}

		class Row {
			private Element[] elements;

			// Getters
			public Element[] getElements() { return elements; }

			class Element {
				private Map<String, String> distance;
				private Map<String, String> duration;
				private String status;

				// Getters
				public int getDistance() { return Integer.parseInt(distance.get("value")); }
				public int getDuration() { return Integer.parseInt(duration.get("value")); }
				public String getStatus() { return status; }
			}
		}
	}
	
    public static void main(String[] args) throws IOException{
        try {  	
        	String key = "AIzaSyAqkcIvDZEM9a5GIB5bPmoIkW9ubnbb2Aw"; // emanuele.guerrazzi@gmail.com
        	//String key = "AIzaSyCgA0d47ZnHPReywfzpX8AUh3x0rxBeTug"; // luisellona60@gmail.com
        	Scanner conta_indirizzi = new Scanner(new File("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstanceDB\\input\\all_address.txt"));
        	int numero_indirizzi=0; // conta il numero di indirizzi presenti in all_address
    		while(conta_indirizzi.hasNextLine()){
    			numero_indirizzi++;
    			conta_indirizzi.nextLine();
    		}
    		conta_indirizzi.close();
    		
        	// https://maps.googleapis.com/maps/api/distancematrix/json?units=metric&origins=via%20Asciutti%202,%2055016%20Porcari%20LU,%20Italy&destinations=via%20Carrara%2032%20Porcari%2055016%20LU&key=AIzaSyAqkcIvDZEM9a5GIB5bPmoIkW9ubnbb2Aw      	
    		PrintStream distanze = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstanceDB\\input\\new_distmatrix.txt", true));
    		// PrintStream distanze = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstanceDB\\input\\food.txt", true));
        	PrintStream tempi = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstanceDB\\input\\new_timematrix.txt", true));
    		//PrintStream tempi = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstanceDB\\input\\foot.txt", true));
        	      	
        	Scanner indirizzi = new Scanner(new File("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstanceDB\\input\\all_address.txt"));
        	String[] origini = new String[numero_indirizzi];
        	String[] destinazioni = new String[numero_indirizzi];
        	int i,j;
        	i=0;
        	
        	while(indirizzi.hasNextLine()){
        		String s = indirizzi.nextLine();
        		origini[i] = s;
        		destinazioni[i] = s;
        		i++;
        	}
        	     	
        	boolean restart = true;	// si usa se il flusso dati si blocca
        	// RIPARTIRE CON i=... e j=...
        	for(i=94;i<numero_indirizzi;i++){	// riferimento: indirizzi Daniela	
        		String origine = origini[i];
        		origine = origine.replaceAll(" ", "%20");
        		origine = origine.replaceAll("�", "'");
        		origine = origine.replaceAll("'", "%20%27");	// nel caso in cui desse noia roba come "dell'Isola" che deve essere "dell' Isola"
        		for(j=0;j<numero_indirizzi;j++){  
        			
        			if(restart){
        				j=53;
        				restart=false;
        			}
        			
        			String destinazione = destinazioni[j];
        			destinazione = destinazione.replaceAll(" ", "%20");
        			destinazione = destinazione.replaceAll("�", "'");
        			destinazione = destinazione.replaceAll("'", "%20%27");
        			// Ottiene il file dal web
        			URL url = new URL("https://maps.googleapis.com/maps/api/distancematrix/json?units=metric&origins="+origine+"&destinations="+destinazione+"&key="+key);
        			InputStreamReader reader = new InputStreamReader(url.openStream());
        			// Lo converte nella struttura dati personalizzata (libreria Google)
        			AttributeMatrix am = new Gson().fromJson(reader, AttributeMatrix.class);

        			System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
        			// Matrice delle distance
        			int rows = am.getOriginAddresses().length;
        			int columns = am.getDestinationAddresses().length;
        			int[][] dm = new int[rows][columns];
        			dm = GoogleDistance(origine,destinazione);

        			// Matrice dei tempi
        			int[][] tm = new int[rows][columns];
        			for(int r = 0; r < rows; ++r) {
        				for(int c = 0; c < columns; ++c) {
        					tm[r][c] = am.getRows()[r].getElements()[c].getDuration();
        				}
        			}
        			
        			// qua abbiamo ottenuto 1 elemento per DistanceMatrix e 1 elemento per TimeMatrix
        			// dunque faccio "print" e "tab" finch� non scendo alla prossima i  			
        			
        			
        			System.setOut(distanze);	// rows e columns valgono 1
        			for(int r = 0; r < rows; ++r) {
        				for(int c = 0; c < columns; ++c) {
        					System.out.print(dm[r][c] + "\t");
        				}
        			}
        			
        			System.setOut(tempi);		// rows e columns valgono 1
        			for(int r = 0; r < rows; ++r) {
        				for(int c = 0; c < columns; ++c) {
        					System.out.print(tm[r][c] + "\t");
        				}
        			}
        			
        			
        			// Query over limit test
        			// System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
        			// System.out.println("\n\n" + ((am.limitReached()) ? "Limite raggiunto" : "Limite non raggiunto"));        	
        		}
        		System.setOut(tempi);
        		System.out.println();
        		System.setOut(distanze);
        		System.out.println();
        	}
        	indirizzi.close();
        }
        catch (MalformedURLException ex) {
            Logger.getLogger(GMapsDistTime.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch (IOException ex) {
            Logger.getLogger(GMapsDistTime.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
