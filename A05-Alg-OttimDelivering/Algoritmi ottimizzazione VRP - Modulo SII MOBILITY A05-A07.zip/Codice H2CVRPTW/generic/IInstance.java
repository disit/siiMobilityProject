package generic;
import java.io.*;
import java.util.Comparator;
import java.util.Vector;

/*** IInstance /***
 * In questa interfaccia vengono definiti tutti i campi comuni alle varie istanze e i metodi di reading e writing. I campi comuni alle varie istanze sono quelli che poi vengono passati al core, ovvero tutti e soili i campi che servono al core per funzionare.
 */

public interface IInstance{
	
	/*** DICHIARAZIONE METODI SETTER ***/
	
	/*** DICHIARAZIONE METODI GETTER ***/
	public int get_ND();
	public int get_NC();
	public int[][] get_distmatrix();
	public double[][] get_timematrix();
	public Vector<Veicolo> get_vehiclematrix();
	public Vector<Pacco> get_packagematrix();
	public Vector<Cliente> get_customermatrix();
	public int get_speed();
	public int get_typeInstance();
	public int get_scalatempo();
	public int get_baseline();
	public String[] get_indirizzi();	// metodo che restituisce nell'ordine tutti gli indirizzi di origine e quelli di destinazione. Sono quelli usati per ottenere la distmatrix e la timematrix del run attuale
	
	/*** DICHIARAZIONE METODI READING ***/
	
	/* readData permette di leggere:
	 	- ND = numero di depositi
	 	- NC = numero di clienti 
	 	- distmatrix = matrice (NC*ND)x(NC*ND) delle distanze dei clienti
	 */
	public void readData() throws IOException; // non ha molto senso includere un solo file se poi dentro ai metodi specifici ne richiami di pi�.
	
	/*** DICHIARAZIONE METODI WRITING ***/
	
	/*** DICHIARAZIONE METODI DI SUPPORTO ***/
	public int find_position1(String indirizzo) throws IOException; 	// questo metodo prende in input un indirizzo e restituisce la sua posizione nella matrice delle distanze (serve per popolare la sottomatrice delle distanze/tempi, quella che fa riferimento al run attuale)
	
	public int find_position2(String indirizzo, String[] indirizzi);	// String[] indirizzi � la stringa di indirizzi (origini e destinazioni) attualmente in gioco nel run
	
	
	/*** DICHIARAZIONE CLASSI ***/
	public class Veicolo  implements Comparator<Veicolo>{
		String ID_veicolo;
		String ID_autista;
		String Carburante;
		double portata;
		double capacit�;
		
		public int compare(Veicolo v1, Veicolo v2) {
			int pollution_value1,pollution_value2;	// valori corrispondenti ai veicolo 1 e 2
			
			pollution_value1 = assign_pollution_value(v1);
			pollution_value2 = assign_pollution_value(v2);
			if(pollution_value1 > pollution_value2) return -1;
			if(pollution_value1 < pollution_value2) return 1;
			if(pollution_value1 == pollution_value2){
				if(v1.capacit� > v2.capacit�) return -1;
				if(v1.capacit� < v2.capacit�) return 1;
				return 0;
			}
			return 0;
		}

		public int assign_pollution_value(Veicolo v){
			int value;
			switch(v.Carburante){
			case("Benzina"):{
				value = 0;
				break;
			}
			case("Diesel"):{
				value = 1;
				break;
			}
			case("Metano"):{
				value = 2;
				break;
			}
			case("Elettrico"):{
				value = 3;
				break;
			}
			default:{
				value=0;
				break;
			}
		}
		return value;
	}
	
	}
	
	public class Pacco{
		String Barcode;
		String Origine;
		String Destinazione;
		double peso;
		double volume;
		int LST;		// Latest Service Time
	}
	
	public class Cliente{
		String indirizzo;
		double latitudine;
		double longitudine;
	}
	
	public class Node{
		public int ID_node;		// etichetta del nodo. Serve per conoscere poi il costo dell'arco. Viene costruito a partire dall'ID del cliente.
		public int pos_arco;	// fa riferimento al 1 arco della stella uscente del nodo (cio� gli archi che hanno come coda il nodo in questione)
	}
	
	public class Edge implements Comparator<Edge> {
		public int ID_arco;		// identificativo dell'arco (viene "creato" direttamente nel metodo e la cosa finisce l�)
		public int coda;		// nodo da cui parte l'arco
		public int testa;		// nodo a cui arriva l'arco
		public int costo;		// costo (distanza) dell'arco

		public int compare(Edge e1, Edge e2) {
			if(e1.costo < e2.costo) return -1;
			if(e1.costo > e2.costo) return 1;
			return 0;
		}
	}
	
	public class Route {
		
		public String address;
		public String barcode;
		public double arrivo;
		
		public String getcliente(){
			return address;
		}
		
		public String getBarcode(){
			return barcode;
		}
		
		public double getArrivo(){
			return arrivo;
		}

		public static void main(String[] args) {
			// TODO Auto-generated method stub

		}

	}
	
}
