/***
 * 08/11/2017
 * Questo algoritmo risolve il H2CVRPTW, con 1 solo deposito
 */

package generic;

import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Collections;
import java.util.Random;
import java.util.Vector;
import java.util.ArrayList;
import java.util.Comparator;

import generic.IInstance.Node;
import generic.IInstance.Edge;
import generic.IInstance.Cliente;
import generic.IInstance.Veicolo;
import generic.IInstance.Pacco;

public class Core3 implements ICore{
	
	public void loadProblem(IInstance inst){
		System.out.println((inst.get_NC() + inst.get_ND()));
		
		boolean debug = false;
		int i,j;
		int nodi = inst.get_NC()+inst.get_ND();
		
		if(debug){
			System.out.println("Stampa della matrice delle distanze");
		
			
			for (i = 0; i < nodi; i++) {
				for (j = 0; j < nodi; j++) {
					System.out.print(inst.get_distmatrix()[i][j] + " ");
				}
				System.out.println();
			}
			
			System.out.println("Stampa della matrice dei tempi");
			for (i = 0; i < nodi; i++) {
				for (j = 0; j < nodi; j++) {
					System.out.print(inst.get_timematrix()[i][j] + " ");
				}
				System.out.println();
			}
			
			System.out.println("Stampa della matrice dei veicoli");
			System.out.println("ID_VEICOLO"+"\t"+"ID_AUTISTA"+"\t"+"CARBURANTE"+"\t"+"PORTATA"+"\t"+"CAPACITA'");
			for (i = 0; i < inst.get_vehiclematrix().size(); i++) {
				System.out.print(inst.get_vehiclematrix().get(i).ID_veicolo + "\t" + inst.get_vehiclematrix().get(i).ID_autista + "\t" +inst.get_vehiclematrix().get(i).Carburante + "\t\t"+ inst.get_vehiclematrix().get(i).portata+"\t"+inst.get_vehiclematrix().get(i).capacit�);
				System.out.println();
			}


			System.out.println("Stampa della matrice dei pacchi");
			System.out.println("BARCODE"+"\t"+"ORIGINE"+"\t"+"DESTINAZIONE"+"\t"+"PESO"+"\t"+"VOLUME"+"\t"+"LST");
			for (i = 0; i < inst.get_packagematrix().size(); i++) {
				System.out.print(inst.get_packagematrix().get(i).Barcode + "\t" + inst.get_packagematrix().get(i).Origine + "\t" +inst.get_packagematrix().get(i).Destinazione + "\t"+ inst.get_packagematrix().get(i).peso+"\t"+inst.get_packagematrix().get(i).volume+"\t"+inst.get_packagematrix().get(i).LST);
				System.out.println();
			}
			System.out.println("Stampa della matrice dei clienti");
			System.out.println("INDIRIZZO"+"\t"+"LATITUDINE"+"\t"+"LONGITUDINE");
			for (i = 0; i < inst.get_customermatrix().size(); i++) {
				System.out.print(inst.get_customermatrix().get(i).indirizzo + "\t" + inst.get_customermatrix().get(i).latitudine + "\t" +inst.get_customermatrix().get(i).longitudine);
				System.out.println();
			}
		} // fine if(debug)
		
	}
	
	public Soluzione solveProblem(IInstance inst) throws IOException{
		Soluzione soluzione = new Soluzione();
		soluzione.elementi = new Vector<Elemento_soluzione>();
		Vector<Vector<Cliente>> ClusterSet = clustering(inst);
		heterogeneous_assignment(ClusterSet, soluzione, inst);
		calcola_funzione_obiettivo(soluzione,inst);	
		return soluzione;
	}
	
	public void printSolution(Soluzione soluzione, IInstance inst){
		int i,j;
		// qua si riporta tutto alla scala naturale (min) per facilitare le successive stampe
		for(i=0;i<soluzione.elementi.size();i++){
			for(j=0;j<soluzione.elementi.get(i).pacchi_assegnati.size();j++){
				soluzione.elementi.get(i).pacchi_assegnati.get(j).LST *= inst.get_scalatempo();
				soluzione.elementi.get(i).pacchi_assegnati.get(j).ora_arrivo_stimata *= inst.get_scalatempo();
			}
		}
		
		System.out.println("Sono stati impiegati "+soluzione.elementi.size()+" veicoli");
		System.out.println("La distanza percorsa � di "+soluzione.funzione_obiettivo +" metri");
		System.out.println("Dettagli su ciascun veicolo:");
		for(i=0;i<soluzione.elementi.size();i++){
			System.out.println("Veicolo utilizzato: "+soluzione.elementi.get(i).veicolo_usato.ID_veicolo);
			System.out.println("Alimentazione: "+soluzione.elementi.get(i).veicolo_usato.Carburante);
			System.out.println("Autista: "+soluzione.elementi.get(i).veicolo_usato.ID_autista);
			System.out.println("Capacit� utile:"+soluzione.elementi.get(i).veicolo_usato.capacit�);
			System.out.println("Portata utile:"+soluzione.elementi.get(i).veicolo_usato.portata);
			System.out.println("Pacchi assegnati:");
			System.out.println("BARCODE" + "\t" + "ORIGINE"+"\t"+"DESTINAZIONE"+"\t"+"PESO"+"\t"+"VOLUME"+"\t"+"LST"+"\t"+"ORARIO STIMATO");
			for(j=0;j<soluzione.elementi.get(i).pacchi_assegnati.size();j++){	// si evita di stampare i pacchi fittizi, anche se in multidepot ci servir� stampare il deposito di ritorno
				int ora_LST = (int) (inst.get_baseline() + soluzione.elementi.get(i).pacchi_assegnati.get(j).LST/60);
				int aux_minuti_LST = (int) (soluzione.elementi.get(i).pacchi_assegnati.get(j).LST % 60);
				String minuti_LST;
				if(aux_minuti_LST>=10){
					minuti_LST = String.valueOf(aux_minuti_LST);
				}else{minuti_LST = "0"+String.valueOf(aux_minuti_LST);}
				
				int ora = (int) (inst.get_baseline() + soluzione.elementi.get(i).pacchi_assegnati.get(j).ora_arrivo_stimata/60);
				int aux_minuti = (int) (soluzione.elementi.get(i).pacchi_assegnati.get(j).ora_arrivo_stimata % 60);
				String minuti;
				if(aux_minuti>=10){
					minuti = String.valueOf(aux_minuti);
				}else{minuti = "0"+String.valueOf(aux_minuti);}
				
				System.out.println(soluzione.elementi.get(i).pacchi_assegnati.get(j).Barcode + "\t" +soluzione.elementi.get(i).pacchi_assegnati.get(j).Origine +"\t"+soluzione.elementi.get(i).pacchi_assegnati.get(j).Destinazione+"\t"+soluzione.elementi.get(i).pacchi_assegnati.get(j).peso+"\t"+soluzione.elementi.get(i).pacchi_assegnati.get(j).volume+"\t"+ora_LST+":"+minuti_LST+"\t"+ora+":"+minuti);
			}
			calcola_tempo_percorrenza(soluzione.elementi.get(i));
		}
		
		for(i=0;i<soluzione.elementi.size();i++){
			for(j=0;j<soluzione.elementi.get(i).pacchi_assegnati.size();j++){
				soluzione.elementi.get(i).pacchi_assegnati.get(j).LST /= inst.get_scalatempo();
				soluzione.elementi.get(i).pacchi_assegnati.get(j).ora_arrivo_stimata /= inst.get_scalatempo();
			}
		}
		
	}
	
	public Soluzione localSearch(Soluzione soluzione, IInstance inst) throws IOException{
		soluzione = inter_route_moves(soluzione, inst);	
		soluzione = intra_route_moves(soluzione, inst);
		return soluzione;
	}
	
	/*** CLUSTERING 
	 * Viene effettuato il clustering dei clienti. Per prima cosa viene applicato l'algoritmodi PRIM
	 ***/
	public Vector<Vector<Cliente>> clustering(IInstance inst) throws IOException{
		double costo_min_span_tree = Prim(inst);
		System.out.println(costo_min_span_tree);
		double alpha = 2;	// coefficiente moltiplicativo (>=1)
		int K = (int) Math.ceil(((costo_min_span_tree * alpha)/(inst.get_speed()/3.6))/(36000));	// numero di cluster da passare a K-Means. Si divide per 3.6 per passare da km/h a m/s, dopodich� si divide per 36000 che corrisponde al time-span, ovvero ai secondi presenti nelle 10 ori corrispondenti alla giornata lavorativa
		System.out.println("K-Means lavora con "+K+" cluster");
		Vector<Vector<Cliente>> ClusterSet = new Vector<Vector<Cliente>>();
		Vector<Cliente> Lista_Clienti = new Vector<Cliente>();
		Lista_Clienti = inst.get_customermatrix();
		KMeans cluster = new KMeans(); 
		cluster.initialize(K,Lista_Clienti);
		ClusterSet = cluster.kMeanCluster(K,Lista_Clienti,inst.get_typeInstance());
		int i,j;
		for(i=0;i<ClusterSet.size();i++){
			for(j=0;j<ClusterSet.get(i).size();j++){
				nearest_neighbor_distandtime(ClusterSet.get(i),inst);
			}
		}
		
		boolean debug = true;
		if(debug){
			StampaCluster(inst,ClusterSet);
		}
		
		return ClusterSet;
		
	}

	public void heterogeneous_assignment(Vector<Vector<Cliente>> ClusterSet, Soluzione soluzione, IInstance inst) throws IOException{
		order_vehicles(inst);
		assign_packages(ClusterSet, soluzione, inst);
		if(!check_times(soluzione)){
			System.out.println("errore");
		}
	}
	
	/*** IMPROVEMENT
	 * In questa sezione si trovano le mosse di miglioramento
	 */

	/* INTRA-ROUTE IMPROVEMENT */
	
	// metti anche il numero di cicli effettuati da ciascuna mossa.
	
	public Soluzione inter_route_moves(Soluzione soluzione, IInstance inst) throws IOException{
		boolean go_on = true;

		/* Use of L_exchange */
		System.out.println("� il turno di L_EXCHANGE!");
		int L = 5;		// da capire come sceglierlo
		while(go_on){
			if(L_exchange(soluzione, inst, L)){
				go_on = true;
			}else{go_on = false;}
		}
		go_on = true;
		
		PrintStream solutionExchange;
		if(inst.get_typeInstance()==0){
			solutionExchange = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\solution\\solutionExchange.txt"));
		}else{solutionExchange = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstance\\solution\\solutionExchange.txt"));}
		System.setOut(solutionExchange);
		printSolution(soluzione, inst);
		
		System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
		
		System.out.println("� il turno di L_RELOCATE!");
		
		while(go_on){
			if(L_relocate(soluzione, inst, L)){
				go_on = true;
			}else{go_on = false;}
		}
		
		PrintStream solutionRelocate;
		if(inst.get_typeInstance()==0){
			solutionRelocate = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\solution\\solutionRelocate.txt"));
		}else{solutionRelocate = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstance\\solution\\solutionRelocate.txt"));}
		System.setOut(solutionRelocate);
		printSolution(soluzione, inst);
		
		System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
		
		return soluzione;
	}
	
	public Soluzione intra_route_moves(Soluzione soluzione, IInstance inst) throws IOException{
		boolean go_on;
		/* use of two_swap */
		System.out.println("E' il turno di two_swap!");
		for(int i=0;i<soluzione.elementi.size();i++){
			// le mosse sono intra-route. Passo al veicolo successivo solo quando non posso pi� effettuare alcuna mossa sul veicolo corrente.
			go_on = true;
			while(go_on){	
				if(two_swap(soluzione.elementi.get(i),inst)){
					go_on = true;
				}else{go_on = false;}
			}
		}
		
		calcola_funzione_obiettivo(soluzione,inst);
		PrintStream solutionTwoSwap;
		if(inst.get_typeInstance()==0){
			solutionTwoSwap = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\solution\\solutionTwoSwap.txt"));
		}else{solutionTwoSwap = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstance\\solution\\solutionTwoSwap.txt"));}
		System.setOut(solutionTwoSwap);
		printSolution(soluzione, inst);
		
		System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
		
		/* use of OR_OPT */
		
		System.out.println("E' il turno di OR_OPT!");
		for(int i=0;i<soluzione.elementi.size();i++){
			go_on = true;
			int L = 5;
			while(go_on){	
				if(OR_OPT(soluzione.elementi.get(i),inst, L)){
					go_on = true;
				}else{go_on = false;}
			}
		}
		
		/* use of TWO_OPT */
		
		calcola_funzione_obiettivo(soluzione,inst);
		PrintStream solutionOROPT;
		if(inst.get_typeInstance()==0){
			solutionOROPT = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\solution\\solutionOROPT.txt"));
		}else{solutionOROPT = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstance\\solution\\solutionOROPT.txt"));}
		System.setOut(solutionOROPT);
		printSolution(soluzione, inst);
		
		System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
		
		System.out.println("E' il turno di 2_OPT!");
		for(int i=0;i<soluzione.elementi.size();i++){
			go_on = true;
			while(go_on){	
				if(two_OPT(soluzione.elementi.get(i),inst)){
					go_on = true;
				}else{go_on = false;}
			}
		}
		
		calcola_funzione_obiettivo(soluzione,inst);
		PrintStream solutionTWO_OPT;
		if(inst.get_typeInstance()==0){
			solutionTWO_OPT = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\solution\\solutionTWO_OPT.txt"));
		}else{solutionTWO_OPT = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstance\\solution\\solutionTWO_OPT.txt"));}
		System.setOut(solutionTWO_OPT);
		printSolution(soluzione, inst);
		
		System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
		
		return soluzione;
	}
	
	/* L-EXCHANGE 
	 * Descrivi mossa perbene.
	 * 
	 */
	
	public boolean L_exchange(Soluzione soluzione, IInstance inst, int L) throws IOException{
		boolean ris = false;
		Soluzione copia = new Soluzione();
		copy_solution(soluzione,copia); // il metodo copia "soluzione" in "copia";
		//System.out.println("copia size veicoli = "+copia.elementi.size());
		//System.out.println("copia f.o. = "+copia.funzione_obiettivo);
		boolean trovato = false;
		int l,h,k;
		int i,j;
		
		PrintStream debug = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\solution\\debug.txt"),true);
		
		
		for(l = 1; l<=L && !trovato; l++){		
		Vector <saving_exchange> savings = new Vector <saving_exchange>();
		for(h=0;h<copia.elementi.size();h++) {			// parti da un veiucolo
			for(k=h+1;k<copia.elementi.size(); k++) {		// guardi tutti gli altri veicoli possibili 
				for(i=1;i<copia.elementi.get(h).pacchi_assegnati.size()-l;i++) {			//evito il magazzino
					for(j=1;j<copia.elementi.get(k).pacchi_assegnati.size()-l;j++) {
						saving_exchange saving = new saving_exchange();
						saving.ID_veicolo1 = h;		// veicolo che visita inizialmente i
						saving.ID_veicolo2 = k;		// veicolo che visita inizialmente j
						//saving.pos_clienti_uscita_veicolo1 = new Vector<>();	// sono i, i+1, ..., i+l-1, che dal veicolo 1 vanno al veicolo 2
						//saving.pos_clienti_uscita_veicolo2 = new Vector<>();	// sono j, j+1, ..., j+l-1, che dal veicolo 2 vanno al veicolo 1
						saving.pos_clienti_uscita_veicolo1 = i; // � il primo cliente che esce dal veicolo 1 verso il veicolo 2
						saving.pos_clienti_uscita_veicolo2 = j;

						int pos_h1i, pos_hi, pos_kj, pos_k1j, pos_hi1L, pos_hiL, pos_kjL, pos_kj1L; 	// pos_hiL � pos_h_i+L mentre pos_h1i � pos_h_i-1.
						pos_h1i = inst.find_position1(copia.elementi.get(h).pacchi_assegnati.get(i-1).Destinazione);
						pos_hi = inst.find_position1(copia.elementi.get(h).pacchi_assegnati.get(i).Destinazione);	// guardo la posizione del cliente i del veicolo h
						pos_kj = inst.find_position1(copia.elementi.get(k).pacchi_assegnati.get(j).Destinazione);
						pos_k1j = inst.find_position1(copia.elementi.get(k).pacchi_assegnati.get(j-1).Destinazione);
						pos_hi1L = inst.find_position1(copia.elementi.get(h).pacchi_assegnati.get(i+l-1).Destinazione);
						pos_hiL = inst.find_position1(copia.elementi.get(h).pacchi_assegnati.get(i+l).Destinazione);
						pos_kjL = inst.find_position1(copia.elementi.get(k).pacchi_assegnati.get(j+l).Destinazione);
						pos_kj1L = inst.find_position1(copia.elementi.get(k).pacchi_assegnati.get(j+l-1).Destinazione);

						saving.value = inst.get_distmatrix()[pos_h1i][pos_hi] - inst.get_distmatrix()[pos_h1i][pos_kj] + inst.get_distmatrix()[pos_k1j][pos_kj] - inst.get_distmatrix()[pos_k1j][pos_hi] + inst.get_distmatrix()[pos_hi1L][pos_hiL] - inst.get_distmatrix()[pos_hi1L][pos_kjL] + inst.get_distmatrix()[pos_kj1L][pos_kjL] - inst.get_distmatrix()[pos_kj1L][pos_hiL]; 
						if(saving.value > 0) {
							savings.add(saving);
						}
					}
				}
			}
		}

		// Uso di un proprio comparatore
		Collections.sort(savings,new saving_exchange());	
		//System.out.println("Lambda is: "+l+" and EXCHANGE Savings size: "+savings.size());
		
		/* stampa dei savings
		for(i=0;i<savings.size();i++){
			System.out.println("Saving numero "+i);
			System.out.println("Veicolo 1 = "+savings.get(i).ID_veicolo1);
			System.out.println("Cliente 1 = "+copia.elementi.get(savings.get(i).ID_veicolo1).pacchi_assegnati.get(savings.get(i).pos_clienti_uscita_veicolo1).Destinazione);
			System.out.println("Veicolo 2 = "+savings.get(i).ID_veicolo2);
			System.out.println("Cliente 2 = "+copia.elementi.get(savings.get(i).ID_veicolo2).pacchi_assegnati.get(savings.get(i).pos_clienti_uscita_veicolo2).Destinazione);
		}*/

		for(i=0;i<savings.size() && !trovato;i++) {	// qua si provano i savings a fare 
			Soluzione copia2 = new Soluzione();	// copia2 serve per provare il saving in questione
			copy_solution(copia, copia2);
			//System.out.println("Lambda vale: "+l+", provo a scambiare il cliente "+copia2.elementi.get(savings.get(i).ID_veicolo1).pacchi_assegnati.get(savings.get(i).pos_clienti_uscita_veicolo1).Destinazione+" del veicolo "+savings.get(i).ID_veicolo1 +" con il cliente " +copia2.elementi.get(savings.get(i).ID_veicolo2).pacchi_assegnati.get(savings.get(i).pos_clienti_uscita_veicolo2).Destinazione+" del veicolo "+savings.get(i).ID_veicolo2+" per ottenere un saving di "+savings.get(i).value);
			// mi servono 2 vector di pacchi_assegnati della soluzione: uno per il veicolo 1 e l'altro per il 2. Dovr� swappare i clienti

			Vector<Pacco_assegnato> aux1 = new Vector<Pacco_assegnato>();	// clienti (ovvero pacchi) del veicolo 1 che andranno nel veicolo 2
			Vector<Pacco_assegnato> aux2 = new Vector<Pacco_assegnato>();	// clienti (ovvero pacchi) del veicolo 2 che andranno nel veicolo 1

			// aggiungo i pacchi "ordinari" in aux1
			for(int r = 0; r < l; r++){
				Pacco_assegnato aus1 = new Pacco_assegnato();
				aus1 = copia2.elementi.get(savings.get(i).ID_veicolo1).pacchi_assegnati.get(savings.get(i).pos_clienti_uscita_veicolo1 + r);
				aux1.addElement(aus1);
			}
			
			boolean doppione1 = true;
			int counter1 = 1;
			int elimina1 = 0;	// sono i clienti eliminati prima del primo elemento del veicolo 1, da non considerare pi� avanti
			
			// cerco i doppioni (prima del primo elemento) del veicolo 1 da mettere in aux1
			while(doppione1 && (savings.get(i).pos_clienti_uscita_veicolo1-counter1)>0 ){
				if(aux1.firstElement().Destinazione.equals(copia2.elementi.get(savings.get(i).ID_veicolo1).pacchi_assegnati.get(savings.get(i).pos_clienti_uscita_veicolo1-counter1).Destinazione )){
					Pacco_assegnato doppio1 = new Pacco_assegnato();
					doppio1 = copia2.elementi.get(savings.get(i).ID_veicolo1).pacchi_assegnati.get(savings.get(i).pos_clienti_uscita_veicolo1-counter1);
					aux1.add(0, doppio1);
					counter1++;
					
					copia2.elementi.get(savings.get(i).ID_veicolo1).pacchi_assegnati.remove(savings.get(i).pos_clienti_uscita_veicolo1-1);
					savings.get(i).pos_clienti_uscita_veicolo1--;
					elimina1++;
					
				}else{doppione1=false;}
			}
			
			// cerco i doppioni (dopo ultimo elemento) del veicolo 1 da mettere in aux1
			doppione1 = true;
			counter1 = l;			
			while(doppione1 && (savings.get(i).pos_clienti_uscita_veicolo1+counter1)<copia2.elementi.get(savings.get(i).ID_veicolo1).pacchi_assegnati.size() ){
				if(aux1.lastElement().Destinazione.equals(copia2.elementi.get(savings.get(i).ID_veicolo1).pacchi_assegnati.get(savings.get(i).pos_clienti_uscita_veicolo1+counter1).Destinazione )){
					Pacco_assegnato doppio1 = new Pacco_assegnato();
					doppio1 = copia2.elementi.get(savings.get(i).ID_veicolo1).pacchi_assegnati.get(savings.get(i).pos_clienti_uscita_veicolo1+counter1);
					aux1.addElement(doppio1);
					counter1++;
				}else{
					doppione1=false;
					}
			}
			
			// aggiungo i pacchi "ordinari" in aux2
			for(int r = 0; r < l; r++){
				Pacco_assegnato aus2 = new Pacco_assegnato();
				aus2 = copia2.elementi.get(savings.get(i).ID_veicolo2).pacchi_assegnati.get(savings.get(i).pos_clienti_uscita_veicolo2 + r);
				aux2.addElement(aus2);
			}
			
			boolean doppione2 = true;
			int counter2 = 1;
			int elimina2 = 0;	// sono i clienti eliminati prima del primo elemento del veicolo 2, da non considerare pi� avanti
			
			// cerco i doppioni (prima del primo elemento) del veicolo 2 da mettere in aux1
			while(doppione2 && (savings.get(i).pos_clienti_uscita_veicolo2-counter2)>0 ){
				if(aux2.firstElement().Destinazione.equals(copia2.elementi.get(savings.get(i).ID_veicolo2).pacchi_assegnati.get(savings.get(i).pos_clienti_uscita_veicolo2-counter2).Destinazione )){
					Pacco_assegnato doppio2 = new Pacco_assegnato();
					doppio2 = copia2.elementi.get(savings.get(i).ID_veicolo2).pacchi_assegnati.get(savings.get(i).pos_clienti_uscita_veicolo2-counter2);
					aux2.add(0, doppio2);;
					counter2++;
					
					copia2.elementi.get(savings.get(i).ID_veicolo2).pacchi_assegnati.remove(savings.get(i).pos_clienti_uscita_veicolo2-1);
					savings.get(i).pos_clienti_uscita_veicolo2--;
					elimina2++;
					
				}else{doppione2=false;}
			}
			
			// cerco i doppioni (dopo l'ultimo elemento) del veicolo 2 da mettere in aux2
			doppione2 = true;
			counter2 = l;
			while(doppione2 && (savings.get(i).pos_clienti_uscita_veicolo2+counter2)<copia2.elementi.get(savings.get(i).ID_veicolo2).pacchi_assegnati.size() ){
				if(aux2.lastElement().Destinazione.equals(copia2.elementi.get(savings.get(i).ID_veicolo2).pacchi_assegnati.get(savings.get(i).pos_clienti_uscita_veicolo2+counter2).Destinazione )){
					Pacco_assegnato doppio2 = new Pacco_assegnato();
					doppio2 = copia2.elementi.get(savings.get(i).ID_veicolo2).pacchi_assegnati.get(savings.get(i).pos_clienti_uscita_veicolo2+counter2);
					aux2.addElement(doppio2);
					counter2++;
				}else{doppione2=false;}
			}

			int r;
			
			// VEICOLO 1
			//tolgo dal veicolo 1 i pacchi che andranno nel veicolo 2
			for(r=0; r<aux1.size()-elimina1;r++){
				copia2.elementi.get(savings.get(i).ID_veicolo1).pacchi_assegnati.removeElementAt(savings.get(i).pos_clienti_uscita_veicolo1);
			}
			//aggiungo al veicolo 1 i pacchi contenuti in aux2, togliendone capacit� e peso e ridandone al veicolo 2
			for(r=aux2.size()-1;r>=0;r--){
				copia2.elementi.get(savings.get(i).ID_veicolo1).pacchi_assegnati.add(savings.get(i).pos_clienti_uscita_veicolo1, aux2.get(r));
				copia2.elementi.get(savings.get(i).ID_veicolo1).veicolo_usato.capacit� -= aux2.get(r).volume;
				copia2.elementi.get(savings.get(i).ID_veicolo1).veicolo_usato.portata -= aux2.get(r).peso;
				copia2.elementi.get(savings.get(i).ID_veicolo2).veicolo_usato.capacit� += aux2.get(r).volume;
				copia2.elementi.get(savings.get(i).ID_veicolo2).veicolo_usato.portata += aux2.get(r).peso;
			}
			
			// VEICOLO 2
			//tolgo dal veicolo 2 i pacchi che sono andati nel veicolo 1
			for(r=0; r<aux2.size()-elimina2;r++){
				copia2.elementi.get(savings.get(i).ID_veicolo2).pacchi_assegnati.removeElementAt(savings.get(i).pos_clienti_uscita_veicolo2);
			}
			//aggiungo al veicolo 2 i pacchi contenuti in aux1, togliendone capacit� e peso e ridandone al veicolo 1
			for(r=aux1.size()-1;r>=0;r--){
				copia2.elementi.get(savings.get(i).ID_veicolo2).pacchi_assegnati.add(savings.get(i).pos_clienti_uscita_veicolo2, aux1.get(r));
				copia2.elementi.get(savings.get(i).ID_veicolo2).veicolo_usato.capacit� -= aux1.get(r).volume;
				copia2.elementi.get(savings.get(i).ID_veicolo2).veicolo_usato.portata -= aux1.get(r).peso;
				copia2.elementi.get(savings.get(i).ID_veicolo1).veicolo_usato.capacit� += aux1.get(r).volume;
				copia2.elementi.get(savings.get(i).ID_veicolo1).veicolo_usato.portata += aux1.get(r).peso;
			}
			
			ricalcola_arrivi(copia2.elementi.get(savings.get(i).ID_veicolo1),inst);
			ricalcola_arrivi(copia2.elementi.get(savings.get(i).ID_veicolo2),inst);	
			
			// ORA CONTROLLIAMO I VINCOLI DI TEMPO, PESO E VOLUME
			if(check_times(copia2) && copia2.elementi.get(savings.get(i).ID_veicolo1).veicolo_usato.capacit� > 0 && copia2.elementi.get(savings.get(i).ID_veicolo1).veicolo_usato.portata > 0 && copia2.elementi.get(savings.get(i).ID_veicolo2).veicolo_usato.capacit� > 0 && copia2.elementi.get(savings.get(i).ID_veicolo2).veicolo_usato.portata > 0) {
				calcola_funzione_obiettivo(copia2, inst);
				if(copia2.funzione_obiettivo < copia.funzione_obiettivo) {
					trovato = true;
					//System.out.println("Siamo passati da "+copia.funzione_obiettivo+" a: "+copia2.funzione_obiettivo);
					//System.out.println("Swap ok!");
					copy_solution(copia2, copia);
				}else {
					//System.out.println("nuova f.o. = "+copia2.funzione_obiettivo);
					//System.out.println("vecchia f.o. = "+copia.funzione_obiettivo);
					//System.out.println("lambda vale "+l+" e ho provato a scambiare a partire dal cliente  "+copia.elementi.get(savings.get(i).ID_veicolo1).pacchi_assegnati.get(savings.get(i).pos_clienti_uscita_veicolo1).Destinazione+" del veicolo "+ savings.get(i).ID_veicolo1+" con il cliente " +copia.elementi.get(savings.get(i).ID_veicolo2).pacchi_assegnati.get(savings.get(i).pos_clienti_uscita_veicolo2).Destinazione +" del veicolo "+savings.get(i).ID_veicolo2 +" nella speranza di risparmiare: "+savings.get(i).value );
					printSolution(copia2, inst);
					System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
					//System.out.println("Peggioro la distanza, NO swap");
				}
			}else {
				//System.out.println("No swap (soluzione non ammissibile)");
			}

		}	// fine del for sui saving per lambda = l

	}	// fine del for su lambda
		
	if(trovato==true){	// basta 1 solo "trovato"
		//System.out.println("Siamo passati da "+soluzione.funzione_obiettivo+" a "+copia.funzione_obiettivo);
		copy_solution(copia,soluzione);
		ris = true;
	}
	else {
	ris = false;
	}
	
	
	return ris;
	}

	/* L relocate
	 * Descrivi perbene anche questo metodo. Qua non � necessario un controllo stretto sui doppioni, basta che L sia abbastanza grande per gestirli!
	 * Mentre prima era necessario perch� si poteva avere uno scambio 2 o 3 a 1 (a livello di pacchi), qua lo scambio � tutto a 0, ci vuole solo un lambda piuttosto grande affinch� l'algoritmo si accorga dei doppioni.
	*/
	public boolean L_relocate(Soluzione soluzione, IInstance inst, int L) throws IOException{
		boolean ris = false;
		
		int i,j;
		int h,k;
		boolean trovato = false;
		Soluzione copia = new Soluzione();
		copy_solution(soluzione,copia);				
		
		for(int l = 1; l<=L ; l++){
		Vector <saving_relocate> savings = new Vector <saving_relocate>();
			for(h=0;h<copia.elementi.size();h++) {		// qua si va a studiare tutte le coppie possibili di veicoli
				for(k=0;k<copia.elementi.size(); k++) {
					if( k!=h){	// se i veicoli sono diversi...
						for(i=1;i<copia.elementi.get(h).pacchi_assegnati.size()-l-1;i++) {		
							for(j=1;j<copia.elementi.get(k).pacchi_assegnati.size()-l-1;j++) {
									saving_relocate saving = new saving_relocate();
									saving.pos_clienti_uscita = new Vector<>();
									saving.ID_veicolo1 = h;		// veicolo del cliente i, che CEDE
									saving.ID_veicolo2 = k;		// veicolo del cliente j, che PRENDE
									for(int counter = 0; counter < l; counter++){
										saving.pos_clienti_uscita.add(i+counter);
									}
									int pos_h1i = inst.find_position1(copia.elementi.get(h).pacchi_assegnati.get(i-1).Destinazione);
									int pos_hi = inst.find_position1(copia.elementi.get(h).pacchi_assegnati.get(i).Destinazione);
									int pos_kj = inst.find_position1(copia.elementi.get(k).pacchi_assegnati.get(j).Destinazione);
									int pos_kj1 = inst.find_position1(copia.elementi.get(k).pacchi_assegnati.get(j+1).Destinazione);
									int pos_hi1l = inst.find_position1(copia.elementi.get(h).pacchi_assegnati.get(i+l-1).Destinazione);
									int pos_hil = inst.find_position1(copia.elementi.get(h).pacchi_assegnati.get(i+l).Destinazione);
									
									saving.swap2 = j;
									saving.value = inst.get_distmatrix()[pos_h1i][pos_hi] + inst.get_distmatrix()[pos_kj][pos_kj1] + inst.get_distmatrix()[pos_hi1l][pos_hil] - inst.get_distmatrix()[pos_h1i][pos_hil] - inst.get_distmatrix()[pos_kj][pos_hi] - inst.get_distmatrix()[pos_hi1l][pos_kj1];
									if(saving.value > 0) {
										savings.add(saving);
									}
								}
							}
						}
					}
				}
				// Uso di un proprio comparatore
				Collections.sort(savings,new saving_relocate());	// ho la mia lista di savings sortati per un determinato lambda
				//System.out.println("Per lambda = "+l+" il numero di savings da provare sono: "+savings.size());
				
				boolean ferma = false;	// questo booleano varr� true quando l'algoritmo deve fermarsi, ovvero quando l'i-esimo saving, se pur feasible, porta a peggiorare la soluzione (se l'algoritmo accetta tutti i savings si ferma comunque quando non ce ne sono pi�)

				for(i=0;i<savings.size() && !ferma;i++) {
					Soluzione copia2 = new Soluzione();
					copy_solution(copia,copia2);	// mi faccio una copia della copia. Questa 2� copia serve per provare il saving i-esimo. Se va bene si aggiorna copiasoluzione (e si continua) altrimenti non si aggiorna copiasoluzione.
					Vector<Pacco_assegnato> aux2 = new Vector <Pacco_assegnato>();	// aux2 � il vector di pacchi del veicolo k (tirante). Esso deve contenere gli ID dei clienti relativi alle posizioni indicate da ID_clienti_uscita, trovabili andando a cercare in copiasoluzione2.get(veicolo1).route.get(pos_clienti_uscita.get(pos)).cliente_ID						
					for(int r = 0; r <savings.get(i).pos_clienti_uscita.size(); r++){
						Pacco_assegnato aux = new Pacco_assegnato();
						aux = copia2.elementi.get(savings.get(i).ID_veicolo1).pacchi_assegnati.get(savings.get(i).pos_clienti_uscita.get(r));
						aux2.add(aux);
					}
					System.out.println();

					for(int counter = 0; counter < l; counter++){
						//System.out.println("Veicolo tirante size prima: "+copia2.elementi.get(savings.get(i).ID_veicolo2).pacchi_assegnati.size());
						copia2.elementi.get(savings.get(i).ID_veicolo2).pacchi_assegnati.add(savings.get(i).swap2 + 1 + counter, aux2.get(counter));		// aggiungo tutti i clienti in uscita di ID_clienti_uscita nel veicolo 2, che � quello "tirante". Lo faccio partendo dalla posizione j+1 e terminando a j+lambda
						copia2.elementi.get(savings.get(i).ID_veicolo2).veicolo_usato.capacit� -= aux2.get(counter).volume;
						copia2.elementi.get(savings.get(i).ID_veicolo2).veicolo_usato.portata -= aux2.get(counter).peso;
						
						copia2.elementi.get(savings.get(i).ID_veicolo1).veicolo_usato.capacit� += aux2.get(counter).volume;
						copia2.elementi.get(savings.get(i).ID_veicolo1).veicolo_usato.portata += aux2.get(counter).peso;
						
					}
					
					for(int p = 0; p<savings.get(i).pos_clienti_uscita.size();p++){
						copia2.elementi.get(savings.get(i).ID_veicolo1).pacchi_assegnati.removeElementAt(savings.get(i).pos_clienti_uscita.get(0));	
					}
					
					/*System.out.println("Veicolo cedente size dopo: "+copia2.elementi.get(savings.get(i).ID_veicolo1).pacchi_assegnati.size());
					
					System.out.println("Ecco la nuova route (prima del controllo) del veicolo "+savings.get(i).ID_veicolo1);
					for(int y = 0; y < copia2.elementi.get(savings.get(i).ID_veicolo1).pacchi_assegnati.size() ; y++){
						System.out.println(copia2.elementi.get(savings.get(i).ID_veicolo1).pacchi_assegnati.get(y).Destinazione);
					}*/
					
					ricalcola_arrivi(copia2.elementi.get(savings.get(i).ID_veicolo2),inst);
					ricalcola_arrivi(copia2.elementi.get(savings.get(i).ID_veicolo1),inst);
					
					// calcola la nuova funzione obiettivo
					calcola_funzione_obiettivo(copia2,inst);	

					// ORA CONTROLLIAMO I VINCOLI DI TEMPO, PESO E VOLUME ( e controlla funzione obiettivo)
					if(check_times(copia2) && copia2.elementi.get(savings.get(i).ID_veicolo2).veicolo_usato.capacit� > 0 && copia2.elementi.get(savings.get(i).ID_veicolo2).veicolo_usato.portata > 0 ) {
						double epsilon = 0.05;
						if(copia2.funzione_obiettivo > copia.funzione_obiettivo - epsilon){	// la nuova funzione obiettivo � peggiore. Se siamo all'ultimo lambda dobbiamo uscire dal programma
						ferma = true;
						}else{
							// aggiorna la funzione obiettivo
							ferma = true;
							trovato = true;
							copy_solution(copia2,copia);						
						}
					}else{
						//System.out.println("Soluzione infeasible, riprovo con un altro saving");
					}
				}	// ho finito con l'i-esimo saving.
				//System.out.println("Savings size per lambda = "+l+" --> "+ savings.size());
				// si riparte con lambda++
			}	
		
		if(trovato == true) {		// basta che ci sia stato un miglioramento per far ritornare al metodo "copiasoluzione"
			//System.out.println("la f.o. � passata da "+soluzione.funzione_obiettivo+" a "+copia.funzione_obiettivo);
			System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
			copy_solution(copia,soluzione); // posso aggiornare la vecchia soluzione con quella nuova.
			
			// controlla che non ci siano elementi vuoti.
			boolean delete = false;			// permette di non commettere errori sull'indice del veicolo da rimuovere
			boolean deletone = true;		// permette di cancellare pi� veicoli
			while(deletone){
				for(int v = 0;v<soluzione.elementi.size() && !delete;v++){
					if(soluzione.elementi.get(v).pacchi_assegnati.size()==0){
						soluzione.elementi.remove(v);
						delete = true;
					}
				}
				if(!delete){
					deletone = false;
				}
			}
			
			ris = true;
		}
		else {
		ris = false;
		}
		
		return ris;
	}

	/* 2-SWAP 
	 * Mossa di tipo intra-route che ...
	 */
	
	public boolean two_swap(Elemento_soluzione elemento, IInstance inst) throws IOException{
		boolean ris = false;
		int i,j;
		PrintStream debug = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\solution\\debug.txt", true));
		Elemento_soluzione copia = new Elemento_soluzione();
		copy_element(elemento,copia);
		
		//System.out.println("Si ragiona del veicolo "+copia.veicolo_usato.ID_veicolo);
		
		// all'inizio ci facciamo una copia senza doppioni dei pacchi
		
		Elemento_soluzione copia2 = new Elemento_soluzione(); 	// � una copia di "copia" che non ha doppioni
		copy_element(copia,copia2);
		
		for(int m = 1; m<copia2.pacchi_assegnati.size()-2; m++){
			for(int n = m+1; n<copia2.pacchi_assegnati.size()-1;n++){
				if(copia2.pacchi_assegnati.get(m).Destinazione.equals(copia2.pacchi_assegnati.get(n).Destinazione)){
					copia2.pacchi_assegnati.remove(n);
					n--;
				}
			}
		}
				
		// ora andiamo a individuare la posizione iniziale di ciascun elemento di copia2 in copia
		int[] pos_iniziali = new int[copia2.pacchi_assegnati.size()];
		int[] pos_finali = new int[copia2.pacchi_assegnati.size()];
		for(int m = 1; m<copia2.pacchi_assegnati.size()-1;m++){
			boolean auxbool = true;
			for(int n=1; n<copia.pacchi_assegnati.size()-1 && auxbool;n++){
				if(copia2.pacchi_assegnati.get(m).Destinazione.equals(copia.pacchi_assegnati.get(n).Destinazione)){	// se le destinazioni corrispondono
					auxbool = false;
					pos_iniziali[m]=n;
					boolean auxbool2 = true;
					int auxcount = 1;
					while(auxbool2){
						pos_finali[m]=n+auxcount-1;
						if(copia2.pacchi_assegnati.get(m).Destinazione.equals(copia.pacchi_assegnati.get(n+auxcount).Destinazione)){
							auxcount++;
						}else{auxbool2 = false;}
					}
				}
			}
		}
		
		/* Le posizioni iniziali e finali sono prese correttamente
		for(i=0;i<copia2.pacchi_assegnati.size();i++){
			System.out.println(pos_iniziali[i]+"\t"+pos_finali[i]);
		}*/
		
		Vector <saving_intra> savings = new Vector<saving_intra>();
		Vector <saving_intra> hopesavings = new Vector<saving_intra>();		// vector per savings nulli
		
		for(i=1;i<copia2.pacchi_assegnati.size()-2;i++) {	// L'inizio e la fine non ci interessano perch� ci sta il deposito. Se la size della route fosse proprio 2 il veicolo non dovrebbe esister
			for(j=i+1; j<copia2.pacchi_assegnati.size()-1; j++) {
				saving_intra saving = new saving_intra();
				saving.indirizzo1 = copia2.pacchi_assegnati.get(i).Destinazione;
				saving.indirizzo2 = copia2.pacchi_assegnati.get(j).Destinazione;

				int pos_i1, pos_j, pos_i, pos_1j, pos_j1, pos_1i;
				pos_1i = inst.find_position1(copia2.pacchi_assegnati.get(i-1).Destinazione);
				pos_j = inst.find_position1(copia2.pacchi_assegnati.get(j).Destinazione);
				pos_i = inst.find_position1(copia2.pacchi_assegnati.get(i).Destinazione);
				pos_j1 = inst.find_position1(copia2.pacchi_assegnati.get(j+1).Destinazione);
				pos_i1 = inst.find_position1(copia2.pacchi_assegnati.get(i+1).Destinazione);
				pos_1j = inst.find_position1(copia2.pacchi_assegnati.get(j-1).Destinazione);				

				if(j== i +1) {	// significa che i clienti i e j sono adiacenti
					// System.out.println("i clienti sono adiacenti!");
					saving.value = - inst.get_distmatrix()[pos_1i][pos_j] - inst.get_distmatrix()[pos_j][pos_i] - inst.get_distmatrix()[pos_i][pos_j1] + inst.get_distmatrix()[pos_1i][pos_i] + inst.get_distmatrix()[pos_i][pos_j] + inst.get_distmatrix()[pos_j][pos_j1] ;
				}else {
					saving.value = - inst.get_distmatrix()[pos_1i][pos_j] - inst.get_distmatrix()[pos_j][pos_i1] - inst.get_distmatrix()[pos_1j][pos_i] - inst.get_distmatrix()[pos_i][pos_j1] + inst.get_distmatrix()[pos_1i][pos_i] + inst.get_distmatrix()[pos_i][pos_i1] + inst.get_distmatrix()[pos_1j][pos_j] + inst.get_distmatrix()[pos_j][pos_j1];
				}

				if(saving.value > 0) {
					System.out.println("aggiungo saving perch� ha value: "+ saving.value);
					savings.add(saving);
				}else if(saving.value ==0) {
					hopesavings.add(saving);
				}

			}
		}
				
		// FINE CALCOLO SAVING
		
		if(savings.size()==0 && hopesavings.size()==0) {
			ris = false;
			System.out.println("Tutti i saving sono negativi");
			debug.close();
			return ris;
		}
		
		// ordina gli elementi del vector
	
		Collections.sort(savings, new saving_intra() );
		
		Collections.sort(hopesavings, new saving_intra());
		
		// Swapping
		
		boolean trovato = false;
		int conta_sav = 0;
		double epsilon = 0.05;
		
		if(savings.size()>0) {	
			System.out.println("Ci sono ben "+savings.size()+" savings da provare!");
			while(!trovato && conta_sav < savings.size()) {		// qua si prova ad effettuare gli swap finch� non finiscono le possibilit� o si swappa qualcosa.				
				
				// ogni saving ha il valore e 2 indirizzi. Quando fai lo swap devi risalire alle posizioni iniziali e finali dei pacchi
				// puoi usare la funzione "trova_posizione" per risalire alla posizione dell'indirizzo in copia2 e quindi alla relativa posizione in pos_iniziali e pos_finali
				
				Elemento_soluzione copia3 = new Elemento_soluzione();	// serve nel caso in cui lo swap porti ad una soluzione non feasible
				copy_element(copia,copia3);
				
				int aux_pos1 = trova_posizione(copia2.pacchi_assegnati, savings.get(conta_sav).indirizzo1);
				int aux_pos2 = trova_posizione(copia2.pacchi_assegnati, savings.get(conta_sav).indirizzo2);
				int pos_iniz1 = pos_iniziali[aux_pos1];
				int pos_fin1 = pos_finali[aux_pos1];
				int pos_iniz2 = pos_iniziali[aux_pos2];
				int pos_fin2 = pos_finali[aux_pos2];
				
				System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
				System.out.println("Provo a swappare "+savings.get(conta_sav).indirizzo1+" con "+savings.get(conta_sav).indirizzo2);
				
				Vector<Pacco_assegnato> aux1 = new Vector<Pacco_assegnato>();	// pacchi del cliente 1 che verranno swappati con quelli di 2
				Vector<Pacco_assegnato> aux2 = new Vector<Pacco_assegnato>();	// pacchi del cliente 2 che verranno swappati con quelli di 1
				int conta1=0;
				while(conta1<=(pos_fin1 - pos_iniz1)){
					Pacco_assegnato p1 = new Pacco_assegnato();
					copia_pacco(copia.pacchi_assegnati.get(pos_iniz1 + conta1), p1);
					aux1.add(p1);
					conta1++;
				}
				int conta2=0;
				while(conta2<=(pos_fin2 - pos_iniz2)){
					Pacco_assegnato p2 = new Pacco_assegnato();
					copia_pacco(copia.pacchi_assegnati.get(pos_iniz2 + conta2), p2);
					aux2.add(p2);
					conta2++;
				}
				
				// eliminazione dei pacchi da swappare
				conta1=0;
				while(conta1<=(pos_fin1 - pos_iniz1)){
					copia3.pacchi_assegnati.remove(pos_iniz1);
					conta1++;				}
				
				conta2=0;
				while(conta2<=(pos_fin2 - pos_iniz2)){
					copia3.pacchi_assegnati.remove(pos_iniz2 - aux1.size() );
					conta2++;
				}
				
				// inserimento di aux2
				conta2=0;
				while(conta2<=(pos_fin2 - pos_iniz2)){
					copia3.pacchi_assegnati.insertElementAt(aux2.get(conta2), pos_iniz1);
					conta2++;
				}
				
				// inserimento di aux1
				conta1=0;
				while(conta1<=(pos_fin1 - pos_iniz1)){
					copia3.pacchi_assegnati.insertElementAt(aux1.get(conta1) , pos_fin2 - aux1.size() + 1);
					conta1++;
				}
			
				ricalcola_arrivi(copia3, inst);				// ricalcolo arrivi
				PrintStream debug_swap = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\solution\\debug_swap.txt"));
				System.setOut(debug_swap);
				System.out.println("Sono stati swappati i clienti "+savings.get(conta_sav).indirizzo1+" e "+savings.get(conta_sav).indirizzo2);
				stampa_elemento(copia3, inst);
				System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
				
				if(check_element_times(copia3)) {			// e controllo la feasibility temporale
					// calcola distanza nuova (ho swappato 2 clienti secondo una logica di savings, ho ricalcolato i tempi e fatto check degli stessi ed � andato tutto ok, ora calcolo la funzione obiettivo che mi permette di capire se � il caso o no di applicare questo change)
					calcola_distanza(copia3,inst);
					System.out.println("Nuova f.o = "+copia3.distanza_percorsa);
					System.out.println("Vecchia f.o = "+elemento.distanza_percorsa);
					if(copia3.distanza_percorsa - elemento.distanza_percorsa < - epsilon) {
						ris = true;
						trovato = true;
						copy_element(copia3,elemento);	// non importa copiare copia3 in copia. Copia3 serve solo per l'unfeasibility
					}else { // controlla che sia migliore di distanza vecchia
						ris = false;				
						System.setOut(debug);
						System.out.println("Sono stati swappati i clienti "+savings.get(conta_sav).indirizzo1+" e "+savings.get(conta_sav).indirizzo2);
						stampa_elemento(copia3,inst);
						System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
						System.out.println("Soluzione feasible ma peggiore. Saremmo passati da "+elemento.distanza_percorsa+" a "+copia.distanza_percorsa+". E dire che si doveva risparmiare: "+savings.get(conta_sav).value);
					}
				}else{
					System.out.println("Tempi non ok, provo con altro savings");
				}
				
				conta_sav++;
			}
		}else if(hopesavings.size()>1) {
			// se abbiamo dei savings nulli dobbiamo solo sperare che swappando contemporaneamente 2 coppie (i,j) e (h,k) di clienti si ottenga complessivamente un risparmio. Questo calcolo non si fa ex-ante ma ex-post, si procede quindi ad indentificare 2 coppie distinte, a swappare e a valutare il tutto. CHiaramente potrebbo esserci pi� coppie
			for(int t=0;t<hopesavings.size() && !trovato;t++) {
				for(int u=0;u<hopesavings.size()&& u!=t && !trovato;u++) {
					if(hopesavings.get(t).indirizzo1!=hopesavings.get(u).indirizzo1 && hopesavings.get(t).indirizzo1!=hopesavings.get(u).indirizzo2 && hopesavings.get(t).indirizzo2!=hopesavings.get(u).indirizzo1 && hopesavings.get(t).indirizzo2!=hopesavings.get(u).indirizzo2) {
						
						int aux_pos1 = trova_posizione(copia2.pacchi_assegnati, hopesavings.get(t).indirizzo1);
						int aux_pos2 = trova_posizione(copia2.pacchi_assegnati, hopesavings.get(t).indirizzo2);
						int aux_pos3 = trova_posizione(copia2.pacchi_assegnati, hopesavings.get(u).indirizzo1);
						int aux_pos4 = trova_posizione(copia2.pacchi_assegnati, hopesavings.get(u).indirizzo2);
						int pos_iniz1 = pos_iniziali[aux_pos1];
						int pos_fin1 = pos_finali[aux_pos1];
						int pos_iniz2 = pos_iniziali[aux_pos2];
						int pos_fin2 = pos_finali[aux_pos2];
						int pos_iniz3 = pos_iniziali[aux_pos3];
						int pos_fin3 = pos_finali[aux_pos3];
						int pos_iniz4 = pos_iniziali[aux_pos4];
						int pos_fin4 = pos_finali[aux_pos4];
						
						Elemento_soluzione copia3 = new Elemento_soluzione();
						copy_element(elemento,copia3);
						
						// copia dei pacchi da swappare. aux 1 e 2 sono degli hopesavings t, mentre aux 3 e 4 di quelli u
						Vector<Pacco_assegnato> aux1 = new Vector<Pacco_assegnato>();	// pacchi del cliente 1 che verranno swappati con quelli di 2
						Vector<Pacco_assegnato> aux2 = new Vector<Pacco_assegnato>();	// pacchi del cliente 2 che verranno swappati con quelli di 1
						int conta1=0;
						while(conta1<=(pos_fin1 - pos_iniz1)){
							Pacco_assegnato p1 = new Pacco_assegnato();
							copia_pacco(copia.pacchi_assegnati.get(pos_iniz1 + conta1), p1);
							aux1.add(p1);
							conta1++;
						}
						int conta2=0;
						while(conta2<=(pos_fin2 - pos_iniz2)){
							Pacco_assegnato p2 = new Pacco_assegnato();
							copia_pacco(copia.pacchi_assegnati.get(pos_iniz2 + conta2), p2);
							aux2.add(p2);
							conta2++;
						}
						
						Vector<Pacco_assegnato> aux3 = new Vector<Pacco_assegnato>();	
						Vector<Pacco_assegnato> aux4 = new Vector<Pacco_assegnato>();	
						int conta3=0;
						while(conta3<=(pos_fin3 - pos_iniz3)){
							Pacco_assegnato p3 = new Pacco_assegnato();
							copia_pacco(copia.pacchi_assegnati.get(pos_iniz3 + conta3),p3);
							aux3.add(p3);
							conta3++;
						}
						int conta4=0;
						while(conta4<=(pos_fin4 - pos_iniz4)){
							Pacco_assegnato p4 = new Pacco_assegnato();
							copia_pacco(copia.pacchi_assegnati.get(pos_iniz4 + conta4),p4);
							aux4.add(p4);
							conta4++;
						}
						
						// eliminazione dei pacchi da swappare per il saving t
						conta1=0;
						while(conta1<=(pos_fin1 - pos_iniz1)){
							copia3.pacchi_assegnati.remove(pos_iniz1);
							conta1++;
						}
						
						conta2=0;
						while(conta2<=(pos_fin2 - pos_iniz2)){
							copia3.pacchi_assegnati.remove(pos_iniz2 - aux1.size() );
							conta2++;
						}
						
						// inserimento di aux2
						conta2=0;
						while(conta2<=(pos_fin2 - pos_iniz2)){
							copia3.pacchi_assegnati.insertElementAt(aux2.get(conta2), pos_iniz1);
							conta2++;
						}
						
						// inserimento di aux1
						conta1=0;
						while(conta1<=(pos_fin1 - pos_iniz1)){
							copia3.pacchi_assegnati.insertElementAt(aux1.get(conta1) , pos_fin2 - aux1.size() + 1);
							conta1++;
						}
						
						// la dimensione della copia � tornata uguale all'originale. Procedo con il saving u
							
						// eliminazione dei pacchi da swappare per il saving u
						conta3=0;
						while(conta3<=(pos_fin3 - pos_iniz3)){
							copia3.pacchi_assegnati.remove(pos_iniz3);
							conta3++;
						}
						
						conta4=0;
						while(conta4<=(pos_fin4 - pos_iniz4)){
							copia3.pacchi_assegnati.remove(pos_iniz4 - aux3.size() );
							conta4++;
						}
						
						// inserimento di aux4
						conta4=0;
						while(conta4<=(pos_fin4 - pos_iniz4)){
							copia3.pacchi_assegnati.insertElementAt(aux4.get(conta4) , pos_iniz3);
							conta4++;
						}
						
						// inserimento di aux3
						conta3=0;
						while(conta3<=(pos_fin3 - pos_iniz3)){
							copia3.pacchi_assegnati.insertElementAt(aux3.get(conta3), pos_fin4 - aux3.size() + 1);
							conta3++;
						}
						
						
						
						ricalcola_arrivi(copia3, inst);
						if(check_element_times(copia3)){	// se il controllo temporale va bene si procede al calcolo della distanza
							calcola_distanza(copia3,inst);
							if(copia3.distanza_percorsa - elemento.distanza_percorsa < - epsilon) { // controlla che sia effettivamente migliore di distanza vecchia
								ris = true;
								trovato = true;
								copy_element(copia3,elemento);
								System.out.println("Ho swappato i clienti: "+hopesavings.get(t).indirizzo1+" e "+hopesavings.get(t).indirizzo2+" e anche "+hopesavings.get(u).indirizzo1+" e "+hopesavings.get(u).indirizzo2 +" nel vero veicolo ");
							}else { 
								ris = false;
								System.setOut(debug);
								stampa_elemento(copia3,inst);
								System.out.println("Soluzione feasible ma peggioreeeeee!");
								System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
							}
						}

					}	
				}
			}

		}
		
		debug.close();
		return ris;
	}
	
	public boolean OR_OPT(Elemento_soluzione elemento, IInstance inst, int L) throws IOException{
		boolean ris = false;
		
		int i,j;
		int l;
		PrintStream debug_OROPT = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\solution\\debug_OROPT.txt", true));
		Elemento_soluzione copia = new Elemento_soluzione();
		copy_element(elemento,copia);
		
		//System.out.println("Si ragiona del veicolo "+copia.veicolo_usato.ID_veicolo);
		
		// introduco un vettore di pacchi senza doppioni
		Elemento_soluzione copia2 = new Elemento_soluzione(); 	// � una copia di "copia" che non ha doppioni
		copy_element(copia,copia2);
		
		for(int m = 1; m<copia2.pacchi_assegnati.size()-2; m++){
			for(int n = m+1; n<copia2.pacchi_assegnati.size()-1;n++){
				if(copia2.pacchi_assegnati.get(m).Destinazione.equals(copia2.pacchi_assegnati.get(n).Destinazione)){
					copia2.pacchi_assegnati.remove(n);
					n--;
				}
			}
		}
				
		// ora andiamo a individuare la posizione iniziale di ciascun elemento di copia2 in copia
		int[] pos_iniziali = new int[copia2.pacchi_assegnati.size()];
		int[] pos_finali = new int[copia2.pacchi_assegnati.size()];
		for(int m = 1; m<copia2.pacchi_assegnati.size()-1;m++){
			boolean auxbool = true;
			for(int n=1; n<copia.pacchi_assegnati.size()-1 && auxbool;n++){
				if(copia2.pacchi_assegnati.get(m).Destinazione.equals(copia.pacchi_assegnati.get(n).Destinazione)){	// se le destinazioni corrispondono
					auxbool = false;
					pos_iniziali[m]=n;
					boolean auxbool2 = true;
					int auxcount = 1;
					while(auxbool2){
						pos_finali[m]=n+auxcount-1;
						if(copia2.pacchi_assegnati.get(m).Destinazione.equals(copia.pacchi_assegnati.get(n+auxcount).Destinazione)){
							auxcount++;
						}else{auxbool2 = false;}
					}
				}
			}
		}
		
		boolean trovato = false;			// uso se trovo una mossa utile
		
		for(l=1; l<=L && !trovato; l++){
			//System.out.println("Lambda vale: "+l);
			Vector<saving_OROPT> savings = new Vector<saving_OROPT>();	// creazione del vettore di savings
			
			for(i=1;i<copia2.pacchi_assegnati.size() - l;i++){	// parto da 1 per non incontrare il deposito e mi fermo a -1-
				// for(j=i+l; j<copia2.pacchi_assegnati.size()-1;j++){
				for(j=1; j<copia2.pacchi_assegnati.size()-1;j++){
					if(j<i-1 || j>= i+l){	// evito che I == j+1 e provo a inserire anche dal basso della lista verso l'alto.
						int pos_1i, pos_i, pos_1iL, pos_iL, pos_j, pos_j1 ;
						pos_1i = inst.find_position1(copia2.pacchi_assegnati.get(i-1).Destinazione);
						pos_i = inst.find_position1(copia2.pacchi_assegnati.get(i).Destinazione);
						pos_1iL = inst.find_position1(copia2.pacchi_assegnati.get(i+l-1).Destinazione);
						pos_iL = inst.find_position1(copia2.pacchi_assegnati.get(i+l).Destinazione);
						pos_j = inst.find_position1(copia2.pacchi_assegnati.get(j).Destinazione);
						pos_j1 = inst.find_position1(copia2.pacchi_assegnati.get(j+1).Destinazione);

						saving_OROPT saving = new saving_OROPT();
						saving.indirizzi1 = new Vector<String>();

						for(int u = 0; u<l; u++){ 
							saving.indirizzi1.add(copia2.pacchi_assegnati.get(i+u).Destinazione);
						}

						saving.indirizzoj = copia2.pacchi_assegnati.get(j).Destinazione;	
						saving.value = inst.get_distmatrix()[pos_1i][pos_i] + inst.get_distmatrix()[pos_1iL][pos_iL] + inst.get_distmatrix()[pos_j][pos_j1] - inst.get_distmatrix()[pos_1i][pos_iL] - inst.get_distmatrix()[pos_j][pos_i] - inst.get_distmatrix()[pos_1iL][pos_j1];

						if(saving.value>0)
							savings.add(saving);
					}
				}
			}
			
			Collections.sort(savings, new saving_OROPT());
			//System.out.println("Size dei savings per lambda = "+ l +" = "+savings.size());
			
			for(int r = 0; r< savings.size() && !trovato; r++){
				
				// ogni saving ha il valore e 2 indirizzi. Quando fai lo swap devi risalire alle posizioni iniziali e finali dei pacchi
				// puoi usare la funzione "trova_posizione" per risalire alla posizione dell'indirizzo in copia2 e quindi alla relativa posizione in pos_iniziali e pos_finali
				
				Elemento_soluzione copia3 = new Elemento_soluzione();	// serve nel caso di soluzione infeasible
				copy_element(copia,copia3);
				
				Vector<Integer> pos_iniziali_i = new Vector<>();
				Vector<Integer> pos_finali_i = new Vector<>();
				for(int h = 0; h< l; h++){
					pos_iniziali_i.add(pos_iniziali[trova_posizione(copia2.pacchi_assegnati, savings.get(r).indirizzi1.get(h))]);
					pos_finali_i.add(pos_finali[trova_posizione(copia2.pacchi_assegnati, savings.get(r).indirizzi1.get(h))]);
				}
				
				int pos_inizj = pos_iniziali[trova_posizione(copia2.pacchi_assegnati, savings.get(r).indirizzoj)];	// probabilmente non serve
				int pos_finj = pos_finali[trova_posizione(copia2.pacchi_assegnati, savings.get(r).indirizzoj)];
				
				int pos_j1 = pos_iniziali[trova_posizione(copia2.pacchi_assegnati, savings.get(r).indirizzoj) + 1];	// probabilmente non serve
								
				// qua dici: voglio mettere i clienti i,i+1, ...ilambda-1 tra il cliente j e il cliente j+1
				//System.out.println("Voglio mettere i clienti da "+savings.get(r).indirizzi1.firstElement()+" e i suoi "+ (l-1)+" successivi tra il cliente "+ savings.get(r).indirizzoj+ " e il suo successivo "+ copia.pacchi_assegnati.get(pos_j1).Destinazione +" per ottenere un saving di "+savings.get(r).value);
				
				Vector<Pacco_assegnato> aux = new Vector<Pacco_assegnato>();	// cos� dovrei riuscire a copiare tutti i pacchi dei lambda clienti che sposto
				for(int a = 0; a<l; a++){
					for(int b=0;b<= pos_finali_i.get(a) - pos_iniziali_i.get(a) ;b++  ){
						Pacco_assegnato aus = new Pacco_assegnato();
						copia_pacco(copia3.pacchi_assegnati.get(pos_iniziali_i.get(a)+b), aus);
						aux.add(aus);
					}
				}
				
				// rimozione pacchi (in copia3)
				for(int a=0;a<aux.size();a++){
					copia3.pacchi_assegnati.removeElementAt(pos_iniziali_i.firstElement());
				}
				
				// aggiunta pacchi (in copia3) in posizione pos_finj - aux.size() + 1
				if(pos_finj > pos_iniziali_i.firstElement() )
				for(int a=aux.size()-1;a>=0;a--){
					copia3.pacchi_assegnati.insertElementAt(aux.get(a), pos_finj-aux.size()+1);
				}else{	// se j � pi� in cima nella lista rispetto a i
					for(int a=aux.size()-1;a>=0;a--){
						copia3.pacchi_assegnati.insertElementAt(aux.get(a), pos_finj + 1);
					}
				}
				
				// aggiorno i tempi di arrivo
				ricalcola_arrivi(copia3, inst);
				
				// puoi mettere stampa di debug col 
				/*System.setOut(debug_OROPT);
				stampa_elemento(copia3, inst);
				System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
				*/
				
				// faccio il solo controllo di feasibility temporale
				if(check_element_times(copia3)){		// feasibility ok?
					calcola_distanza(copia3,inst);
					double epsilon = 0.005;
					if(copia3.distanza_percorsa < elemento.distanza_percorsa - epsilon){ 
						trovato = true;
						copy_element(copia3,elemento);
						//System.out.println("La f.o. � passata da "+copia.distanza_percorsa+" a "+elemento.distanza_percorsa);
						ris = true;
					}else{
						System.out.println("La f.o. non migliora");
						System.setOut(debug_OROPT);
						stampa_elemento(copia3, inst);
						System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));	
					}
				}						
			}
			
		}		
		
		return ris;
	}
	
	public boolean two_OPT(Elemento_soluzione elemento, IInstance inst) throws IOException{
		boolean ris = false;
		Elemento_soluzione copia = new Elemento_soluzione();
		copy_element(elemento,copia);
		
		PrintStream debug_TWO_OPT = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\solution\\debug_TWO_OPT.txt", true));
		
//		System.out.println("Si ragiona del veicolo "+copia.veicolo_usato.ID_veicolo);
		
		// introduco un vettore di pacchi senza doppioni
		Elemento_soluzione copia2 = new Elemento_soluzione(); 	// � una copia di "copia" che non ha doppioni
		copy_element(copia,copia2);
		
		for(int m = 1; m<copia2.pacchi_assegnati.size()-2; m++){
			for(int n = m+1; n<copia2.pacchi_assegnati.size()-1;n++){
				if(copia2.pacchi_assegnati.get(m).Destinazione.equals(copia2.pacchi_assegnati.get(n).Destinazione)){
					copia2.pacchi_assegnati.remove(n);
					n--;
				}
			}
		}
				
		// ora andiamo a individuare la posizione iniziale di ciascun elemento di copia2 in copia
		int[] pos_iniziali = new int[copia2.pacchi_assegnati.size()];
		int[] pos_finali = new int[copia2.pacchi_assegnati.size()];
		for(int m = 1; m<copia2.pacchi_assegnati.size()-1;m++){
			boolean auxbool = true;
			for(int n=1; n<copia.pacchi_assegnati.size()-1 && auxbool;n++){
				if(copia2.pacchi_assegnati.get(m).Destinazione.equals(copia.pacchi_assegnati.get(n).Destinazione)){	// se le destinazioni corrispondono
					auxbool = false;
					pos_iniziali[m]=n;
					boolean auxbool2 = true;
					int auxcount = 1;
					while(auxbool2){
						pos_finali[m]=n+auxcount-1;
						if(copia2.pacchi_assegnati.get(m).Destinazione.equals(copia.pacchi_assegnati.get(n+auxcount).Destinazione)){
							auxcount++;
						}else{auxbool2 = false;}
					}
				}
			}
		}
		
		Vector<saving_intra> savings = new Vector<saving_intra>();
		
		for(int i=1;i<copia2.pacchi_assegnati.size()-4;i++){	// parto dopo il deposito e mi fermo: prima del deposito, di j+1, di j e di i+1
			for(int j=i+2;j<copia2.pacchi_assegnati.size()-2;j++){	// non parto da i+1 perch� senn� saving = 0 sicuro
				
				int pos_i, pos_i1, pos_j, pos_j1 ;
				pos_i = inst.find_position1(copia2.pacchi_assegnati.get(i).Destinazione);
				pos_i1 = inst.find_position1(copia2.pacchi_assegnati.get(i+1).Destinazione);
				pos_j = inst.find_position1(copia2.pacchi_assegnati.get(j).Destinazione);
				pos_j1 = inst.find_position1(copia2.pacchi_assegnati.get(j+1).Destinazione);
				
				saving_intra saving = new saving_intra();
				saving.indirizzo1 = copia2.pacchi_assegnati.get(i).Destinazione;
				saving.indirizzo2 = copia2.pacchi_assegnati.get(j).Destinazione;
				saving.value = inst.get_distmatrix()[pos_i][pos_i1] + inst.get_distmatrix()[pos_j][pos_j1] - inst.get_distmatrix()[pos_i][pos_j] - inst.get_distmatrix()[pos_i1][pos_j1];	// si tratta del saving considerando la matrice delle distanze simmetrica. Va aggiunto il saving asimmetrico (in Manhattan dovrebbe valere 0)
				
				// calcolo del saving asimmetrico (poich� si inverte la rotta, quindi i costi tra i+1 e j potrebbero non essere gli stessi!
				for(int k=i+1;k<j;k++){
					int pos_k = inst.find_position1(copia2.pacchi_assegnati.get(k).Destinazione);
					int pos_k1 = inst.find_position1(copia2.pacchi_assegnati.get(k+1).Destinazione);
					double difference = inst.get_distmatrix()[pos_k][pos_k1] - inst.get_distmatrix()[pos_k1][pos_k];
					//System.out.println("And the difference is..."+difference); // viene giustamente 0 per Manhattan
					saving.value += difference;
				}
				
				//System.out.println("saving value = "+saving.value);
				
				if(saving.value>0)			// se valore > 0 aggiungi al vector
					savings.add(saving);
			}
		}
		
		//System.out.println("Saving size: "+savings.size());
		
		// ora hai i saving calcolati, e conosci l'indirizzo di i e di j
		Collections.sort(savings, new saving_intra());
		
		boolean trovato = false;
		
		for(int r = 0; r<savings.size() && !trovato ;r++){
			Elemento_soluzione copia3 = new Elemento_soluzione();	// serve nel caso di soluzione infeasible
			copy_element(copia,copia3);
			
			int pos_fini = pos_finali[trova_posizione(copia2.pacchi_assegnati, savings.get(r).indirizzo1)];
			int pos_inizj = pos_iniziali[trova_posizione(copia2.pacchi_assegnati, savings.get(r).indirizzo2)];	
			int pos_finj = pos_finali[trova_posizione(copia2.pacchi_assegnati, savings.get(r).indirizzo2)];
			
			int pos_i1 =  pos_fini+1;			// i+1
			int pos_1j =  pos_inizj-1;			// j-1 (teoricamente non mi serve)
			
			// salvo tutti i pacchi da i+1 a pos_finj
			Vector<Pacco_assegnato> aux = new Vector<Pacco_assegnato>();
			boolean reached = false;
			int aux_cont = 0;
			while(!reached){
				Pacco_assegnato aus = new Pacco_assegnato();
				copia_pacco(copia3.pacchi_assegnati.get(pos_i1+aux_cont), aus);
				aux.addElement(aus);
				aux_cont++;
				if(pos_i1+aux_cont>pos_finj){
					reached = true;
				}
			}
			
			// inizio a rimuovere in posizione i+1 tutti gli aux.size() pacchi
			for(int a = 0;a<aux.size(); a++){
				copia3.pacchi_assegnati.removeElementAt(pos_i1);
			}
			
			// li reinserisco sempre in posizione i+1
			for(int a = 0;a<aux.size();a++){
				copia3.pacchi_assegnati.insertElementAt(aux.get(a), pos_i1);
			}
			
			// FINE
			
			/*
			// anzitutto mi salvo il/i pacco/pacchi del cliente j, lo rimuovo e lo metto subito dopo il cliente i.
			Vector<Pacco_assegnato> auxj = new Vector<Pacco_assegnato>();
			for(int a = 0; a <= (pos_finj - pos_inizj) ; a++){
				Pacco_assegnato ausj = new Pacco_assegnato();
				copia_pacco(copia3.pacchi_assegnati.get(pos_inizj + a), ausj);
				auxj.add(ausj);				
			}
			// ora rimuovo i pacchi di j
			for(int a = 0; a<auxj.size();a++){
				copia3.pacchi_assegnati.removeElementAt(pos_inizj);
			}
			// ora aggiungi tutti i pacchi dopo il cliente i
			for(int a = 0; a<auxj.size();a++){
				copia3.pacchi_assegnati.insertElementAt(auxj.get(a), pos_fini);	// se j < i dovrai sottrarre un fattore aux.size 
			}
			
			
			Vector<Pacco_assegnato> aux = new Vector<Pacco_assegnato>();	// qua metto tutti i pacchi tra i e j, quindi quelli da i+1 a j-1 (estremi compresi)
			
			for(int a = 0; a<= (pos_1j - pos_i1); a++){		// a<= (pos_1j - pos_i1) va bene fintanto che j>i, dopo come minimo usi il modulo
				Pacco_assegnato aus = new Pacco_assegnato();
				copia_pacco(copia3.pacchi_assegnati.get(pos_i1 + a),aus);
				aux.add(aus);
			}
			
			// ora rimuovi tutti i pacchi (se j>i saranno tutti dopo j, ora che lui � stato collocato dopo i)
			for(int a = 0; a<aux.size();a++){
				copia3.pacchi_assegnati.removeElementAt(pos_fini+auxj.size()+1);
			}
			
			// e li re-inseriamo
			for(int a = 0; a<aux.size();a++){
				copia3.pacchi_assegnati.insertElementAt(aux.get(a), pos_fini+auxj.size()+1);
			}*/
			
			ricalcola_arrivi(copia3,inst);			
			
			if(check_element_times(copia3)){		// feasibility ok?
				calcola_distanza(copia3,inst);
				double epsilon = 0.005;
				if(copia3.distanza_percorsa < elemento.distanza_percorsa - epsilon){ 
					trovato = true;
					copy_element(copia3,elemento);
					stampa_elemento(copia3, inst);
					//System.out.println("La f.o. � passata da "+copia.distanza_percorsa+" a "+elemento.distanza_percorsa);
					ris = true;
				}else{
					System.out.println("La f.o. non migliora");
					System.setOut(debug_TWO_OPT);
					System.out.println("Ho provato a cambiare con i = "+savings.get(r).indirizzo1+" e j = "+savings.get(r).indirizzo2);
					stampa_elemento(copia3, inst);
					System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));	
				}
			}else{
				System.out.println("unfeasible, try it again");
			}
			
		} // fine del for sui savings.
		
		
		return ris;
	}
	
class saving_exchange implements Comparator<saving_exchange> {

	double value;
	//Vector<Integer> pos_clienti_uscita_veicolo1 = new Vector<>();		// vettore delle posizioni dei clienti che se ne andranno dal veicolo 1			
	int pos_clienti_uscita_veicolo1;
	int ID_veicolo1;		// si tratta del veicolo h, quello "cedente"
	int pos_clienti_uscita_veicolo2;				// vettore delle posizioni dei clienti che se ne andranno dal veicolo 2			
	int ID_veicolo2;		// si tratta del veicolo k, quello "tirante"

	public double getValue(){
		return value;
	}

	public int getID_clienti_veicolo1(){
		return pos_clienti_uscita_veicolo1;
	}

	public int getID_clienti_veicolo2(){
		return pos_clienti_uscita_veicolo2;
	}

	public int getID_veicolo1(){
		return ID_veicolo1;
	}

	public int getID_veicolo2(){
		return ID_veicolo2;
	}

	public int compare(saving_exchange s1, saving_exchange s2) {
		if(s1.value > s2.value) return -1;
		if(s1.value < s2.value) return 1;
		return 0;
	}

}
	
class saving_relocate implements Comparator<saving_relocate> {

	double value;
	Vector<Integer> pos_clienti_uscita = new Vector<>();		// vettore delle posizioni dei veicoli che se ne andranno dal veicolo 1			
	int ID_veicolo1;		// si tratta del veicolo h, quello "cedente"
	int swap2;				// si tratta della posizione j nella route del veicolo k
	int ID_veicolo2;		// si tratta del veicolo k, quello "tirante"
	
	public double getValue(){
		return value;
	}
	
	public int getID_cliente(int i){
		return pos_clienti_uscita.get(i);
	}
	
	public int getID_veicolo1(){
		return ID_veicolo1;
	}
	
	public int getSwap2(){
		return swap2;
	}
	
	public int getID_veicolo2(){
		return ID_veicolo2;
	}
	
	public int compare(saving_relocate s1, saving_relocate s2) {
		if(s1.value > s2.value) return -1;
		if(s1.value < s2.value) return 1;
		return 0;
	}

}
	
class saving_intra implements Comparator<saving_intra>{
	double value;
	String indirizzo1;	// questi 2 campi servono solo per il debug
	String indirizzo2;
	public int compare(saving_intra s1, saving_intra s2) {
		if(s1.value > s2.value) return -1;
		if(s1.value < s2.value) return 1;
		return 0;
	}
	
}

class saving_OROPT implements Comparator<saving_OROPT>{
	double value;
	Vector<String> indirizzi1;	// questi 2 campi servono solo per il debug
	String indirizzoj;
	public int compare(saving_OROPT s1, saving_OROPT s2) {
		if(s1.value > s2.value) return -1;
		if(s1.value < s2.value) return 1;
		return 0;
	}
	
}

	/**************************/
	/*** METODI DI SUPPORTO ***/
	/**************************/
	
	/*** METODI PER MOSSE DI RICERCA LOCALE ***/
	
	/** Il metodo ricalcola gli orari di arrivo
 	*/
	public void ricalcola_arrivi(Elemento_soluzione elemento, IInstance inst) throws IOException{
		elemento.pacchi_assegnati.firstElement().ora_arrivo_stimata = 0;
		for(int i=1;i<elemento.pacchi_assegnati.size();i++){
			int pos1 = inst.find_position1(elemento.pacchi_assegnati.get(i-1).Destinazione);
			int pos2 = inst.find_position1(elemento.pacchi_assegnati.get(i).Destinazione);
			elemento.pacchi_assegnati.get(i).ora_arrivo_stimata = elemento.pacchi_assegnati.get(i-1).ora_arrivo_stimata + inst.get_timematrix()[pos1][pos2]/inst.get_scalatempo();
		}
	}
		
	/*** METODI PER CLUSTERING ***/
	/**
	 * Algoritmo Di Prim
	 * @param inst
	 * @return Ritorna il costo dell'albero di copertura di costo minimo
	 * @throws IOException
	 */
	public double Prim(IInstance inst) throws IOException{
		double cost = 0;
		// ricorda che in un grafo connesso (come quello di lista_clienti) di n nodi l'albero di copertura ha esattamente n-1 archi e almeno 2 foglie. una foglia � un nodo del grafo di grado 1, ovvero nel quale incide 1 solo arco.
		Vector<Node> V1 = new Vector<Node>();
		Vector<Node> V2 = new Vector<Node>();

		// V1 e V2 mi forniscono un taglio del grafo dato dai nodi "lista_clienti" e tutti i suoi archi. Il taglio consiste nel fatto che i nodi di V1 non stanno in V2 e viceversa, e che V1 U V2 = lista_clienti.
		System.out.println("Il numero di clienti (distinti) �: "+inst.get_customermatrix().size());
		int i;
		int pos;

		for(i=0;i<inst.get_customermatrix().size();i++) {
			Node nodo = new Node();
			nodo.ID_node = inst.find_position1(inst.get_customermatrix().get(i).indirizzo);
			pos = (inst.get_customermatrix().size()-1)*i;
			nodo.pos_arco = pos;
			V2.add(nodo);
		}

		Vector<Edge> lati = new Vector <Edge>();
		int num_lati = inst.get_customermatrix().size()*(inst.get_customermatrix().size()-1);		// uso doppi grafi, a mo di multigrafo
		System.out.println("Il numero di lati �: "+num_lati);

		int conta_node = 0;
		int j=0;
		i=0;

		while(lati.size()<num_lati) {
			j++;
			if(j>=inst.get_customermatrix().size()) {
				conta_node++;
				j=0;
			}

			if( V2.get(conta_node).ID_node!=V2.get(j).ID_node) {
				Edge arco = new Edge();
				arco.ID_arco = i;
				arco.coda = V2.get(conta_node).ID_node;
				arco.testa = V2.get(j).ID_node;
				arco.costo = inst.get_distmatrix()[arco.coda][arco.testa];
				lati.add(arco);
				i++;
			}
		}

		V1.addElement(V2.firstElement());	// inizializzo V1 con il primo cliente nella lista
		V2.remove(V2.firstElement());

		Vector<Edge> albero = new Vector<Edge>();

		while(V1.size()<inst.get_customermatrix().size() ) {
			Vector<Edge> stella = new Vector<Edge>(); // find the star of the endpoints of V1
			for(i=0;i<V1.size();i++) {		// esploro la parte di nodi gi� inseriti per trovare la stella delle foglie di V1
				boolean cambia = false;
				for(j=V1.get(i).pos_arco;j<lati.size() && !cambia && V1.get(i).pos_arco>-1 ;j++) { // al fine di identificarvi gli archi che fanno parte della stella. Tali archi li trovo andando a vedere "lati"
					if(lati.get(j).coda!=V1.get(i).ID_node) {
						cambia=true;
					}else {
						boolean ciclo = false;
						for(int k=0;k<V1.size() && !ciclo;k++) {
							if(lati.get(j).testa==V1.get(k).ID_node)
								ciclo = true;
						}
						if(!ciclo) {
							stella.add(lati.get(j));
						}
					}
				}
			}

			// sort it in a crescent order
			Collections.sort(stella, new Edge());

			// pick the first
			albero.add(stella.firstElement());
			// check if it forms a cycle	(non dovrebbe essere necessario)
			// if yes, pick the following one
			// if no, add it to V1
			boolean coda = true;
			boolean testa = true;
			for(int k=0;k<V1.size();k++) {
				if(stella.firstElement().coda==V1.get(k).ID_node)
					coda = false;
				if(stella.firstElement().testa==V1.get(k).ID_node)
					testa = false;
			}

			int pos_add = -1;
			boolean trovato = false;

			if(coda) {		// cerca in V2 il nodo con ID_node = coda, e aggiungi tale nodo
				for(int k=0;k<V2.size() && !trovato;k++) {
					if(stella.firstElement().coda == V2.get(k).ID_node) {
						trovato = true;
						pos_add = k;
					}
				}
			}else if(testa) {
				for(int k=0;k<V2.size() && !trovato;k++) {
					if(stella.firstElement().testa == V2.get(k).ID_node) {
						trovato = true;
						pos_add = k;
					}
				}
			}
			if(pos_add!=-1) {
				V1.add(V2.get(pos_add));
				V2.remove(pos_add);						// remove it in V2
			}else System.out.println("Errore 00");

		}

		for(i=0;i<albero.size();i++) {
			cost += albero.get(i).costo;
		}

		/*
		System.out.println("L'albero di copertura di costo minimo � dato dai seguenti lati:");
		for(i=0;i<albero.size();i++) {
			System.out.println("("+albero.get(i).coda+","+albero.get(i).testa+")");
		}
		*/
		System.out.println("Minimum Spanning Tree cost: "+cost);

		//System.out.println("V1 size: "+V1.size());
		//System.out.println("V2 size: "+V2.size());

		return cost;
	}
		
	/**
	 * K-Means: famoso algoritmo per ottenere K cluster basati su distanza
	 * @author pc -> Lo hai preso su Internet (trova fonte) e lo hai cambiati
	 *
	 */
	
	public class KMeans
	{
	    private ArrayList<Data> dataSet = new ArrayList<Data>();
	    private ArrayList<Centroid> centroids = new ArrayList<Centroid>();
	    
	  //getting the maximum value
	    public double getMaxValue(double[] array){
	     double maxValue = array[0];
	     for (int i = 1; i < array.length; i++) {
	         if (array[i] > maxValue) {
	             maxValue = array[i];
	         }
	     }
	     return maxValue;
	    }

	    //getting the miniumum value
	    public double getMinValue(double[] array) {
	     double minValue = array[0];
	     for (int i = 1; i < array.length; i++) {
	         if (array[i] < minValue) {
	             minValue = array[i];
	         }
	     }
	     return minValue;
	    }
	    
	    public void initialize(int ncl, Vector<Cliente> cust)		// ho ncl cluster inizializzati in modo random
	    {	
	    	long seed = 10;
	    	
	    	double[] coorx = new double[cust.size()];
	    	double[] coory = new double[cust.size()];
	    	for(int i=0;i<cust.size();i++) {
	    		coorx[i] = cust.get(i).latitudine;
	    		coory[i] = cust.get(i).longitudine;
	    	}
	    	
	        for(int i=0;i<ncl;i++) {
	        centroids.add(new Centroid(randDouble(getMinValue(coorx), getMaxValue(coorx), seed), randDouble(getMinValue(coory), getMaxValue(coory), seed))); 
	        seed += 37;
	        }
	        return;
	    }
	    
	    public Vector<Vector<Cliente>> kMeanCluster(int ncl, Vector<Cliente> cust, int type)
	    {	
	    	
	    	Vector<Vector<Cliente>> ClusterSet = new Vector<Vector<Cliente>>();
	    	
	        final double bigNumber = Math.pow(10, 10);    // some big number that's sure to be larger than our data range.
	        double minimum = bigNumber;                   // The minimum value to beat. 
	        double distance = 0.0;                        // The current minimum value.
	        int sampleNumber = 0;
	        int cluster = 0;
	        boolean isStillMoving = true;
	        Data newData = null;
	        double[] coorx = new double[cust.size()];
	    	double[] coory = new double[cust.size()];
	    	String[] address = new String[cust.size()];
	    	for(int i=0;i<cust.size();i++) {
	    		coorx[i] = cust.get(i).latitudine;
	    		//System.out.println("Coor x"+coorx[i]);
	    		coory[i] = cust.get(i).longitudine;
	    		// System.out.println("Coor y"+coory[i]);
	    		address[i] = cust.get(i).indirizzo;
	    	}
	        
	        // Add in new data, one at a time, recalculating centroids with each new one. 
	        while(dataSet.size() < cust.size())
	        {
	            newData = new Data(coorx[sampleNumber], coory[sampleNumber], address[sampleNumber]);
	            dataSet.add(newData);
	            minimum = bigNumber;
	            for(int i = 0; i < ncl; i++)
	            {	
	            	if(type==0){
	            		distance = distMan(newData, centroids.get(i));
	            	}else{
	            		distance = distEuc(newData, centroids.get(i));
	            	}
	                if(distance < minimum){
	                    minimum = distance;
	                    cluster = i;
	                }
	            }
	            newData.cluster(cluster);
	            
	            // calculate new centroids.
	            for(int i = 0; i < ncl; i++)
	            {
	                double totalX = 0;
	                double totalY = 0;
	                int totalInCluster = 0;
	                for(int j = 0; j < dataSet.size(); j++)
	                {
	                    if(dataSet.get(j).cluster() == i){
	                        totalX += dataSet.get(j).X();
	                        totalY += dataSet.get(j).Y();
	                        totalInCluster++;
	                    }
	                }
	                if(totalInCluster > 0){
	                    centroids.get(i).X(totalX / totalInCluster);
	                    centroids.get(i).Y(totalY / totalInCluster);
	                }
	            }
	            sampleNumber++;
	        }
	        
	        // Now, keep shifting centroids until equilibrium occurs.
	        while(isStillMoving)
	        {
	            // calculate new centroids.
	            for(int i = 0; i < ncl; i++)
	            {
	                double totalX = 0;
	                double totalY = 0;
	                int totalInCluster = 0;
	                for(int j = 0; j < dataSet.size(); j++)
	                {
	                    if(dataSet.get(j).cluster() == i){
	                        totalX += dataSet.get(j).X();
	                        totalY += dataSet.get(j).Y();
	                        totalInCluster++;
	                    }
	                }
	                if(totalInCluster > 0){
	                    centroids.get(i).X(totalX / totalInCluster);
	                    centroids.get(i).Y(totalY / totalInCluster);
	                }
	            }
	            
	            // Assign all data to the new centroids
	            isStillMoving = false;
	            
	            for(int i = 0; i < dataSet.size(); i++)
	            {
	                Data tempData = dataSet.get(i);
	                minimum = bigNumber;
	                for(int j = 0; j < ncl; j++)
	                {                
	                	if(type==0){
	                	distance = distMan(tempData, centroids.get(j));
	                	}else{
	                		distance = distEuc(tempData, centroids.get(j));
	                	}
	                    if(distance < minimum){
	                        minimum = distance;
	                        cluster = j;
	                    }
	                }
	                tempData.cluster(cluster);
	                if(tempData.cluster() != cluster){
	                    tempData.cluster(cluster);
	                    isStillMoving = true;
	                }
	            }
	        }
	        
	        // Print out clustering results.
	        for(int i = 0; i < ncl; i++)				
	        {	
	        	Vector<Cliente> kluster = new Vector<Cliente>();
	           // System.out.println("Cluster " + i + " includes:");
	            for(int j = 0; j < coorx.length; j++)
	            {
	                if(dataSet.get(j).cluster() == i){
	                	Cliente customer = new Cliente();
	                    //System.out.println("     (" + dataSet.get(j).X() + ", " + dataSet.get(j).Y() + ")");
	                    customer.latitudine = (double) dataSet.get(j).X();
	                    customer.longitudine = (double) dataSet.get(j).Y();
	                    customer.indirizzo = dataSet.get(j).address;
	                    kluster.add(customer);
	                }
	            } // j
	           // System.out.println();
	            
	            // qua devo pushare un vector che contiene tot oggetti Customer all'interno del vector Cluster. Tale vector costituisce un cluster
	            ClusterSet.add(kluster);
	            
	        } // i
	        
	        // Print out centroid results.
	        //System.out.println("Centroids finalized at:");
	        for(int i = 0; i < ncl; i++)
	        {
	      //      System.out.println("     (" + centroids.get(i).X() + ", " + centroids.get(i).Y() + ")");
	        }
	       // System.out.print("\n");
	        
	        return ClusterSet;
	    }
	    
	    /**
	     * // Calculate Euclidean distance.
	     * @param d - Data object.
	     * @param c - Centroid object.
	     * @return - double value.
	     */
	    public double distEuc(Data d, Centroid c)
	    {
	        return Math.sqrt(Math.pow((c.Y() - d.Y()), 2) + Math.pow((c.X() - d.X()), 2));
	    }
	    
	    /**
	     * // Calculate Manhattan distance.
	     * @param d - Data object.
	     * @param c - Centroid object.
	     * @return - double value.
	     */
	    public double distMan(Data d, Centroid c)
	    {       
	        return  Math.abs(c.Y()-d.Y())+Math.abs(c.X()-d.X());
	    }
	    
	    public class Data
	    {
	        public double mX = 0;
	        public double mY = 0;
	        public String address = "0";
	        public int mCluster = 0;
	        
	        public Data()
	        {
	            return;
	        }
	        
	        public Data(double x, double y, String address)
	        {
	            this.X(x);
	            this.Y(y);
	            this.address(address);
	            return;
	        }
	        
	        public void X(double x)
	        {
	            this.mX = x;
	            return;
	        }
	        
	        public double X()
	        {
	            return this.mX;
	        }
	        
	        public void Y(double y)
	        {
	            this.mY = y;
	            return;
	        }
	        
	        public double Y()
	        {
	            return this.mY;
	        }
	        
	        public void address(String address)
	        {
	            this.address = address;
	            return;
	        }
	        
	        public String address()
	        {
	            return this.address;
	        }
	        
	        public void cluster(int clusterNumber)
	        {
	            this.mCluster = clusterNumber;
	            return;
	        }
	        
	        public int cluster()
	        {
	            return this.mCluster;
	        }
	    }
	    
	    private class Centroid
	    {
	        private double mX = 0.0;
	        private double mY = 0.0;
	        
	        public Centroid()
	        {
	            return;
	        }
	        
	        public Centroid(double newX, double newY)
	        {
	            this.mX = newX;
	            this.mY = newY;
	            return;
	        }
	        
	        public void X(double newX)
	        {
	            this.mX = newX;
	            return;
	        }
	        
	        public double X()
	        {
	            return this.mX;
	        }
	        
	        public void Y(double newY)
	        {
	            this.mY = newY;
	            return;
	        }
	        
	        public double Y()
	        {
	            return this.mY;
	        }
	    }
	}

	/**
	 * Metodo che serve a ordinare (prioritizzare) i clienti all'interno di un cluster secondo una metrica spazio temporale
	 */
	
	//public void nearest_neighbor_distandtime(Vector<Cliente> cluster, int[][] distmat, Vector<Pacco> transpmatrix, int N) throws IOException {	// N � il numero di magazzini
	public void nearest_neighbor_distandtime(Vector<Cliente> cluster, IInstance inst) throws IOException {	// N � il numero di magazzini
		double min_value = 999999;
		int min_pos = -1;
		double value = 999999;
		double k1 = 0.333;
		double k2 = 10;
		double addendo1, addendo2;
		
		int i,j;
		int max_dist = -1;
		for(i=0;i<inst.get_distmatrix().length;i++){
			for(j=0;j<inst.get_distmatrix().length;j++){
				if(inst.get_distmatrix()[i][j]>max_dist)
					max_dist = inst.get_distmatrix()[i][j];
			}
		}
		
		for(i=0;i<cluster.size();i++) {		// qua si esplorano tutti gli elementi del cluster, cercando quello pi� vicino al magazzino
			int position = inst.find_position1(cluster.get(i).indirizzo);
			//System.out.println(cluster.get(i).indirizzo);
			if(i==0){
				position =0;
			}
			addendo1 = k1*(( (double) inst.get_distmatrix()[0][position] / max_dist));		// ok
			//System.out.println("Addendo 1 del cliente ID "+cluster.get(i).cliente_ID+ "� "+ addendo1);
			
			// ricerca della riga in transpmatrix
			int pos_transpmatrix = -1;
			boolean trovato = false;
			//System.out.println("STAMPE DEBUG");
			for(int t=0; t<inst.get_packagematrix().size() && !trovato; t++) {
				if(inst.get_packagematrix().get(t).Destinazione.equals(cluster.get(i).indirizzo)) {	// vedo qual � l'elemento di transpmatrix che ci serve, ovvero quello corrispondente all'elemento del cluster osservato
					// transpmatrix ha gli address 
					trovato = true;
					pos_transpmatrix = t;
				}
			}
			
			addendo2 = k2 * ( inst.get_packagematrix().get(pos_transpmatrix).LST/ (600/inst.get_scalatempo()) );
			//System.out.println("Addendo 2 del cliente ID "+cluster.get(i).cliente_ID+ "� "+ addendo2);
			value = addendo1  + addendo2;	// il magazzino si trova in posizione 0
			
			if(value < min_value) {
				min_value = value;
				min_pos = i;
			}
		}
		
		// System.out.println("min_pos = "+min_pos);
		
		// System.out.println("Prova: "+600/scala_tempo); stampa 60 regolare
		
		//System.out.println("Min value = "+min_value+" presso il cliente ID "+cluster.get(min_pos).cliente_ID);
		// a questo punto l'elemento min_pos � il primo.
		Collections.swap(cluster,0,min_pos);	// metto in posizione 0 l'elemento che si trova in min_pos		
		
		// adesso ho il primo elemento da visitare del cluster. L'elemento successivo � quello pi� vicino al primo
		
		for(i=1;i<cluster.size();i++) {		// questo serve per le posizioni
			min_value = 999999;
			int position1 = inst.find_position1(cluster.get(i-1).indirizzo);
			for(j=i; j<cluster.size();j++) {// questo serve per considerare la distanza effettiva
				int position2 = inst.find_position1(cluster.get(j).indirizzo);
				addendo1 = k1*(((double) inst.get_distmatrix()[position1][position2]/max_dist));
				//System.out.println("Addendo 1 = "+min_value+" presso il cliente ID "+cluster.get(min_pos).cliente_ID);
				int pos_transpmatrix = -1;
				boolean trovato = false;
				for(int t=0; t<inst.get_packagematrix().size() && !trovato; t++) {
					if(inst.get_packagematrix().get(t).Destinazione.equals(cluster.get(i).indirizzo)) {	// vedo in quale riga di transpmatrix la destinazione corrisponde all'ID del cliente i-esimo del cluster
						trovato = true;
						pos_transpmatrix = t;
					}
				}
				
				addendo2 = k2 * ( inst.get_packagematrix().get(pos_transpmatrix).LST/(  600/inst.get_scalatempo()) );
				value = addendo1 + addendo2;
				if(value < min_value) {
					min_value = value;
					min_pos = j;
				}
			}
			//System.out.println("Min value = "+min_value+" presso il cliente ID "+cluster.get(min_pos).cliente_ID);
			Collections.swap(cluster, i, min_pos);
		}
		
		return;
	}

	public void StampaCluster(IInstance inst, Vector<Vector<Cliente>> ClusterSet) throws IOException{
		PrintStream OutputCluster;
		if(inst.get_typeInstance()==0){
			OutputCluster = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\output\\cluster.txt"));
		}else{
			OutputCluster = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstance\\output\\cluster.txt"));
		}
		System.setOut(OutputCluster);
		for (int z = 0; z < ClusterSet.size(); z++) {
			System.out.println("Stampa del cluster "+z+" ordinato");
			System.out.println("ID \t Coor_X \t Coor_Y");
			for (int g = 0; g < ClusterSet.get(z).size(); g++) {
				System.out.println(ClusterSet.get(z).get(g).indirizzo + "\t" + ClusterSet.get(z).get(g).latitudine
						+ "\t \t" + ClusterSet.get(z).get(g).longitudine);
			}
		}
		System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
	}
	
	/**
	 * Restituisce un numero reale compreso tra min e max
	 */
	
	public double randDouble(double min, double max, long seed) {
		Random rand = new Random(seed);
		double randomNum = min + (max - min) * rand.nextDouble();
		return randomNum;
	}
	
	/*** METODI PER ETEROGENEO ***/
	/**
	 * Questo metodo ordina i veicoli disponibili in senso crescente di inquinamento e, a parit� di inquinamento, in senso decrescente di capacit�.
	 */
	public void order_vehicles(IInstance inst){
		// prendi la vehiclematrix di inst e ordinala per inquinamento crescente (riconoscerai in tutte le tipologie di istanza il carburante benzina, metano ecc.)
		// a parit� di inquinamenti ordini per capacit� decrescente
		/*
		int i;
		System.out.println("Prova");
		for(i=0;i<inst.get_vehiclematrix().size();i++){
			System.out.println("Veicolo "+i+" ="+inst.get_vehiclematrix().get(i).ID_veicolo+"\t"+inst.get_vehiclematrix().get(i).Carburante+"\t"+inst.get_vehiclematrix().get(i).capacit�);
		}*/
		
		Collections.sort(inst.get_vehiclematrix(),new Veicolo());
		/*System.out.println("After sorting");
		
		for(i=0;i<inst.get_vehiclematrix().size();i++){
			System.out.println("Veicolo "+i+" ="+inst.get_vehiclematrix().get(i).ID_veicolo+"\t"+inst.get_vehiclematrix().get(i).Carburante+"\t"+inst.get_vehiclematrix().get(i).capacit�);
		}
		*/
		
	}
	
	public void assign_packages(Vector<Vector<Cliente>> ClusterSet, Soluzione soluzione, IInstance inst) throws IOException{
		int i;
		
		/** INIZIALIZZAZIONE DEI PRIMI NCL VEICOLI **/
		for(i=0;i<ClusterSet.size();i++){	// creo un numero di veicoli pari al numero di cluster
			Elemento_soluzione e = new Elemento_soluzione(); // per ogni cluster inizializzo un veicolo da inserire in soluzione
			e.veicolo_usato = new Veicolo();
			e.veicolo_usato = inst.get_vehiclematrix().firstElement();
			inst.get_vehiclematrix().remove(0);		// rimuovo il primo elemento, che ho appena aggiunto in e
			e.pacchi_assegnati = new Vector<Pacco_assegnato>();
			Pacco_assegnato p = new Pacco_assegnato();
			p.LST = 600;
			p.Destinazione = inst.get_packagematrix().firstElement().Origine;	// facciamo partire tutto dal magazzino
			e.pacchi_assegnati.addElement(p);
			soluzione.elementi.add(e);
		}
		
		/*
		System.out.println("Ecco i veicoli creati:");
		for(i=0;i<soluzione.elementi.size();i++){
		System.out.println(soluzione.elementi.get(i).veicolo_usato.ID_veicolo + "\t" + soluzione.elementi.get(i).veicolo_usato.Carburante +"\t"+soluzione.elementi.get(i).veicolo_usato.portata+"\t"+soluzione.elementi.get(i).veicolo_usato.capacit�+"\t"+soluzione.elementi.get(i).veicolo_usato.ID_autista);
		}*/
					
		Vector<Integer> num_clienti_cluster = new Vector<>();		// mi creo un array in cui inserisco il numero di clienti di ciascun cluster
		for(i=0;i<ClusterSet.size();i++){
			num_clienti_cluster.add(ClusterSet.get(i).size());	// numero di clienti in ciascun cluster 
		}
		int counter = 0;	// variabile che permette di costruire le route in parallelo. Fa riferimento ai pacchi da consegnare cos� come presenti nei vari cluster
		int j;
		Collections.sort(num_clienti_cluster);	// li ordino in senso crescente		
		while(counter < num_clienti_cluster.lastElement()){
			for(int z = 0; z < ClusterSet.size(); z++) {		// vado a esplorare tutti i veicoli del clusterset
				if(counter<ClusterSet.get(z).size()){			// se esiste il cliente counter di quel veicolo
					double peso = 0;
					double volume = 0;
					int tempo = 0;

					for (j= 0; j < inst.get_packagematrix().size() ; j ++) {	// s� facendo un cliente viene servito da un solo veicolo anche quando il cliente richieda pi� di 1 pacco. La variabile j nasce e muore qua
						if(ClusterSet.get(z).get(counter).indirizzo.equals(inst.get_packagematrix().get(j).Destinazione)){
							peso += inst.get_packagematrix().get(j).peso;
							volume += inst.get_packagematrix().get(j).volume;
							tempo = inst.get_packagematrix().get(j).LST;
						}
					}					
					boolean colloassegnato = false;					// per l'elemento i del cluster z pongo colloassegnato = false
					while(!colloassegnato) {		// il collo che voglio assegnare � il collo "counter"
						// fintanto che non assegno il collo ciclo alla ricerca di un veicolo feasible. Da qua si riparte anche dopo aver costruito il nuovo veicolo. In quel caso, il veicolo del cluster z sar� ancora infeasible e si prover� a dare il cliente z.counter al nuovo veicolo. 
						
						PrintStream debug;
						if(inst.get_typeInstance()==0){
							debug = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\debug\\debug.txt"));
						}else{
							debug = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstance\\debug\\debug.txt"));
						}
						System.setOut(debug);
						for(i=0;i<soluzione.elementi.size();i++){
							System.out.println("Ecco la soluzione del veicolo: "+soluzione.elementi.get(i).veicolo_usato.ID_veicolo+" del signor"+soluzione.elementi.get(i).veicolo_usato.ID_autista);
							System.out.println("BARCODE"+"\t"+"ORIGINE"+"\t"+"DESTINAZIONE"+"\t"+"LST"+"\t"+"ORA_ARRIVO");
							for(j=0;j<soluzione.elementi.get(i).pacchi_assegnati.size();j++){
								System.out.println(soluzione.elementi.get(i).pacchi_assegnati.get(j).Barcode+"\t"+soluzione.elementi.get(i).pacchi_assegnati.get(j).Origine+"\t"+soluzione.elementi.get(i).pacchi_assegnati.get(j).Destinazione+"\t"+soluzione.elementi.get(i).pacchi_assegnati.get(j).LST+"\t"+soluzione.elementi.get(i).pacchi_assegnati.get(j).ora_arrivo_stimata);
							}
						}
						
						System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
						
						int last_address_pos = inst.find_position1(soluzione.elementi.get(z).pacchi_assegnati.lastElement().Destinazione);
						int posizione = inst.find_position1(ClusterSet.get(z).get(counter).indirizzo);
					
						//System.out.println("CLIENTE: "+ClusterSet.get(z).get(counter).indirizzo+" , arrivo a :"+temporale+" e devo arrivare entro: "+tempo);
						
						if( soluzione.elementi.get(z).veicolo_usato.capacit� - volume > 0 && soluzione.elementi.get(z).veicolo_usato.portata - peso > 0 && soluzione.elementi.get(z).pacchi_assegnati.lastElement().ora_arrivo_stimata + inst.get_timematrix()[last_address_pos][posizione]/inst.get_scalatempo() <= tempo){ // nessuna tolleranza temporale
							soluzione.elementi.get(z).veicolo_usato.capacit� -= volume;
							soluzione.elementi.get(z).veicolo_usato.portata -= peso;
							
							Vector<Pacco> pacchi_appoggio = new Vector<Pacco>();
							pacchi_appoggio = retrieve_packages(ClusterSet.get(z).get(counter).indirizzo, inst);
							double ora_arrivo = soluzione.elementi.get(z).pacchi_assegnati.lastElement().ora_arrivo_stimata + inst.get_timematrix()[last_address_pos][posizione]/inst.get_scalatempo();
							for(int t = 0; t < pacchi_appoggio.size(); t++){
								Pacco_assegnato p = new Pacco_assegnato();
								p.Barcode = pacchi_appoggio.get(t).Barcode;
								p.Destinazione = pacchi_appoggio.get(t).Destinazione;
								p.Origine = pacchi_appoggio.get(t).Origine;
								p.peso = pacchi_appoggio.get(t).peso;
								p.volume = pacchi_appoggio.get(t).volume;
								p.LST = pacchi_appoggio.get(t).LST;
								p.ora_arrivo_stimata = ora_arrivo;
								soluzione.elementi.get(z).pacchi_assegnati.addElement(p);
							}
							
							colloassegnato = true;
						}else {	// altrimenti ho bisogno di un nuovo veicolo
							// CERCO UN VEICOLO DISPONIBILE TRA QUELLI CHE SONO ATTUALMENTE IN GIOCO
							
							Vector<Veicolo_in_gioco> veicoli = new Vector<Veicolo_in_gioco>();	
							
							for(i=0;i<soluzione.elementi.size();i++){
								Veicolo_in_gioco v = new Veicolo_in_gioco();								
								int last_pos = inst.find_position1(soluzione.elementi.get(i).pacchi_assegnati.lastElement().Destinazione);
								int pos = inst.find_position1(ClusterSet.get(z).get(counter).indirizzo);
								v.posizione = i;
								v.distanza=(inst.get_distmatrix()[last_pos][pos]);
								veicoli.add(v);
							}
							
							Collections.sort(veicoli, new Veicolo_in_gioco());	
							/*System.out.println("Poisizione"+"\t"+"Distanza");
							for(i=0;i<veicoli.size();i++){
								System.out.println(veicoli.get(i).posizione+"\t"+veicoli.get(i).distanza);
							}*/
							
							int v;
							boolean found = false;
							for(v=0;v<veicoli.size() && !found;v++){
								if(soluzione.elementi.get(veicoli.get(v).posizione).veicolo_usato.capacit� - volume > 0 && soluzione.elementi.get(veicoli.get(v).posizione).veicolo_usato.portata - peso > 0 && soluzione.elementi.get(veicoli.get(v).posizione).pacchi_assegnati.lastElement().ora_arrivo_stimata + inst.get_timematrix()[last_address_pos][posizione]/inst.get_scalatempo() <= tempo) {							
									soluzione.elementi.get(veicoli.get(v).posizione).veicolo_usato.capacit� -= volume;
									soluzione.elementi.get(veicoli.get(v).posizione).veicolo_usato.portata -= peso;
									
									Vector<Pacco> pacchi_appoggio = new Vector<Pacco>();
									pacchi_appoggio = retrieve_packages(ClusterSet.get(z).get(counter).indirizzo, inst);
									double ora_arrivo = soluzione.elementi.get(veicoli.get(v).posizione).pacchi_assegnati.lastElement().ora_arrivo_stimata + inst.get_timematrix()[last_address_pos][posizione]/inst.get_scalatempo();	
									for(int t = 0; t < pacchi_appoggio.size(); t++){
										Pacco_assegnato p = new Pacco_assegnato();
										p.Barcode = pacchi_appoggio.get(t).Barcode;
										p.Destinazione = pacchi_appoggio.get(t).Destinazione;
										p.Origine = pacchi_appoggio.get(t).Origine;
										p.peso = pacchi_appoggio.get(t).peso;
										p.volume = pacchi_appoggio.get(t).volume;
										p.LST = pacchi_appoggio.get(t).LST;
										p.ora_arrivo_stimata = ora_arrivo;
										soluzione.elementi.get(veicoli.get(v).posizione).pacchi_assegnati.addElement(p);
									}
									colloassegnato = true;
									found = true;
									//System.out.println("Mi � stato d'aiuto uno dei veicoli in gioco");
								}
							}
							if(!found){	// significa che ho bisogno di un nuovo veicolo
								System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));

								//System.out.println("Non ho neanche un veicolo in gioco che mi pu� aiutare. Vado a cercarmene un altro");

								Elemento_soluzione e = new Elemento_soluzione();
								e.veicolo_usato = new Veicolo();
								e.pacchi_assegnati = new Vector<Pacco_assegnato>();
								e.veicolo_usato = inst.get_vehiclematrix().firstElement();
								
								Pacco_assegnato fake = new Pacco_assegnato();	 // facciamo partire tutto dal magazzino
								fake.LST = 600;
								fake.Origine = inst.get_packagematrix().firstElement().Origine;
								fake.Destinazione = fake.Origine ;	
								e.pacchi_assegnati.addElement(fake);
								
								soluzione.elementi.addElement(e);
								inst.get_vehiclematrix().remove(inst.get_vehiclematrix().firstElement());	// rimuoviamo il veicolo appena introdotto in soluzione
								Vector<Pacco> pacchi_appoggio = new Vector<Pacco>();
								pacchi_appoggio = retrieve_packages(ClusterSet.get(z).get(counter).indirizzo, inst);
								
								double ora_arrivo = soluzione.elementi.lastElement().pacchi_assegnati.lastElement().ora_arrivo_stimata + inst.get_timematrix()[last_address_pos][posizione]/inst.get_scalatempo();
								
								for(int t = 0; t < pacchi_appoggio.size(); t++){
									Pacco_assegnato p = new Pacco_assegnato();
									p.Barcode = pacchi_appoggio.get(t).Barcode;
									p.Destinazione = pacchi_appoggio.get(t).Destinazione;
									p.Origine = pacchi_appoggio.get(t).Origine;
									p.peso = pacchi_appoggio.get(t).peso;
									p.volume = pacchi_appoggio.get(t).volume;
									p.LST = pacchi_appoggio.get(t).LST;
									p.ora_arrivo_stimata = 	ora_arrivo;
									soluzione.elementi.lastElement().pacchi_assegnati.addElement(p);
								}
							
								soluzione.elementi.lastElement().veicolo_usato.capacit� -= volume;
								soluzione.elementi.lastElement().veicolo_usato.portata -= peso;
								colloassegnato=true;
							}		
						}	
					} // collo assegnato

				}
			}
			counter++;
		}
		
		/*** PERCORSO DI RITORNO ***/ 	// qua nel caso single-depot � semplificato
		for(i = 0;i<soluzione.elementi.size();i++){	// si aggiunge il magazzino di ritorno per ciascun veicolo. In generale avremo un vector di magazzini che ogni veicolo si porta dietro in quanto pi� pacchi potrebbero comportare pi� magazzini, qua per� utilizzeremo un solo magazzino
			int last_pos = inst.find_position1(soluzione.elementi.get(i).pacchi_assegnati.lastElement().Destinazione);
			Pacco_assegnato p = new Pacco_assegnato();
			p.Destinazione = inst.get_packagematrix().firstElement().Origine;
			p.LST = 600/inst.get_scalatempo();
			p.ora_arrivo_stimata = soluzione.elementi.get(i).pacchi_assegnati.lastElement().ora_arrivo_stimata + inst.get_timematrix()[last_pos][0]/inst.get_scalatempo();
			soluzione.elementi.get(i).pacchi_assegnati.addElement(p);
		}		
	}

	public class Veicolo_in_gioco implements Comparator<Veicolo_in_gioco>{
		int posizione;
		double distanza;
		
		public int compare(Veicolo_in_gioco v1, Veicolo_in_gioco v2) {
			if(v1.distanza < v2.distanza) return -1;
			if(v1.distanza > v2.distanza) return 1;
			return 0;
		}
		
	}
	
	public Vector<Pacco> retrieve_packages(String indirizzo, IInstance inst){
		Vector<Pacco> packages = new Vector<Pacco>();
		
		for(int i=0;i<inst.get_packagematrix().size();i++){
			Pacco p = new Pacco();
			if(indirizzo.equals(inst.get_packagematrix().get(i).Destinazione)){
				p = inst.get_packagematrix().get(i);
				packages.add(p);
			}
		}
		return packages;
	}

	/**
	 * Questo metodo copia la soluzione s1 in s2.
	 */
	public void copy_solution(Soluzione s1, Soluzione s2){
		s2.funzione_obiettivo = s1.funzione_obiettivo;
		s2.elementi = new Vector<Elemento_soluzione>();
		for(int i=0;i<s1.elementi.size();i++){
			Elemento_soluzione e = new Elemento_soluzione();
			e.distanza_percorsa = s1.elementi.get(i).distanza_percorsa;
			
			e.veicolo_usato = new Veicolo();
			
			e.veicolo_usato.capacit� =  s1.elementi.get(i).veicolo_usato.capacit�;
			e.veicolo_usato.Carburante =  s1.elementi.get(i).veicolo_usato.Carburante;
			e.veicolo_usato.ID_autista =  s1.elementi.get(i).veicolo_usato.ID_autista;
			e.veicolo_usato.ID_veicolo =  s1.elementi.get(i).veicolo_usato.ID_veicolo;
			e.veicolo_usato.portata =  s1.elementi.get(i).veicolo_usato.portata;
			
			e.pacchi_assegnati = new Vector<Pacco_assegnato>();
			
			for(int j=0;j<s1.elementi.get(i).pacchi_assegnati.size();j++){
				Pacco_assegnato p = new Pacco_assegnato();
				p.Barcode = s1.elementi.get(i).pacchi_assegnati.get(j).Barcode;
				p.Destinazione = s1.elementi.get(i).pacchi_assegnati.get(j).Destinazione;
				p.LST = s1.elementi.get(i).pacchi_assegnati.get(j).LST;
				p.ora_arrivo_stimata = s1.elementi.get(i).pacchi_assegnati.get(j).ora_arrivo_stimata;
				p.Origine = s1.elementi.get(i).pacchi_assegnati.get(j).Origine;
				p.peso = s1.elementi.get(i).pacchi_assegnati.get(j).peso;
				p.volume = s1.elementi.get(i).pacchi_assegnati.get(j).volume;				
				e.pacchi_assegnati.addElement(p);
			}
			s2.elementi.addElement(e);
		}
	}
	
	/**
	 * Questo metodo copia l'elemento e1 in e2.
	 */
	public void copy_element (Elemento_soluzione e1, Elemento_soluzione e2){
		e2.distanza_percorsa = e1.distanza_percorsa;
		
		e2.veicolo_usato = new Veicolo();
		
		e2.veicolo_usato.capacit� =  e1.veicolo_usato.capacit�;
		e2.veicolo_usato.Carburante =  e1.veicolo_usato.Carburante;
		e2.veicolo_usato.ID_autista =  e1.veicolo_usato.ID_autista;
		e2.veicolo_usato.ID_veicolo =  e1.veicolo_usato.ID_veicolo;
		e2.veicolo_usato.portata =  e1.veicolo_usato.portata;
		
		e2.pacchi_assegnati = new Vector<Pacco_assegnato>();
		
		for(int j=0;j<e1.pacchi_assegnati.size();j++){
			Pacco_assegnato p = new Pacco_assegnato();
			p.Barcode = e1.pacchi_assegnati.get(j).Barcode;
			p.Destinazione = e1.pacchi_assegnati.get(j).Destinazione;
			p.LST = e1.pacchi_assegnati.get(j).LST;
			p.ora_arrivo_stimata = e1.pacchi_assegnati.get(j).ora_arrivo_stimata;
			p.Origine = e1.pacchi_assegnati.get(j).Origine;
			p.peso = e1.pacchi_assegnati.get(j).peso;
			p.volume = e1.pacchi_assegnati.get(j).volume;				
			e2.pacchi_assegnati.addElement(p);
		}
		
	}
	
	public boolean check_times(Soluzione soluzione){
		boolean ris = true;
		int i,j;
		for(i=0;i<soluzione.elementi.size() && ris;i++){
			for(j=0;j<soluzione.elementi.get(i).pacchi_assegnati.size() && ris;j++){
				if(soluzione.elementi.get(i).pacchi_assegnati.get(j).ora_arrivo_stimata > soluzione.elementi.get(i).pacchi_assegnati.get(j).LST){
					ris=false;
					//System.out.println("il cliente "+soluzione.elementi.get(i).pacchi_assegnati.get(j).Destinazione+" doveva essere servito entro le "+soluzione.elementi.get(i).pacchi_assegnati.get(j).LST+" e invece viene servito alle "+soluzione.elementi.get(i).pacchi_assegnati.get(j).ora_arrivo_stimata);
				}
			}
		}
		return ris;
	}
	
	public boolean check_element_times(Elemento_soluzione e){
		boolean ris = true;
		for(int j=0;j<e.pacchi_assegnati.size() && ris;j++){
			if(e.pacchi_assegnati.get(j).ora_arrivo_stimata > e.pacchi_assegnati.get(j).LST){
				ris = false;
				//System.out.println("il cliente "+e.pacchi_assegnati.get(j).Destinazione+" doveva essere servito entro le "+e.pacchi_assegnati.get(j).LST+" e invece viene servito alle "+e.pacchi_assegnati.get(j).ora_arrivo_stimata);
			}
		}
		return ris;
	}
	
	public void calcola_funzione_obiettivo(Soluzione soluzione, IInstance inst) throws IOException{
		int i;
		double funzione_obiettivo = 0;
		for(i=0;i<soluzione.elementi.size();i++){
			calcola_distanza(soluzione.elementi.get(i), inst);
			funzione_obiettivo += soluzione.elementi.get(i).distanza_percorsa;
		}
		soluzione.funzione_obiettivo = funzione_obiettivo;
	}
	
	public void calcola_distanza(Elemento_soluzione e, IInstance inst) throws IOException{
		double distanza = 0;
		int i;
		int pos1,pos2;
		for(i=0;i<e.pacchi_assegnati.size()-1;i++){		// -2 se consideri i 2 pacchi fittizi dei magazzini
			pos1 = inst.find_position1(e.pacchi_assegnati.get(i).Destinazione);
			pos2 = inst.find_position1(e.pacchi_assegnati.get(i+1).Destinazione);
			distanza += inst.get_distmatrix()[pos1][pos2];
		}
		e.distanza_percorsa = distanza;
	}
	
	/**
	 * Semplice funzione di calcolo del tempo totale di percorrenza. Effettua la traduzione da numero intero a orario hh:mm. Richiede che le eventuali scale temporali siano gi� state prese in considerazione
	 */
	
	public void calcola_tempo_percorrenza(Elemento_soluzione e){
		int baseline = 0;	// potresti anche toglierla
		int min_arrivo = (int) (e.pacchi_assegnati.lastElement().ora_arrivo_stimata % 60);
		int ora_arrivo = baseline + (int) e.pacchi_assegnati.lastElement().ora_arrivo_stimata / 60;
		if(min_arrivo>=10)
		System.out.println("Tempo di percorrenza totale: "+"\t" +ora_arrivo+":"+min_arrivo);
		if(min_arrivo<10)
		System.out.println("Tempo di percorrenza totale:" +"\t" +ora_arrivo+":"+"0"+min_arrivo);
	}
	
	public void stampa_elemento(Elemento_soluzione e, IInstance inst){
		int j;
		// qua si riporta tutto alla scala naturale (min) per facilitare le successive stampe
		
		for(j=0;j<e.pacchi_assegnati.size();j++){
			e.pacchi_assegnati.get(j).LST *= inst.get_scalatempo();
			e.pacchi_assegnati.get(j).ora_arrivo_stimata *= inst.get_scalatempo();
		}
	
		
		System.out.println("Veicolo utilizzato: "+e.veicolo_usato.ID_veicolo);
		System.out.println("Alimentazione: "+e.veicolo_usato.Carburante);
		System.out.println("Autista: "+e.veicolo_usato.ID_autista);
		System.out.println("Capacit� utile:"+e.veicolo_usato.capacit�);
		System.out.println("Portata utile:"+e.veicolo_usato.portata);
		System.out.println("Pacchi assegnati:");
		System.out.println("BARCODE" + "\t" + "ORIGINE"+"\t"+"DESTINAZIONE"+"\t"+"PESO"+"\t"+"VOLUME"+"\t"+"LST"+"\t"+"ORARIO STIMATO");
		for(j=0;j<e.pacchi_assegnati.size();j++){	// si evita di stampare i pacchi fittizi, anche se in multidepot ci servir� stampare il deposito di ritorno
			int ora_LST = (int) (inst.get_baseline() + e.pacchi_assegnati.get(j).LST/60);
			int aux_minuti_LST = (int) (e.pacchi_assegnati.get(j).LST % 60);
			String minuti_LST;
			if(aux_minuti_LST>=10){
				minuti_LST = String.valueOf(aux_minuti_LST);
			}else{minuti_LST = "0"+String.valueOf(aux_minuti_LST);}

			int ora = (int) (inst.get_baseline() + e.pacchi_assegnati.get(j).ora_arrivo_stimata/60);
			int aux_minuti = (int) (e.pacchi_assegnati.get(j).ora_arrivo_stimata % 60);
			String minuti;
			if(aux_minuti>=10){
				minuti = String.valueOf(aux_minuti);
			}else{minuti = "0"+String.valueOf(aux_minuti);}

			System.out.println(e.pacchi_assegnati.get(j).Barcode + "\t" +e.pacchi_assegnati.get(j).Origine +"\t"+e.pacchi_assegnati.get(j).Destinazione+"\t"+e.pacchi_assegnati.get(j).peso+"\t"+e.pacchi_assegnati.get(j).volume+"\t"+ora_LST+":"+minuti_LST+"\t"+ora+":"+minuti);
		}
		calcola_tempo_percorrenza(e);
	
		for(j=0;j<e.pacchi_assegnati.size();j++){
			e.pacchi_assegnati.get(j).LST /= inst.get_scalatempo();
			e.pacchi_assegnati.get(j).ora_arrivo_stimata /= inst.get_scalatempo();
		}
	
	}
	
	public int trova_posizione(Vector<Pacco_assegnato> v, String indirizzo){
		int pos = -1;
		int i;
		boolean trovato = false;
		for(i=0;i<v.size()&&!trovato;i++){
			if(v.get(i).Destinazione.equals(indirizzo)){
				trovato = true;
				pos = i;
			}
		}
		return pos;
	}
	
	public void copia_pacco(Pacco_assegnato originale, Pacco_assegnato copia){
		copia.Barcode = originale.Barcode;
		copia.Destinazione = originale.Destinazione;
		copia.LST = originale.LST;
		copia.ora_arrivo_stimata = originale.ora_arrivo_stimata;
		copia.Origine = originale.Origine;
		copia.peso = originale.peso;
		copia.volume = originale.volume;
	}

}
