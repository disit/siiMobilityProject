package generic;
import java.io.*;
import java.util.Vector;
import generic.IInstance.Veicolo;
import generic.IInstance.Pacco;

public interface ICore {
	public void loadProblem(IInstance inst);
	public Soluzione solveProblem(IInstance inst) throws IOException;
	public void printSolution(Soluzione soluzione, IInstance inst);
	public Soluzione localSearch(Soluzione soluzione, IInstance inst) throws IOException;
	
	public class Soluzione{
		Vector<Elemento_soluzione> elementi;
		double funzione_obiettivo;
	}
	
	public class Elemento_soluzione{
		Veicolo veicolo_usato;
		Vector<Pacco_assegnato> pacchi_assegnati;
		double distanza_percorsa;		
	}
	
	public class Pacco_assegnato extends Pacco{
		double ora_arrivo_stimata;
	}
	
}
