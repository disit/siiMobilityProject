package generic;
import java.io.*;
import generic.ICore.Soluzione;

/**
 * Autore: Emanuele Guerrazzi
 * 
 * Questo programma risolve il problema del Heterogeneous 2-Capacitated VRP with Time Windows (H2CVRPTW) mediante l'utilizzo di un algoritmo euristico costruttivo con ricerca locale. 
 * ISTRUZIONI PER L'ESECUZIONE DEL MAIN:
 * - Questo programma risolve il H2CVRPTW di istanze definite in modo diverso (Manhattan, Reale leggendo da .txt e Reale leggendo da DB XAMPP). E' possibile creare la propria istanza facendo riferimento all'interfaccia IInstance.java
 * - Importare le librerie gson e mysql-connector
 * - Definire la propria connessione al DB e le proprie directory in cui leggere/scrivere i file di input/output.
 */

public class Main {
	
	public static void main(String[] args) throws IOException{
	
	// ISTANZA MANHATTAN
	System.out.println("Istanza Manhattan");
	IInstance M = new ManhattanInstance();
	M.readData();

	ICore Q = new Core3();
	Q.loadProblem(M);
	Soluzione soluzioneMan = Q.solveProblem(M);
	PrintStream solutionMan = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\solution\\solution.txt"));
	System.setOut(solutionMan);
	Q.printSolution(soluzioneMan, M);
	System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
	Q.localSearch(soluzioneMan, M);

	PrintStream solutionManImproved = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\ManhattanInstance\\solution\\solutionImproved.txt"));
	System.setOut(solutionManImproved);
	Q.printSolution(soluzioneMan, M);
	System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
		
	// ISTANZA REALE da .txt
	IInstance C = new RealInstance();
	C.readData();	
	
	ICore P = new Core3(); 
	P.loadProblem(C);
	PrintStream solutionReal = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstance\\solution\\solution.txt"));
	Soluzione soluzioneReal = P.solveProblem(C);
	System.setOut(solutionReal);
	P.printSolution(soluzioneReal, C);
	System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
	P.localSearch(soluzioneReal,C);
	
	PrintStream solutionRealImproved = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstance\\solution\\solutionImproved.txt"));
	System.setOut(solutionRealImproved);
	P.printSolution(soluzioneReal, C);
	
	System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
	
	// ISTANZA REALE CON DB
	
	System.out.println("Istanza Reale con DB");
	IInstance R = new RealInstanceDB();
	R.readData();
	ICore C3 = new Core3DB();
	C3.loadProblem(R);
	Soluzione soluzioneRealDB = C3.solveProblem(R);
	PrintStream solutionRealDB = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstanceDB\\solution\\solution.txt"));
	System.setOut(solutionRealDB);
	C3.printSolution(soluzioneRealDB, R);
	System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
	C3.localSearch(soluzioneRealDB, R);
	PrintStream solutionRealDBImproved = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstanceDB\\solution\\solutionImproved.txt"));
	System.setOut(solutionRealDBImproved);
	C3.printSolution(soluzioneRealDB, R);
		
	}	
}
