package generic;
import java.io.*;
import java.util.Scanner;
import java.util.Vector;

public class RealInstance implements IInstance{
	
	int ND;
	int NC;
	int[][] distmat;	// matrice delle distanze espresse in metri
	double[][] timemat;	// matrice dei tempi espressa in minuti. NB: in Google il concetto di velocit� variabile � inglobato nella timematrix (ovvero non c'� una funzione univoca che lega distanza e tempo, come invece accade in ambiente simulato)
	Vector<Veicolo> vehiclemat;
	Vector<Pacco> packmat;
	Vector<Cliente> custmat;
	final int baseline = 8;
	String[] indirizzy;
	
	File inputt = new File("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstance\\input\\input.txt");
	File coordinate = new File("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstance\\input\\coord.txt");
	File distanze = new File("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstance\\input\\distmatrix.txt");
	File tempi = new File("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstance\\input\\timematrix.txt");
	File veicoli = new File("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstance\\input\\vehiclematrix.txt");
	File pacchi = new File("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstance\\input\\packagematrix.txt");
	
	File indirizzi = new File("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstance\\input\\indirizzi.txt");	// file dal quale in fase di pre-preprocessing viene egenerata la matrice delle distanze
	
	/*************************************/
	/*** IMPLEMENTAZIONE METODI SETTER ***/
	/*************************************/
	
	public void set_ND(int ND){	this.ND = ND;};	
	public void set_NC(int NC){ this.NC = NC;};
	// manca il set_distmatrix
	
	/*************************************/
	/*** IMPLEMENTAZIONE METODI GETTER ***/
	/*************************************/
	
	public int get_ND(){ return this.ND; };
	public int get_NC(){ return this.NC; };
	public int[][] get_distmatrix(){ return this.distmat; }
	public double[][] get_timematrix(){ return this.timemat; }
	public Vector<Veicolo> get_vehiclematrix(){return this.vehiclemat; }
	public Vector<Pacco> get_packagematrix(){return this.packmat; }
	public Vector<Cliente> get_customermatrix(){ return this.custmat; }
	public int get_speed(){ return 25; }	// velocit� media dei veicoli fissata a 25 km/h
	public int get_typeInstance(){return 1;}
	public int get_scalatempo(){return 1;}
	public int get_baseline(){return baseline;}
	public String[] get_indirizzi(){return this.indirizzy;}
	
	/**************************************/
	/*** IMPLEMENTAZIONE METODI READING ***/
	/**************************************/
	
	public void readData() throws IOException{
		Scanner input = new Scanner(inputt);
		boolean trovato = false;
		// Lettura ND
		while(!trovato){
			if(input.hasNextInt()){
				set_ND(input.nextInt());
				trovato = true;
			}else input.next();
		}
		// Lettura NC: in un primo momento possiamo leggere il numero di clienti da File, per� poi non � detto che rimanga questa modalit�
		trovato = false;
		while(!trovato){
			if(input.hasNextInt()){
				set_NC(input.nextInt());
				trovato = true;
			}else input.next();
		}
		input.close();
		
		int i,j;
		int nodi = NC + ND;
		
		// Lettura distmatrix
		distmat = new int[nodi][nodi];
		Scanner distmatrix = new Scanner(distanze);
		for(i=0;i<nodi;i++){
			for(j=0;j<nodi;j++){
				if(distmatrix.hasNextInt()){
					distmat[i][j] = distmatrix.nextInt();
				}else distmatrix.next();
			}
			if(i<nodi-1)
			distmatrix.nextLine();
		}
		distmatrix.close();
		
		// Lettura timematrix
		timemat = new double [nodi][nodi];
		Scanner timematrix = new Scanner(tempi);
		double beta = 5;	// coefficiente additivo per carico/scarico (min)
		for(i=0;i<nodi;i++){
			for(j=0;j<nodi;j++){
				if(timematrix.hasNextDouble()){
					timemat[i][j] = timematrix.nextDouble() + beta;
				}else timematrix.next();
			}
			if(i<nodi-1)
			timematrix.nextLine();
		}
		timematrix.close();
		
		// Lettura vehiclematrix
		vehiclemat = new Vector<Veicolo>();
		Scanner vehiclematrix = new Scanner(veicoli);
		while(vehiclematrix.hasNext()){
			vehiclematrix.nextLine();
			Veicolo vehicle = new Veicolo();
			vehicle.ID_veicolo = vehiclematrix.next();
			vehicle.Carburante = vehiclematrix.next();
			vehicle.portata = vehiclematrix.nextDouble();
			vehicle.capacit� = vehiclematrix.nextDouble();
			vehicle.ID_autista = vehiclematrix.next();
			vehiclemat.add(vehicle);
		}
		PrintStream vehi = new PrintStream(new FileOutputStream("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstance\\output\\vehicles.txt"));
		System.setOut(vehi);
		for(i=0;i<vehiclemat.size();i++){
			System.out.print(vehiclemat.get(i).ID_veicolo + "\t" + vehiclemat.get(i).ID_autista + "\t" +vehiclemat.get(i).Carburante + "\t"+ vehiclemat.get(i).portata+"\t"+vehiclemat.get(i).capacit�);
			System.out.println();
		}
		System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
		
		vehiclematrix.close();
		
		// Lettura packagematrix
		packmat = new Vector<Pacco>();
		//Scanner packagematrix = new Scanner(new File("C:\\Users\\pc\\Desktop\\CODICE UNICO\\RealInstance\\input\\packagematrix.txt")).useDelimiter("\\s*\t*\\s*");
		Scanner packagematrix = new Scanner(pacchi);
		packagematrix.nextLine();
		packagematrix.nextLine();
		while(packagematrix.hasNextLine()){
			Scanner packagematrix2 = new Scanner(packagematrix.nextLine());
			packagematrix2.useDelimiter("\t");
			Pacco pacco = new Pacco();
			pacco.Barcode = packagematrix2.next();
			pacco.Origine = packagematrix2.next();
			pacco.Destinazione = packagematrix2.next();
			while(pacco.peso==0){
				if(packagematrix2.hasNextDouble()){
				pacco.peso = packagematrix2.nextDouble();
				}else{packagematrix2.next();}
			}
			while(pacco.volume==0){
				if(packagematrix2.hasNextDouble()){
				pacco.volume = packagematrix2.nextDouble();
				}else{packagematrix2.next();}
			}
			while(pacco.LST==0){
				if(packagematrix2.hasNextInt()){
				pacco.LST = packagematrix2.nextInt();
				}else{packagematrix2.next();}
			}
			//packagematrix.nextLine();
			packmat.add(pacco);
			packagematrix2.close();
		}
		
		packagematrix.close();
		
		// Lettura custmatrix
		custmat = new Vector<Cliente>();
		Scanner custmatrix = new Scanner(coordinate);
		for(i=0;i<NC;i++){
			Cliente cliente = new Cliente();
			cliente.indirizzo = packmat.get(i).Destinazione;
			//System.out.println("indirizzo = "+cliente.indirizzo);
			Scanner line = new Scanner(find_latlon(cliente.indirizzo,coordinate));
			line.useDelimiter("\t");
			line.next();	// serve a evitare di prendere l'indirizzo
			while(cliente.latitudine==0){
				if(line.hasNextDouble()){
					cliente.latitudine = line.nextDouble();
					//System.out.println("latitudine = "+cliente.latitudine);
				}else{line.next();}
			}
			while(cliente.longitudine==0){
				if(line.hasNextDouble()){
					cliente.longitudine = line.nextDouble();
				}else{line.next();}
			}
			line.close();
			custmat.add(cliente);
		}
		
		custmatrix.close();
		
	}
	
	
	/**************************************/
	/*** IMPLEMENTAZIONE METODI WRITING ***/
	/**************************************/
	
	/*********************************************************/
	/*** IMPLEMENTAZIONE METODI DI SUPPORTO (di IInstance) ***/
	/*********************************************************/
	
	// questo metodo trova la posizione dell'indirizzo del cliente dentro alla matrice delle distanze
	public int find_position1(String indirizzo) throws IOException{
		int position = -1;
		boolean trovato = false;
		Scanner input = new Scanner(this.indirizzi);
		int conta_pos = -1;	// serve a evitare il conflitto con ﻿ 
		while(input.hasNextLine() && !trovato){
			String s = input.nextLine();
			if(s.equals(indirizzo)){
				position = conta_pos;
				trovato = true;
			}else{
				conta_pos++;
			}
		}	
		input.close();
		return position;
	}

	// questo metodo serve per capire la posizione dell'indirizzo nella ATTUALE matrice delle distanze (che � pi� piccola)
	public int find_position2(String indirizzo, String[] indirizzi){
			int position = -1;
			boolean trovato = false;
			
			for(int i=0;i<indirizzi.length&&!trovato;i++){
				if(indirizzo.equals(indirizzi[i])){
					trovato=true;
					position = i;
				}
			}
			return position;
		}
	
	/**************************/
	/*** METODI DI SUPPORTO ***/
	/**************************/
	
	/**
	 * Questo metodo restituisce la linea in cui si trovano latitudine e longitudine
	 * @param indirizzo	� l'indirizzo del cliente
	 * @param coordinate � il file in cui cercare l'indirizzo
	 * @return ritorna la linea in cui si trovano lat e lon dell'indirizzo passato in input
	 */
	public String find_latlon(String indirizzo, File coordinate) throws IOException{
		String line = "ERROR";
		boolean trovato = false;
		Scanner scanner = new Scanner(coordinate);
		while(!trovato){
			String linea = scanner.nextLine();
			Scanner auxlinea = new Scanner(linea);
			auxlinea.useDelimiter("\t");
			String stringa = auxlinea.next();
			if(stringa.equals(indirizzo)){
				trovato = true;
				line = linea;
			}
			auxlinea.close();
		}
		
		scanner.close();
		//System.out.println("line = "+line);
		return line;
	}
	
}
